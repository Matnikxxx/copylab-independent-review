# CopyLab — Independent Review Package

**Prepared:** 2026-11-05
**Reference commit (frozen):** `ad8470c71a4421994cb8514ae7d2139adf1f086d`
**Branch:** `arena/3e2065ef-copylab-independent-review`
**Purpose:** complete, self-contained handover for independent review in Google Antigravity.

---

## 1. Read this first — paper-only

CopyLab is a **paper-only** copy-trading research system. This package must be reviewed
without departing from the following, which are binding and non-negotiable:

- **No live trading. No real-money capability, permanently.** Not deferrable to a later
  phase; not grantable by the reviewer, the owner, or any gate in this package.
- **Paper-only restrictions must never be weakened** — not by tests, fixtures, reviewers,
  or a "temporary" relaxation to get a green run.
- **No API keys, no private keys, no signing capability, no key material, no order
  endpoints.** Public **GET only**, against a fixed allowlist.
- **No wallet queries, no external trading connections** during this review.
- **Do not start** the application, worker, or collector. **Do not open, write, migrate,
  back up or restore** any runtime database.
- **Do not deploy anything.**
- **Do not implement** remediation groups G1–G5. **All five remain NOT AUTHORISED.**
- **Do not modify source.** This is a read-only review of a frozen snapshot.

The authoritative requirement set is `review-package/MASTER_COMPLETION/MCD-08.md`
(SR-01…SR-28). If anything in this README appears to conflict with that document,
**`MCD-08` governs and the review stops until the conflict is resolved.**

---

## 2. Governance state at this commit

**Phase 0 is NOT SATISFIED. Phase 1A is NOT AUTHORISED. G1–G5 are NOT AUTHORISED.**

The acceptance suite is **PROVISIONAL** and requires independent review before it may be
adopted as the project's acceptance instrument. No remediation has been implemented, and no
fix has been applied to the source snapshot in this package.

A successful review does **not** by itself authorise implementation. The reviewer's verdict
is one input to an owner decision that has not yet been taken.

---

## 3. What is in this ZIP

```
README.md                         <- this file
MANIFEST.json                     <- every file + SHA-256, commit, original archive hash
SHA256SUMS.txt                    <- sha256sum -c compatible, covers all payload files
VERIFY.md                         <- step-by-step verification procedure
EXCLUDED_ITEMS.md                 <- every exclusion, with its reason

review-package/                   <- the review dossier (extracted from the frozen commit)
  AUDIT_REPORT_INDEP-AUDIT-01.md  <- original independent audit (UNMODIFIED, by design)
  copylab-external-review-INSTRUCTIONS.md
  copylab-external-review-SHA256.txt
  MASTER_COMPLETION/              <- 13 documents, see §4
    README.md                     <- dossier entry point
    MCD-01.md ... MCD-11.md
    CONSISTENCY_CHECK.md
    evidence/                     <- probe corpus, results, artefact manifest
    tools/                        <- 35-criterion acceptance suite + reproduction guide

source-snapshot/                  <- the code under review, as sealed by the producers
  paper-copy-lab/                 <- application source, docs, tests, fixtures
  _COPYLAB_TRANSFER/              <- producers' own manifest, exclusions, patch, git status
```

### Two layers, deliberately kept separate

`source-snapshot/` is the **thing being reviewed**. It is the immutable extraction of the
producers' sealed archive, verified byte-for-byte in §6 below. Nothing in it has been edited.

`review-package/` is **commentary about** that snapshot: the audit, the 35 acceptance
criteria, the correction record, the governance ledgers, and the safety requirements. It was
extracted from the frozen commit's object graph (`git archive`), not from a working tree.

The separation is intentional. The reviewer should be able to form an opinion of the source
without the dossier's framing, then test the dossier's claims against it.

---

## 4. The review dossier (`MASTER_COMPLETION/`, 13 documents)

| Document | What it is |
|---|---|
| `README.md` | dossier entry point, reading order, blocker list |
| `MCD-01.md` | coordination dossier: state, reconciliation, group plan, blockers |
| `MCD-02.md` | **the 35 acceptance criteria**, each with root cause, pre-fix result, post-fix condition |
| `MCD-03.md` | A14-08 correction record — a claim withdrawn and replaced |
| `MCD-04.md` | owner decisions **D-1…D-12**, the TD-01 transmission record, gate state |
| `MCD-05.md` | external-review handover package and signature block |
| `MCD-06.md` | R1–R10 disposition register |
| `MCD-07.md` | authoritative 1A–1H ↔ G1–G6 numbering cross-reference |
| `MCD-08.md` | **authoritative safety requirements SR-01…SR-28**, provenance-tagged |
| `MCD-09.md` | G2 schema design — **design only, no migration exists** |
| `MCD-10.md` | environment and version pinning, plus known divergence |
| `MCD-11.md` | reviewer checklist, sections A–I, with signature block |
| `CONSISTENCY_CHECK.md` | measured evidence that the package agrees with itself |

**Suggested order:** `README.md` → `MCD-01` → `MCD-02` → `MCD-11` → the rest as referenced.

---

## 5. Verification procedure (summary)

Full detail in `VERIFY.md`. The three checks that matter:

1. **ZIP integrity** — compare the ZIP's SHA-256 against the value published with the
   download. Any mismatch means the file is corrupt or was altered in transit; stop.
2. **Payload integrity** — from the ZIP root run `sha256sum -c SHA256SUMS.txt`. Every line
   must report `OK`. This proves each file matches what was recorded at packaging time.
3. **Provenance** — confirm `MANIFEST.json` records commit
   `ad8470c71a4421994cb8514ae7d2139adf1f086d` and original archive SHA-256
   `f19437429a3dc239813840628920496123bf5fc2be3f0bf6c3af3fd2f9b11c23`, then re-verify the
   source snapshot against `source-snapshot/_COPYLAB_TRANSFER/MANIFEST.json`
   (156 hashed members).

Reproducing the acceptance suite is **optional** for review and is covered in
`review-package/MASTER_COMPLETION/tools/REPRODUCE.md`. If you run it, run it in a **copy**,
never against `source-snapshot/`, and expect **RED**: `TOTAL 35 / PASS 0 / FAIL 35`. A green
run on this snapshot would mean the suite is not testing what it claims.

---

## 6. Integrity record

| Item | Value |
|---|---|
| Reference commit | `ad8470c71a4421994cb8514ae7d2139adf1f086d` |
| Commit tree | `96926f1b5d53a7e303adbef1879da1f2f7ed2f85` |
| Parent commit | `9b8ba67b65d3ffec3a0b8da42ece04b21f88afed` |
| Original archive SHA-256 | `f19437429a3dc239813840628920496123bf5fc2be3f0bf6c3af3fd2f9b11c23` |
| Snapshot head at sealing | `288a69f64c24438cfe69ea176e6f3d6ce7333499` |
| Source snapshot files | 157 |
| Source snapshot manifest mismatches | **0 of 156** |
| Acceptance criteria | 35 |
| Safety requirements | SR-01…SR-28 (28) |

The source snapshot is byte-identical to the sealed archive the producers shipped. That was
re-verified at packaging time, not assumed from an earlier run.

---

## 7. Known limitations — read before forming a verdict

These are stated so you do not have to discover them:

- **The 35 criteria are provisional.** They have not been independently validated. They
  encode the audit's findings and two owner amendments (R4/R5); whether they are complete,
  correct, or free of self-defeating construction is exactly what you are being asked to judge.
- **`MCD-09` is design only.** No migration is written, run, or tested. Do not look for one.
- **Cross-version parity is unproven.** The authors ran Python 3.13.16 / SQLite 3.46.1; the
  package's measurements were taken on Python 3.11.2 / SQLite 3.40.1. Reasoning suggests the
  difference does not affect results, but this is **reasoned, not proven** (GOV-15).
- **`capture_frontiers` has a schema defect that cannot be fixed additively** — the primary
  key `(wallet, endpoint)` needs a new table or a rebuild. Decision deferred (GOV-14).
- **Directive §2 was truncated in transmission** (TD-01). The safety set in `MCD-08` was
  compiled only from owner-transmitted text and the sealed archive. Its **exhaustiveness is
  unconfirmed** (GOV-13). Nothing was reconstructed from memory.
- **Evidence findings H01–H05 are unresolved.** CopyLab cannot currently demonstrate it
  would copy a real wallet correctly even if every A14 defect were fixed. Fixing the
  instruments does not supply the measurements.
- **No runtime database is included.** Runtime state is therefore unverified by design.

---

## 8. What is excluded, and why

No required evidence has been silently omitted. Every exclusion is listed in
`EXCLUDED_ITEMS.md` with its reason. In summary:

- **Runtime databases** (`data/lab.sqlite`, `data/lab-verified-backup.sqlite`) — excluded by
  the producers and again here: they are protected runtime state, contain no review-relevant
  source, and their inclusion would breach the no-runtime-DB restriction.
- **Git internals** (~104 files) — not source or evidence.
- **A duplicate nested archive** — the original 1.2 MB ZIP was present inside the review
  package; it is byte-identical to the snapshot you already have unpacked. Its SHA-256 is
  recorded so you can confirm the identification.
- **No secrets, credentials, keys, or personal data are present.** Independently re-scanned
  at packaging time. See `EXCLUDED_ITEMS.md` §4.

---

## 9. Reviewer deliverables

Use `review-package/MASTER_COMPLETION/MCD-11.md` (checklist A–I, with signature block) and
`review-package/MASTER_COMPLETION/MCD-05.md` (handover package). Record, at minimum:

- which criteria you independently reproduced, and any that failed to reproduce;
- any criterion you judge wrong, insufficient, or trivially satisfiable;
- your verdict on the A14-08 correction;
- your verdict on the SR-01…SR-28 set's adequacy against the system as you observed it;
- an explicit statement of what your verdict does **not** cover.

---

## 10. Contact and scope

This package is complete as delivered. If a file listed in `MANIFEST.json` is missing, or a
checksum fails, the package is not reviewable — stop and request a fresh copy rather than
reviewing a partial artefact.
