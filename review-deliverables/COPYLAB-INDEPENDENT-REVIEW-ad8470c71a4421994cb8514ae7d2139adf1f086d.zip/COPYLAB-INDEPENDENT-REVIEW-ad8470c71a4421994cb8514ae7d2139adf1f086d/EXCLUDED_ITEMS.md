# Excluded items — complete list with reasons

This package contains **no silent omissions**. Everything that is absent is either
listed here with a reason, or was never part of the frozen commit or the sealed archive.

Three distinct kinds of exclusion apply. They are separated because their justifications
are different and a reviewer should be able to challenge each one independently.

---

## 1. Excluded from the source snapshot by the producers (107 items)

Recorded in `source-snapshot/_COPYLAB_TRANSFER/EXCLUSIONS_AND_SECURITY.json`, produced by
the people who sealed the archive. Reproduced here in full so the list is in front of you
without opening that file.

| Reason | Count | Items |
|---|---:|---|
| Git internals | 104 | `.git/` objects, refs, hooks, index, logs, config |
| Protected runtime database / verified backup | 2 | `data/lab.sqlite` (1 662 976 B), `data/lab-verified-backup.sqlite` (770 048 B) |
| Runtime worker lock, not source/evidence | 1 | `data/lab.sqlite.worker.lock` (0 B) |
| **Total** | **107** | |

**Why the databases are excluded.** They are *runtime state*, not source and not evidence
for the review. Including them would:

- breach the standing prohibition on opening, copying or migrating runtime databases;
- risk carrying live position, balance and wallet data into a document that is meant to be
  reviewable and shareable;
- add no review value — the review is of the code and the acceptance criteria, not of one
  machine's database.

**The consequence is a stated limitation, not a hidden gap:** runtime database state is
**unverified by design**. This is recorded as a blocker in the dossier (`MCD-01` §9,
blocker 8) and repeated in the top-level `README.md` §7.

**Git internals** are excluded because they are packaging machinery, not reviewable content.
The commit identity that matters is recorded explicitly in `MANIFEST.json` and needs no
`.git` directory to verify.

---

## 2. Excluded at packaging time by this package (1 item)

| Item | Size | Reason |
|---|---:|---|
| `review-package/copylab-external-review (1).zip` | 1 239 236 B | Duplicate of the source snapshot |

**Why.** The frozen commit happened to contain the original sealed archive as a committed
file. That archive is the **same artefact** already unpacked for you at
`source-snapshot/`. Keeping both would double the ZIP size for zero information, and would
invite the reviewer to unpack a second, unverified copy and thereby introduce ambiguity about
which tree is authoritative.

**This is not a silent removal.** Its identity is recorded so you can confirm the
identification yourself:

```
f19437429a3dc239813840628920496123bf5fc2be3f0bf6c3af3fd2f9b11c23
```

That is the same SHA-256 as the **original archive** declared in `MANIFEST.json` and in
`review-package/copylab-external-review-SHA256.txt`. So:

- the excluded file **is** the original archive, and
- its hash **is** preserved in this package, in three places.

**If you want the original archive byte-for-byte.** It is recoverable from the reference
commit without any access to this package:

```bash
git cat-file -p 'copylab-external-review (1).zip' > copylab-external-review.zip
sha256sum copylab-external-review.zip     # must equal f1943742…1c23
```

Nothing else was dropped. Every other file present in the frozen commit is included.

---

## 3. Never present in the first place

The frozen commit contains **32 files**. The review package holds **31** after the duplicate
archive is removed; the source snapshot holds **157**. Nothing was removed from the dossier:
all 13 `MASTER_COMPLETION` documents, all 5 probes, all 4 result files, the 35-criterion suite,
the reproduction guide and the artefact manifest are present.

`__pycache__` and `node_modules` do not exist in the frozen commit (they are git-ignored) and
are therefore absent here. No interim build output, no editor state, no temporary files.

---

## 4. Security scan — independent re-run at packaging time

The producers ran their own scan. Their result was not taken on trust: all **157** files were
re-scanned independently while building this ZIP.

| Pattern class | Result |
|---|---|
| Private key blocks (`BEGIN … PRIVATE KEY`) | **0** |
| Provider secrets (GitHub, OpenAI, AWS, Slack, Google) | **0** |
| JWTs | **0** |
| Bearer values | **0** |
| Credential assignments (`api_key`, `password`, `access_token`, `client_secret`, `seed_phrase`, `mnemonic`) | **0** |
| 64-hex private-key assignments | **0** |
| Credentials embedded in URLs | **0** |
| Solana-style addresses | **0** |
| Email addresses | **0** (one false positive inside PNG binary data, not text) |
| Absolute home paths (`/home/…`, `/Users/…`) | 32 hits — see below |
| 0x addresses | 148 hits, 44 distinct — see below |

### 4a. The 0x addresses are synthetic fixtures, not personal data

All 44 distinct addresses are **patterned test values**, e.g.
`0xe111180000d2663c0091e4f400237545b87b996b`,
`0xe2222d279d744050d28e00520010520000310f59`,
`0x000012e0009c84078c4924fba808a41b9f67527f`. They appear in
`docs/wallet-activity.md` as documented shell/JS examples and in test fixtures.

This is corroborated by the project's own records, which state that no real wallet has ever
been queried and that no addresses have been supplied:

> "No accounts/live wallet APIs queried; no addresses requested." — `docs/phase0-audit14/PHASE0_REPORT.md`
> "Request actual user-supplied Polymarket proxy-wallet addresses **when ready to validate**." — `docs/CONTINUE.md`
> "No real wallet observations … " — `MASTER_REMEDIATION_PLAN.md`

`AUDIT_REPORT_INDEP-AUDIT-01.md` independently withholds wallet addresses from its own text.
**Reviewer note:** if you nevertheless believe any address is a real party's, treat it as
sensitive and do not republish it; report it instead.

### 4b. The `/home/…` paths are redacted sandbox paths, not personal data

These appear in the dossier and in `_COPYLAB_TRANSFER/` metadata as `/home/user`, i.e. the
generic container home directory. No real account name is exposed. The two
`docs/browser-*.log` files reference the same generic path.

No author identity, no machine name, no hostname and no shell history is present in any
included file. The only identity in this package is the public GitHub handle recorded in the
commit metadata, which is already public.

---

## 5. What a reviewer should do if something looks missing

1. Check this file first — the item is probably here with a reason.
2. Check `MANIFEST.json`: it lists every included file with its SHA-256. If a file appears
   there but is absent from the ZIP, the package is **incomplete** — stop and request a fresh
   copy.
3. If the item is genuinely unaccounted for, that is a packaging defect. Report it as one
   rather than reviewing around it.

Silence about a missing artefact would be worse than the omission itself. That is why this
file exists.
