# Verification procedure

Anyone can verify this package without trusting the sender. Work through the checks in
order; each one is independent, and each one can fail on its own.

Commands are POSIX shell. The ZIP expands to a **single top-level directory**; run every
command from inside it.

---

## Check 1 — The ZIP itself

Before unpacking, compare the archive's SHA-256 against the value published alongside the
download.

```bash
sha256sum COPYLAB-INDEPENDENT-REVIEW-ad8470c71a4421994cb8514ae7d2139adf1f086d.zip
```

The published value is in `ZIP-SHA256.txt`, which accompanies the download separately (it
cannot live inside the ZIP it describes, since that would be self-referential).

**If it does not match:** the file was corrupted or altered in transit. **Stop.** Do not
review a package that failed this check, and do not attempt to "repair" it.

---

## Check 2 — Unpack and confirm structure

```bash
unzip -q COPYLAB-INDEPENDENT-REVIEW-ad8470c71a4421994cb8514ae7d2139adf1f086d.zip
cd COPYLAB-INDEPENDENT-REVIEW-ad8470c71a4421994cb8514ae7d2139adf1f086d
ls
```

You should see exactly:

```
README.md   MANIFEST.json   SHA256SUMS.txt   VERIFY.md   EXCLUDED_ITEMS.md
review-package/   source-snapshot/
```

The archive must open cleanly with no warnings. An "unexpected end of file" or a CRC error
means the download is truncated — return to Check 1.

---

## Check 3 — Every payload file matches its recorded hash

```bash
sha256sum -c SHA256SUMS.txt
```

Every line must end in `OK`, and the exit status must be `0`:

```bash
sha256sum -c SHA256SUMS.txt > /dev/null && echo "ALL OK"
```

This is the strongest single check in the package: it proves each file is byte-identical to
what was hashed at packaging time. There should be **no** `FAILED` lines.

`SHA256SUMS.txt` covers every file under `review-package/` and `source-snapshot/`, plus the
four documentation files. It does **not** list itself or `MANIFEST.json` (a file cannot
contain its own hash).

---

## Check 4 — Provenance matches the frozen reference

```bash
python3 - <<'EOF'
import json
m = json.load(open('MANIFEST.json'))
print("commit      :", m['reference_commit'])
print("tree        :", m['commit_tree'])
print("orig archive:", m['original_archive_sha256'])
print("files       :", len(m['files']))
EOF
```

Confirm these four values:

| Field | Expected |
|---|---|
| `reference_commit` | `ad8470c71a4421994cb8514ae7d2139adf1f086d` |
| `commit_tree` | `96926f1b5d53a7e303adbef1879da1f2f7ed2f85` |
| `original_archive_sha256` | `f19437429a3dc239813840628920496123bf5fc2be3f0bf6c3af3fd2f9b11c23` |
| `snapshot_head` | `288a69f64c24438cfe69ea176e6f3d6ce7333499` |

If you have the upstream repository, you can confirm the commit exists and that the package
was taken from it rather than a working tree:

```bash
git cat-file -t ad8470c71a4421994cb8514ae7d2139adf1f086d    # -> commit
git rev-parse ad8470c71a4421994cb8514ae7d2139adf1f086d^{tree}  # -> 96926f1b…
```

---

## Check 5 — The source snapshot is the sealed original

This is the check that matters most for review integrity: it proves `source-snapshot/` is the
producers' sealed archive and not something edited after the fact.

```bash
cd source-snapshot
python3 - <<'EOF'
import json, hashlib
from pathlib import Path
m = json.load(open('_COPYLAB_TRANSFER/MANIFEST.json'))
bad = []
for name, rec in m['files'].items():
    p = Path(name)
    if not p.exists():
        bad.append((name, 'MISSING'))
    elif hashlib.sha256(p.read_bytes()).hexdigest() != rec['sha256']:
        bad.append((name, 'HASH MISMATCH'))
print(f"checked {len(m['files'])} files, {len(bad)} problems")
for n, why in bad[:20]:
    print("  ", why, n)
EOF
```

Expected output:

```
checked 156 files, 0 problems
```

156 hashed members; the manifest file itself is excluded from its own hash map by
construction (the producers state this in the manifest). Total files on disk is **157**.

---

## Check 6 — The dossier is internally consistent

```bash
cd ../review-package/MASTER_COMPLETION
python3 - <<'EOF'
import re, json
from pathlib import Path
docs = sorted(Path('.').glob('*.md'))
print("documents      :", len(docs))                       # expect 13
rows = re.findall(r'^\|\s*(\d+)\s*\|\s*([A-Z][A-Z0-9]{0,4}-\d{2})\s*\|\s*`([a-z0-9_]+)`',
                  Path('MCD-02.md').read_text(), re.M)
rows = [r for r in rows if int(r[0]) <= 35]
cases = json.load(open('evidence/red-phase-results.json'))['cases']
print("criteria       :", len(rows), "suite:", len(cases))  # expect 35 35
print("names match    :", {r[2] for r in rows} == {c['test'] for c in cases})
srs = re.findall(r'^\|\s*(SR-\d{2})\s*\|', Path('MCD-08.md').read_text(), re.M)
print("safety reqs    :", len(srs))                       # expect 28
EOF
```

Expected: 13 documents, 35 criteria matching 35 executed cases, 28 safety requirements.

---

## Optional Check 7 — Reproduce the red baseline

**Not required for review**, and **not to be run inside `source-snapshot/`**. The suite
writes scratch state; run it against a *copy*.

From the package root:

```bash
cd /tmp
cp -a "<package>/source-snapshot/paper-copy-lab" /tmp/run-copy
python3 "<package>/review-package/MASTER_COMPLETION/tools/acceptance_suite.py" /tmp/run-copy
```

`<package>` is the directory this README sits in. The argument is the **project directory**
(`paper-copy-lab`), not the package root and not `source-snapshot/`.

Expected, against this pre-fix snapshot:

```
TOTAL 35  PASS 0  FAIL 35   -> phase=RED
```

**RED is the correct result.** The suite asserts the *absence* of the defects the audit
found; on an unfixed snapshot every criterion must fail. A green run here would mean the
suite is not measuring what it claims. Full instructions, environment notes and the
`unittest` (never `pytest`) requirement are in
`review-package/MASTER_COMPLETION/tools/REPRODUCE.md`.

Cross-version caution: the package's measurements were taken on Python 3.11.2 / SQLite
3.40.1, while the authors used 3.13.16 / 3.46.1. See `MCD-10.md` and limitation GOV-15.

---

## What these checks do and do not prove

**They prove:** the ZIP is intact; every file is the one that was hashed; the package was
built from commit `ad8470c…`; the source snapshot is byte-identical to the sealed archive;
and the dossier's own numbers agree with its own evidence.

**They do not prove:** that the 35 criteria are *correct*, *sufficient*, or *independent*;
that the audit's findings are right; that the safety set is complete; or that CopyLab would
behave correctly in live conditions. Those are judgements only a reviewer can make, and they
are precisely why this package was sent to you.

Verification establishes **provenance and integrity**. It does not establish **adequacy**.

---

## If a check fails

| Failure | Meaning | Action |
|---|---|---|
| ZIP hash mismatch | Corrupt or altered download | Request a fresh copy; do not review |
| `sha256sum -c` reports `FAILED` | A payload file was modified | Stop; report which file |
| A file in `MANIFEST.json` is absent | Incomplete package | Stop; request a fresh copy |
| Source snapshot shows mismatches | Snapshot is not the sealed original | **Stop — this invalidates the review** |
| Dossier counts differ | Dossier inconsistent | Report it; treat counts as suspect |
| Suite exits green | Suite not measuring the defects | Report it; do not treat as a pass |

Report any failure rather than working around it. A package that fails verification is not
reviewable, and discovering that is a result in itself.
