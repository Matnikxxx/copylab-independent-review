# CopyLab — Master Remediation Plan

**Part 18 only · 2026-11-05 · planning artifacts, not implementation authority**

## 1. Decision and current gate

**Gate: BLOCKED.** Phase 0 independent review is unavailable; bounded implementation
approval has not been granted. This planning deliverable does not clear that gate.
Audit 14's technical result remains FAIL. No A14 or H01–H05 issue is verified fixed.
No Phase 1 work has begun. Stop after presenting this plan and the central register.

This plan follows the latest master prompt's numbering and order. In particular,
Phase 1A precedes 1B–1H; source integrity is Phase 2, lifecycle Phase 3, reconciliation
Phase 4, approved wallet-driven paper testing Phase 5, execution Phase 6, strategies
Phase 7, risk Phase 8, dashboard/operations Phase 9 and final audit Phase 10.
The older docs/PHASE_TRACKER.md and Phase 0 report are preserved historical records;
their earlier proposed sequencing is **not** current implementation approval.

## 2. Repository and preservation — freshly checked

- Target: `/home/user/paper-copy-lab`, branch `main`.
- HEAD: `288a69f64c24438cfe69ea176e6f3d6ce7333499`.
- 17 pre-existing modified tracked files, no staged changes, plus important untracked
  source, tests, remediation reports and Audit 14 artifacts. Complete status is retained
  in the new baseline manifest; nothing was reset, cleaned, committed or replaced.
- Previous manifests checked by reading/hashing actual files: original baseline
  **106/106**, remediation **59/59**, Audit 14 evidence **29/29**; zero mismatches.
- New pre-planning baseline: **136 project files**, before new planning artifacts.
- Runtime `data/lab.sqlite`: SHA-256
  `cdbf549d5f39f9cb53a18b7e9fa9aad961083ae4914ca869c72bc705a6c1deb3`.
- Backup `data/lab-verified-backup.sqlite`: SHA-256
  `05749631d7ada4ede38834dec060006c44f4d0e4ed0c2f6df70822ea9ba10c44`.
- Only disposable byte-copies were opened in SQLite, using mode=ro: both integrity ok,
  migration versions [1,2], wallets=0, fills=0, source/copy hashes match. V3 is not applied.
- No WAL/SHM observed. No matching CopyLab application/worker/migration process observed;
  process inventory retained, no signals or process control performed. This inventory
  is not a guarantee against an unrelated concurrent writer starting later.
- Application code, strategy configuration, tests, old reports and evidence unchanged.

New evidence directory:
`docs/master-remediation-planning-2026-11-05/`.
It contains the new manifest, complete status/diff/process inventories, prior-manifest
checks, disposable-copy inspection, artifact inventory and final preservation check.

## 3. Inspection basis and evidence boundaries

Read Audit 14 findings, Phase 0 report, H01–H05 remediation descriptions, stored probe
results and relevant current functions in integrity.py, migrations.py, main.py,
store.py, source_verify.py and audit.py; inspect reproduction/browser scripts and the
existing test inventory. Prior source hashes match, so the archived defects still
refer to the same implementation. This is a planning review, **not** a new full-code
independent audit, a fresh defect reproduction, or a claim that there are no more bugs.

Evidence labels:
- Prior regression: 119 passed, 0 failed/errors/skipped in disposable mirror; this is
  historical evidence, not a suite rerun during Part 18.
- Prior backend probes: 8 defects reproduced, 2 containment checks; prior intercepted
  browser probe: stale green health reproduced. A14-10 was inspection-only.
- Part 18: 0 automated regression/adversarial/browser tests run; no new passed/failed/
  skipped test counts claimed. The 119-case suite and 11 recorded probe scenarios were
  **not rerun**. Fresh hash and read-only copied-schema checks are preservation checks.
- No real wallet observations, forward paper results, calibration or independent audit.
- Do not rerun old evidence scripts in place: they overwrite old evidence outputs.
  Existing HTTP integration tools also start an app; they are not permitted now.

## 4. Phase 0 — obtain a genuinely separate reviewer

Before implementation, a separately identifiable reviewer must inspect actual current
source, tests, reproduction code, all Audit 14 evidence, manifests and this plan/register.
They must independently attempt the nine reproduced defects, investigate A14-10 through
safe disposable concurrency tests, challenge severities and seek additional defects.
They must report each finding as confirmed/rejected/reclassified with their own evidence;
rejection requires a counterexample or demonstrated misinterpretation, not disagreement.
They must assess the proposed order and data-safety prerequisites without editing code.

Deliverable: a new, separately authored reviewer report with provenance, scope, inspected
hashes, exact commands, failures, reproduction results, limitations and recommendation.
No such reviewer tool/process is available in this session. Do not substitute this agent,
a subprocess, a locally written verifier, a synthetic fixture or a different speaking
style for independence. User approval alone cannot supply missing independent evidence.

Phase 0 acceptance requires reviewer assessment, preservation, reviewed remediation
sequence and explicit user approval of the next bounded group. Finding confirmation is
not the same as fixing it: confirmed defects can remain OPEN for approved Phase 1 work.
If review is unavailable, remain BLOCKED; do not start even Phase 1A.

## 5. Common protocol for every future approved group

1. Reconfirm identity, hashes, process/WAL state and explicit group approval; stop on drift.
2. Write group-specific design, affected-file list, risks and test plan **before code**.
3. Freeze a pre-fix source snapshot in a new evidence directory. Reproduce the original
   case there, retaining exact inputs/output/exit codes and desired-invariant failure.
4. Make only approved changes. Any new schema work needs an additive/versioned design,
   compatibility tests and separate runtime migration approval; never touch real DBs.
5. Run focused positive, negative, boundary, crash and related adversarial tests on
   disposable paths with network denied. Use the same pre-fix fixture post-fix.
6. Run regression from an isolated mirror, with runtime data excluded and explicit temp
   paths. Inspect tests first; no implicit data/lab.sqlite defaults. Never weaken guards,
   config, thresholds or assertions. Preserve failures, even if later corrected.
7. Have a separate reviewer inspect actual diff and reproduce before/after cases.
   Arithmetic processes must not import production accounting or validate a summary
   against itself. This separation of code does not make their author independent.
8. Inspect full tracked/untracked diff; rehash old evidence and runtime/backup; inventory
   processes without controlling pre-existing ones. Document every changed file.
9. Produce the mandatory A–H report: scope/exclusions, exact root cause, files/changes,
   commands/counts including not-run cases, before/after evidence, preservation, limits,
   and **one** gate value PASS/PARTIAL/FAIL/BLOCKED. Request explicit approval and STOP.

A defect moves OPEN → IN_PROGRESS → FIXED_PENDING_VERIFICATION → VERIFIED_FIXED only
with relevant acceptance and genuinely separate review. Failed fixes/regressions remain
open and block progression. Required unavailable review/evidence means BLOCKED, not PASS.
Every 1A–1H group has its own stop; approval of one is not approval of the next.

## 6. Phase 1 — proposed bounded groups and pre-implementation test plan

### 1A — SQLite digest and startup ownership (A14-08, A14-10)

Affected: lab/migrations.py table_digests/upgrade_existing; lab/main.py main/App/startup;
lab/store.py initialization/backup; tools/migrate_source.py; disposable migration and
new concurrent-process tests. Inspect every Store/App entry point, not merely CLI main.

Root causes: default=str loses BLOB type; main constructs mutable App/Store before flock,
and its backup branch returns before that worker lock. Design ownership for initialize,
worker, dashboard access, backup and migration as explicit read/write modes with canonical
path treatment. Decide ownership lifetime and exception cleanup before moving code.
Do not require every concurrent read to take an exclusive writer lock unnecessarily.

Tests: original BLOB b'A'/TEXT "b'A'" collision before fix; after fix distinguish NULL,
INTEGER, REAL, TEXT and BLOB using explicit type tags, stable byte encoding, unambiguous
length framing and deterministic row multiset ordering. Compare actual SQLite typeof,
not Python input intentions after column affinity. Cover 1/"1"/1.0, NULL/empty text,
empty blob/text, embedded NUL, large blobs, Unicode, empty tables, composite keys, row
reordering, duplicate rows and type-changing disposable migration. Document REAL bit
encoding, signed-zero/nonfinite behavior and TEXT decoding; include golden vectors.
Preservation claims must distinguish table content from schema/index/trigger coverage.

Prove current lock ordering in a disposable initialization-only harness, with no live
App.run, server or collector. Then synchronized competing processes must show only the
owner can initialize; loser performs no DB/config/schema mutation. Cover new and existing
V3 files, legacy refusal, migration contention, backup semantics, path aliases/symlinks,
exceptions/crash mid-initialize, restart and failed lock acquisition. Check DB+sidecars,
not only a success exit code. No real application/worker or runtime migration.

Gate: storage tests, disposable migration preservation and concurrent-init tests pass;
no unsafe write before ownership; separate review; preservation; STOP for user approval.

### 1B — complete source-journal coverage (A14-02)

Affected: tools/source_verify.py verify, source schema/references, tests/test_integrity.py
and dedicated adversarial verifier fixtures. Production integrity.py is inspected as
producer, not imported to calculate expected values.

Root cause: verifier walks event-reachable rows only. Define required operation, wallet,
provenance, leg/effect and historical-position relationships, then reconcile **all** rows
in both directions. Emit exact row ID and reason for unknown/extra/missing relationships.
A valid closed-out position must not be rejected solely because no live position remains;
verify the historical transition and documented zero-row retention rules. Never synthesize
parents or declare unknown inventory zero. Unsupported semantics must report unverified.

Tests: valid movement, orphan, wrong parent, duplicate identity, missing leg, wrong wallet,
invalid provenance, parent with missing movement, valid+orphan mixture, individually valid
legs forming invalid/unbalanced operation. Include malformed numeric values, extra effect,
wrong token, missing inventory state and deterministic diagnostics. Reproduce archived
orphan (cash/realized=999 ignored) before; same row must fail after. STOP after review.

### 1C — full paper accounting invariants (A14-01)

Affected: tools/audit.py; inspect lab/accounting.py fill/metrics/snapshot, order/fill/ledger/
closed-position schema, settlement records and existing fixture tools. No strategy tuning.

Root cause: replay reconciles cash/fill realized, not ledger realized or complete cycles.
Define authoritative executed paper records and causal links. Independently derive cash,
quantities, costs, proceeds, fees, realized PnL and position cycles using Fraction/Decimal;
compare every expected and stored movement, closed/open state and valuation snapshot.
Reconstruct unrealized/equity from time-appropriate retained mark context, flag unavailable
marks as unverified, and enforce equity = starting capital + total PnL with documented
precision/rounding. Ledger realized cannot validate itself. Unknown correction/settlement
semantics fail closed rather than being reinterpreted as a sale.

Tests: valid buys/sells/partial fills/exits/fees/zero and full closes, then each requested
corruption: realized, cash, deletion, duplication, quantity, cost, partial exit, payout,
orphan accounting, closed→open, negative quantity and rounding boundary. Archive case
999 PnL with unchanged equity must fail. Test orphan orders/fills/ledger and wrong model/
track associations. Coordinated tampering of all causal records is not disproved merely
by internal consistency; authenticity and tamper evidence must be separately scoped.
No claims of calibrated execution. STOP after review.

### 1D — synthetic SPLIT/REDEEM semantics (A14-03, A14-04)

Affected: lab/integrity.py synthetic_event/lifecycle, tools/source_verify.py, lifecycle
fixtures/tests and evidence schema if required. Define explicit symbolic fixture-market
specifications, outcome maps, operation identities, collateral/quantity and payout rules.
They are assumed **test specifications**, not invented contract or blockchain evidence.

Tests: archived single-sided split and 10-share/20-cash redemption first; incomplete and
inconsistent splits, wrong outcome/condition/collateral, fractional quantities, missing
payout/resolution/actual-operation evidence, unproved payout, deductions, duplicate event
and duplicate economic redemption under another ID, restart, resolution-only no cash,
unsupported configuration and fully specified valid fixtures. Check no partial posting
on rejection. Extend independent checker semantics, not only producer arithmetic.
Production admission remains false. Real contract decoding is Phase 3, not this group.
STOP after review.

### 1E — append-only certificate conflicts (A14-05)

Affected: integrity.py synthetic_event, observation/event links and additive schema design.
Root cause: conflict branch changes old state but loses new content when no observation.
Design raw originals plus conflicting payload, receipt time, source/certificate identity,
digest, reason, related batch/observation (explicit absent if unavailable), and resolution
status/history. Preserve raw bytes separately from canonical comparison; no silent winner.

Tests: archive conflict-without-observation; identical repeat; changed value; field order;
missing/extra field; null/empty; numeric representation; repeated conflict; restart; failed
write rollback. Show both raw payloads retrievable and old evidence immutable. Distinguish
semantic equality from byte equality. No retroactive modification of old evidence files.
STOP after review.

### 1F — durable per-attempt transport evidence (A14-06)

Affected: public.py PublicClient.get, integrity.py collect/exception path and transport
schema; explicit immutable request scope before network call. Durability cannot depend
only on get() returning; plan request/attempt start, response receipt and exception paths.
Record attempt/status/headers/body/error, timing/retry-after, completion and redaction.
A crash before persistence may leave outcome UNKNOWN, not a fabricated response.

Tests: two different errors; partial response then timeout; all fail; final success;
restart between attempts; Retry-After seconds/date; empty body; malformed body; subprocess
timeout; write failure. Archive three-failure case must retain all received bodies, not
only last_raw. No secrets, credentials, public wallet collection or actual API requests.
STOP after review.

### 1G — immutable collection scope (A14-07)

Affected: integrity.py collect/frontier/batch model and public.py baseline coordinator.
Define scope schema/hash including wallet, type/API version, time boundaries, market,
archive/dust/size filters and pagination parameters. Distinguish cursor state from scope.
Changed scope must reject or explicitly create an independent batch; pending CLOSED
completion must not masquerade as OPEN completion. Scope-specific frontier semantics
must survive restart. Do not mutate params mid-walk or discard unfinished evidence.

Tests: identical resume; changed wallet/start/end/filter/archive/API version/page config;
crash; partial page; API error; mixing scope A/B; duplicate pages; repeated cursor; missing
terminal page; attempted premature frontier; archive CLOSED→requested OPEN. Verify batch
IDs, raw multiplicity, params and frontier with assertions, not only row totals.
STOP after review.

### 1H — honest health state (A14-09)

Affected: store.py health schema, main.py state, dashboard.html and collector reporting;
add tests without starting actual runtime. Persist/derive last success/attempt, age/TTL,
collection progress, hold/error and freshness/completeness/accounting/audit/readiness
as separate dimensions. Define HEALTHY/DEGRADED/STALE/BLOCKED/UNKNOWN precedence; an
aggregate green cannot override a stale or unknown mandatory component. Correct unsupported
settlement capability wording. Do not imply reachability means trustworthy source data.

Tests: fresh success, stale success, recent failure, no observations, incomplete batch,
wallet hold, unknown source completeness, unavailable DB, stopped worker and reachable
API with stale data. Reuse archived ts=0 browser case; require no green Healthy after fix.
Intercept browser requests with controlled clocks; test API and browser jointly, errors
and refresh failure. Authentication remains Phase 9; do not expose a server now.
STOP after review. Phase 1 overall gate requires every group independently accepted.

## 7. Remaining phases — dependencies and acceptance evidence

| Phase | Scope / expected files | Required verification / external dependencies | Current gate |
|---|---|---|---|
| 2 | Canonical identity, finality, checkpoints, exhaustive inventory and pagination; integrity/public/new adapter/verification tests | Official source capability matrix; real supported identity/chain/contract/block/hash/tx/log evidence, reorg/finality; adversarial missing/late/duplicate/tied pages, inactive/archive/dust/unknown inventory; independent source review. REST terminal cursor ≠ checkpoint | BLOCKED: Phase 1, source capability and approval |
| 3 | All lifecycle types, corrections/reorgs, source/paper isolation; decoder, integrity/accounting/verifier | Verified version-specific operations, all inputs/outputs/collateral/fees/basis; missing legs, overlaps, partial quantities, conversion, transfers and rollback or quarantine; independent semantic + arithmetic review | BLOCKED: canonical identity and real decoding evidence |
| 4 | Full monitoring-gap history/reconciliation, re-enable review, soft removal; wallets/integrity/store/UI records | Short/long gaps with missed BUY/SELL/lifecycle, changed source/paper inventory, restart during reconstruction; no backdated fills or unexplained release; independent review | BLOCKED: complete source history and Phases 0–3 |
| 5 | Approved wallet onboarding and complete traceable source→decision→risk→paper fill→ledger→UI pipeline; wallets/engine/accounting/validation | User supplies wallets ONLY here after explicit approval; every event has reason/outcome; real forward observation coverage, partial/failed exit/settlement/hold/restart and duplicate tests; no success before fill | BLOCKED: Phases 0–4, safety and activation approval |
| 6 | Ideal vs estimated executable model, context, timing/fees/depth/slippage/error; engine/public/validation/execution docs | Forward book/latency measurements, partials/stale/limits/adverse selection and insufficient depth; quantify calibration error/uncertainty, no obtainable-fill guarantee | BLOCKED: approved forward evidence and earlier gates |
| 7 | Five separate $1,000 strategies and ledgers, hypotheses, leakage-safe evaluation; strategies/config/accounting/research docs | Account/risk isolation, training/validation/untouched OOS/forward periods, wallet selection as-of, concentration/correlation/bias; full metrics not single-rank profit claim; independent review | BLOCKED: sufficient legitimate data and earlier gates |
| 8 | Non-bypassable pre-execution risk and durable counters; engine/risk/store/tests | Position/wallet/market/strategy/total exposure, cash, daily loss/drawdown, count/liquidity/spread/age/delay/duplicates/invalid markets; interacting limits and restart; separate review | BLOCKED: earlier gates, existing safety must already hold |
| 9 | Accurate dashboard + authentication/session/CSRF/authorization and operations; main/dashboard/store/public/ops tools | No unauthenticated public exposure; backups AND disposable restore, crash/locking/contention, rate limits, disk/retention/load/soak/graceful shutdown with isolated tests; no actual runtime start | BLOCKED: earlier gates and operational evidence |
| 10 | Fresh whole-system adversarial verification, independent financial/source replay and separate final reviewer | All 45 scenarios from master prompt, every one with setup/expected/actual/logs/DB/accounting/fail-safe result; challenge earlier findings and complete code/security/migration review | BLOCKED: all previous gates and independent auditor |

All phases require fresh pre-implementation test plans and explicit approval, not simply
this table. No public research is performed in Part 18. Later documentation/source
research must be inside the approved scope; wallet queries wait for Phase 5 activation.

## 8. Dependencies, conflicts and decisions needing review

1. **Governance first:** inability to obtain independent review is a hard block, not
   grounds to self-certify or waive Phase 0. No available tool delegates to a separate
   reviewer. User should arrange separate review before bounded implementation approval.
2. **No circular gate:** Phase 0 approves diagnosis/order/scope, not a bug-free bot.
   Requiring all A14 fixes before allowing Phase 1 would contradict the phased prompt.
3. **Risk/auth later than wallets:** Phase 5 cannot operate unsafely while waiting for
   Phases 8/9. First demonstrate existing minimum risk controls; keep tests nonpublic.
   If inadequate, stop and seek an explicitly revised prerequisite scope, not silently
   reorder phases or turn on wallet-driven testing.
4. **Forward data vs calibration:** Phase 5 may establish traceability, not profitable
   performance or calibrated executable PnL. Missing obtainable liquidity/queue evidence
   remains uncertainty through Phases 6/7; it is not cured by more synthetic fills.
5. **Schema changes vs runtime protection:** needed conflict/retry/health records may
   require additive schema versions. Propose compatibility/backfill/recovery explicitly;
   tests use disposable V2/V3 copies. No group approval implicitly authorizes migration.
6. **Startup lock vs readers/backups:** define ownership across CLI, import/programmatic
   startup, backup/migration and dashboard worker; account for lock path aliases and
   concurrency. Do not solve contention by deleting locks or killing existing processes.
7. **Scope-resume vs preservation:** preserve original pending scope but do not substitute
   it for requested scope. Long windows/API-default changes must have explicit identity.
8. **Accounting proof vs missing evidence:** historical context that was never recorded
   cannot be fabricated. Report unknown valuation/lifecycle semantics, not invented fills.
9. **Synthetic semantics vs chain semantics:** fixtures can validate a specified operation
   model; only official, version-specific and observed evidence can validate real decoding.
10. **Regressions vs legitimate fixture updates:** stricter lifecycle validation may reject
    old incomplete fixtures. Preserve their failures; add explicit positive specs and
    negative regressions. Never delete failing cases or relax controls for green counts.
11. **Unavailable canonical completeness:** Phase 2 must remain BLOCKED if sources cannot
    prove coverage. No subsequent dependent operational milestone may be claimed complete.

## 9. Local verification versus external proof

Locally testable after approval: storage encoding, lock/concurrency/crash behavior,
referential coverage, exact accounting/rounding, immutable conflict/attempt/scope handling,
synthetic operation semantics, browser freshness and isolation/risk primitives. Local
correctness still needs separate review before VERIFIED_FIXED.

External or mixed evidence: supported canonical identity/completeness and finality;
version-specific actual lifecycle coverage; complete real gaps; approved wallet forward
history; execution calibration/obtainable liquidity; statistically adequate untouched
strategy evaluation; independent auditor. No synthetic proxy may clear these gates.

Milestones remain separate: A engineering complete (no HIGH/unreviewed accounting defects),
B trustworthy paper operation (real verified source and forward history), C performance
(evidence adequate for isolated strategies), D operations (auth/restore/monitoring/load).
All are currently BLOCKED, not complete. Real-money capability is permanently prohibited.

## 10. Required future documentation and runtime gate

Maintain central register without deleting findings; append dated evidence and reviewer
sign-off links. Produce/maintain AUDIT, REMEDIATION_REPORT, ARCHITECTURE, FORWARD_REPORT,
JOURNAL, CONTINUE, STRATEGIES, EXECUTION_MODEL, DATA_INTEGRITY, OPERATIONS and
FINAL_VALIDATION as corresponding implementation becomes real; do not document planned
features as implemented. Old audit evidence remains immutable.

Before any actual migration/runtime activation: a separate approval request must prove
correct path, all app/workers stopped without assumption, a new verified backup, counts/
typed digests, disposable migration, preserved legacy content, rollback/restore and recovery
procedures. User must explicitly approve that specific operation. Current prompt grants
none of these runtime actions, and no wallet addresses are needed now.

## 11. Part 18 completion / requested next decision

Created only this plan, MASTER_DEFECT_REGISTER.md and a fresh evidence directory. Fresh
preservation checks are in preservation-final.json; exact baseline hashes/status/diff and
copied-DB inspection are retained. No code/test/config/old-document change, app/worker
startup, migration, network/wallet request, commit/push/deploy or phase progression.

**STOP. Please review the plan and defect register.** Arrange genuinely separate Phase 0
review and approve its remediation sequence, then explicitly approve only the next bounded
scope (proposed: Phase 1A). Until those conditions hold, Phase 0 remains BLOCKED and no
implementation will begin. Approval of planning artifacts alone is not permission to fix.
