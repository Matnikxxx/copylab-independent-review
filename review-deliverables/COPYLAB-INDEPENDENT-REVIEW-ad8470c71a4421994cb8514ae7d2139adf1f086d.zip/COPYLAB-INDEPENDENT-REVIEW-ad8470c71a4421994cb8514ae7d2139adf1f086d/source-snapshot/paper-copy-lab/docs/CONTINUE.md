# Exact continuation instructions

Repository: `/home/user/paper-copy-lab`. Runtime DB: `data/lab.sqlite`. Expected branch: `main`. No remote repository is configured. Do not touch any other user projects or enable real trading.

1. Read README.md, ARCHITECTURE.md, AUDIT.md, COMPLETION_REPORT.md and latest test/forward evidence. Verify `git status` and current commit. Preserve the existing DB and `.git` history.
2. Run `python3 -m unittest discover -s tests -v` (latest checkpoint: 52 passing) and `python3 tools/fixture_validation.py` (500 synthetic fills replayed by separate Fraction verifier). Do not delete old failed logs.
3. Check existing preview/worker before starting another. Single-worker DB lock blocks concurrent normal startups. Start `python3 -m lab.main --port 8080` from repo if none running. Python optional browser packages and OS libraries may need reinstalling after workspace restore; runtime itself needs only stdlib + curl.
4. **Prioritize H01/H02:** research authoritative per-log source IDs/block ordering and a block-consistent inventory checkpoint using current official APIs/on-chain public sources. Do not invent log indexes. Quarantine ambiguous same-second/multiple identical fills until independently reconciled. Verify provider freshness. Quiet baseline is not an atomic checkpoint.
5. **H03/H04:** implement persisted source lifecycle state machine (splits/merges/redemptions/conversions), inventory provenance and reorg correction. Distinguish paper holdings from source holdings. Reconcile disabled/failed intervals without retroactively fabricating executable entry fills. Verify zero/fractional payouts cannot be applied twice. Preserve working accounting and add targeted integration fixtures.
6. Expand property/fuzz tests for quantization extremes, many partial sells, unsupported fee schedules, paginated interrupted collection, clock skew, HTTP 429/Retry-After/5xx, crash during commit, late-indexed trades and simultaneous source events. Independent replay should compare each closure too, not only aggregate inventory/cash.
7. Improve dashboard lifetime pagination/export and stale-valuation ranking suppression. Add authenticated deployment controls if exposed beyond trusted preview. Parameter changes must go through stopped-worker `tools/configure.py`; never reset balances to avoid migration.
8. Request actual user-supplied Polymarket proxy-wallet addresses **when ready to validate**. Never substitute arbitrary public wallets. No real credentials are necessary or accepted. Add supplied addresses through dashboard; observe baseline admission and health. Full live wallet behavior has not been verified.
9. Arrange a separate auditor/human or separately instructed agent with full specification and repository. Give it no expectation of passing. Record independent findings/evidence/remediation/retests; current standalone arithmetic verifier is not external sign-off.
10. Run a meaningful multi-day forward paper window with matched evaluation dates and predefined minimum events/sample requirements. Record exact achieved interval, API gaps, price/fee evidence, accepted/blocked decisions, model-specific samples, realized/unrealized and liquidation-mark caveats. Never fabricate fills or claim profitability from zero/small samples.
11. Before final acceptance: rerun all tests, verify DB restore and source-event reconciliation, audit the dashboard against full-ledger SQL, resolve all confirmed critical/high findings, collect independent sign-off, and regenerate forward report. Update the completion matrix honestly. Preserve recoverable Git commits and a source bundle.

Current unresolved work is substantial; user wallet addresses alone will not make the project complete. Treat this as a tested development checkpoint, not a deployment-ready trading bot.

---
# Superseding continuation after coordinated H01–H05 remediation

HEAD remains 288a69f; changes intentionally UNCOMMITTED. Do not discard working-tree
remediation. Read REMEDIATION_REPORT.md and remediation/manifest.json first. All new
artifacts/tests are evidence preparation, not external audit or forward results.

Runtime worker has been stopped and must not be restarted under old assumptions.
Runtime DB remains version 2, no migration applied. New application refuses it before
schema writes. Do NOT delete/reset it. Back up independently before any future action.

Reproduce controlled tests (no accounts/network):
  python3 -m unittest discover -s tests -v
  python3 tools/remediation_evidence.py
  python3 tools/fixture_validation.py
  python3 tools/http_check.py --out <new-evidence-path>
Optional: python3 tools/remediation_browser.py (Playwright required; intercepted only).
Preserve old logs rather than overwriting them when producing new evidence.

A separate auditor must review code + docs + raw fixtures, reproduce rollback and
replay checks, challenge synthetic-only assumptions, verify contract/RPC coverage,
block-consistent balances and authoritative ordinary fill mappings. Do not arm copying
by editing allowed(), setting SQL state='verified', or relabelling production data.
No production verifier/adapter or auto-release mechanism exists by design.

If/when an operator separately authorises migration, STOP every writer; use:
  python3 tools/migrate_source.py --db <existing-copy> --backup <new-backup> --evidence <new-json>
First use a disposable copy and review digests/holds. Actual runtime was not migrated
in this task. Migration preserves all old rows; adds quarantine/holds/gaps. It does not
certify legacy baselines or automatically reconcile positions.

Next priority: verified complete source adapter + separate audit. Only after that,
request actual user wallet addresses and explicit observation-only validation approval.
Controlled paper copying is currently BLOCKED. H05 requires real user-supplied-wallet
observations, adequate history and evaluated execution/restart/lifecycle behaviour;
synthetic success or source freshness alone cannot close it. Never deploy/push/commit
without new authorisation.
