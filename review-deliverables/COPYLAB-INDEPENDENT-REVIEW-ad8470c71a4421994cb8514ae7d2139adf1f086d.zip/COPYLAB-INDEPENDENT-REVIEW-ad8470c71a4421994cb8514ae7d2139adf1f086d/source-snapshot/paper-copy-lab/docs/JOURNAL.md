# Development journal

Work occurred in the session dated 2026-11-05 Africa/Johannesburg. Evidence timestamps are stored as UTC epoch / ISO UTC rather than fabricated stage timing.

1. Verified `/home/user` was empty and Git/Python/curl available. Initialized new `/home/user/paper-copy-lab`; no existing project read or reused.
2. Researched official docs index and v2 migration/OpenAPI. Live time/Gamma/v2 trades worked; v1 positions explicitly retired. Old guessed documentation URL 404'd; used official index instead. urllib CLOB market read got 403; fixed-origin curl public reads worked.
3. Implemented SQLite WAL/FULL persistence, transaction context, audited wallet registry and configuration, read-only upstream client, retries/cursors, books/markets/health storage.
4. Implemented five entry-rule objects, ten ledgers, ideal counterfactual and causal post-latency depth simulation, mirror sells, entry/execution risk checks and model exits.
5. Implemented cash/cost/realized/unrealized accounting and snapshots; later added full closed-position cycles rather than partial-fill win rate. Added idempotent zero/fractional payout handling based on public token finality.
6. Added responsive standalone dashboard with overall comparison, model pages, wallet management/performance, observation/decision/order visibility, audit trail and component health.
7. First 21 tests exposed partial-depth fixture/risk interaction. Retained failing evidence and corrected fixture rather than removing liquidity risk control.
8. Review found source-inventory and B bootstrap failures. Added quiet double-read baseline, public source performance, lifecycle containment, rebaseline on enable and mismatch quarantine. These mitigate but do not complete chain reconciliation.
9. Expanded to 44 tests. Two fixture-isolation failures and a zero-string formatting mismatch were corrected with their historical logs preserved. Added eight more regression tests (52 total) for independent exits, depth reuse, repeated execution and paper-mode validation.
10. Added standalone Fraction verifier. Replayed 500 explicitly synthetic fills across ten worlds after backup/restore; no mismatches. Production DB had zero fills; not treated as an execution audit.
11. Launched real-data sentinel/worker and dashboard. Restarted process against the same DB without resetting financial state. Updated persisted config with stopped-worker configure tool; audited the change.
12. Installed optional Playwright. First Chromium launch failed on missing OS libraries; installed browser system dependencies. Desktop/mobile smoke checked all nine pages: no JS errors, no mobile document overflow. HTTP integration tested validation/CSRF/add/disable/soft-remove on a disposable DB with upstream collection stubbed out.
13. Documented architecture, config, schema, strategies, audit register, acceptance gaps, exact continuation and actual forward data window. No strategy winner or project completion claimed. Production wallet list remains empty by design.

## Stage assessment

Research / architecture / foundation / core accounting: implemented with stored evidence.
Trading / models / dashboard / integration: substantial implementation and synthetic verification; lifecycle and real-wallet acceptance still incomplete.
Independent audit: partial independent-process replay, **not** requested independent third-party sign-off.
Remediation: multiple confirmed issues fixed and regression-tested; open H01–H05 and M findings remain.
Forward validation: real public-data observation only; user-wallet forward copying blocked by absent addresses and unresolved lifecycle guarantees.
Final verification: incomplete, explicitly recorded in COMPLETION_REPORT.md. Preserve checkpoint and continue; do not present this as a completed lab.

---
# Coordinated remediation journal — H01–H05

Reference inspected: main, 288a69f64c24438cfe69ea176e6f3d6ce7333499; initially clean.
No commit/push/merge/PR/deployment authorised or performed.

1. Inspected original schema, capture, admission, event hashing, source denominator,
   monitoring, strategies and tests. Stopped old preview worker gracefully to prevent
   continued legacy writes; did not launch new code against runtime data. Recorded
   post-stop runtime file hashes. No user-wallet/API requests.
2. Wrote remediation/DESIGN.md before schema implementation. Additive migration 3,
   explicit verified backup/lock/content checks; actual runtime not upgraded.
3. Implemented durable raw batches/pages/deliveries/observations with retained
   multiplicity, recovery and terminal capture frontiers. REST baselines unverified,
   no atomicity inferred. Added status freshness gate and removed invalid CLOSED filter.
4. Separated source observations, synthetic evidence certificates, economic copy
   events and local IDs; exposed ambiguity flags, no production hash ordering/dedup.
5. Typed explicit source legs and effect overlap protection; source and paper cash
   separate. Pure conversions carry cost; unsupported economic allocation or unknown
   operation/correction blocks. Official contract/lifecycle docs archived separately;
   no RPC/ABI completeness certification or invented chain fields.
6. Recorded monitoring gaps/reconciliation and paper holds. Enable/remove preserve
   evidence; no retrospective fills, no overwrite of unknown source balance with zero.
7. Existing 52 tests: first attempt had 2 API fixture errors (old baseline helper only
   implemented pages()). Retained failure log, updated those tests to full get()
   envelopes and asserted stronger quarantine, with source quantity retained as raw.
   No strategy/risk thresholds weakened or tests removed.
8. Added 61 focused tests (113 total initially) covering failure/recovery, identity,
   lifecycle, gaps, migration, independent replay and forward classification. Extended
   after review; final command/results in remediation/tests-final.txt and report.
9. Independent Fraction paper verifier replays 500 synthetic fills; separate source
   verifier replays 10 typed fixture operations against explicit 3/2 source realized
   result and tests tamper detection. Repeated output deterministic. Neither verifier
   imports production accounting, but neither is a separate auditor.
10. Disposable HTTP tests and fully intercepted browser fixtures check controls/9 pages
    without production deployment or upstream wallet calls. Historical reports/evidence
    preserved; all new evidence under docs/remediation.
11. Prepared reproducible migration/forward export/auditor instructions, source hashes,
    finding status and residual blockers. Runtime kept at legacy schema, unchanged
    since post-stop snapshot. No claims of market performance or production readiness.
