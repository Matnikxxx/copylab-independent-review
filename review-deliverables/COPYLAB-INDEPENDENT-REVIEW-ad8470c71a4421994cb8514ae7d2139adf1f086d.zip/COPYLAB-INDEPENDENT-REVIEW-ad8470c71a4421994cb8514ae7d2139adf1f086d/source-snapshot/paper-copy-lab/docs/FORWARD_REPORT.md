# Forward public-data observation report

Generated: 2026-11-04T23:16:56.861507+00:00

- First real public order book: **2026-11-04T23:06:43.236895+00:00**
- Last included public order book: **2026-11-04T23:16:45.751151+00:00**
- Sampled first-to-last span: **602.51 seconds** (NOT uninterrupted runtime)
- Maximum sample gap: **15.63 seconds**; application restarted during development.
- Public order-book observations: **42**, distinct sentinel tokens: **1**.
- Ten-world portfolio snapshots: **420**.
- User wallets registered: **0**.
- Observed wallet events: **0**.
- Actual production paper fills: **0**.

This is real Gamma/CLOB/Data public connectivity and repeated sentinel observation evidence, not evidence of profitable copying, obtainable executions, or successful source-wallet lifecycle monitoring. No arbitrary wallet was added. Capital remains unchanged because there were no copied trades. Synthetic accounting tests and 500-fill verifier stress data are strictly separate from production.

Raw live books remain in `data/lab.sqlite`. The payload hash and component health included in `forward-evidence.json` support reproducibility of this report. The worker may continue collecting after this report's cutoff; regenerate via `python3 tools/forward_report.py` for an updated cutoff.

## Required next validation

Supply proxy-wallet addresses. Record at least a meaningful multi-day forward window with enough copied buys, partial/full source sells and model exits across all models; predefine minimum sample and confidence criteria rather than choosing a winner after seeing outcomes. Exercise lossless restart, actual API failures, rate limits and source lifecycle events. Independently reconcile observed prices, causal due-time books, fee schedules, settlements and accounting. No fixed duration alone establishes profitability.

---
## H01–H05 remediation validation status

No additional real wallet-driven forward run was performed. Historical sentinel
results above remain historical and do not validate the modified code. Runtime worker
was stopped and not redeployed. No wallets/accounts were queried or supplied.

`tools/export_validation.py --db <migrated-db> --out <new-evidence.json>` is read-only
and exports raw arrivals/pages/provider order, event links, decisions, due/fill times,
latency/null unavailable timings, ideal/executable snapshots and ledger PnL, book
spread/depth evidence, fees, quantities/partial/rejected order state, source payouts,
reconciliation/gaps/holds. Raw book levels allow spread/depth to be independently
recomputed; missing measurements remain missing, never substituted. Full export has
no retention cap and should be protected for wallet data/privacy when real use begins.

Readiness is explicitly false while the canonical adapter is absent. A production
classified EMPTY DISPOSABLE DB export is in remediation/empty-forward-readiness.json;
it is a workflow test, not real forward performance. The source fixture export is
labelled synthetic and contains no paper fills or market performance claim.

User wallet addresses alone cannot make this build eligible to copy. First obtain a
separate audit and verified complete checkpoint/event adapter. Then obtain user
addresses, migrate a verified backup under operator control, collect observation-only
checks, and evaluate source completeness/restarts/lifecycle before copy execution.
H05 remains open in substance (PARTIALLY RESOLVED preparation), not externally audited.
