# Coordinated H01–H05 remediation report

## Verdict and reference

**Safety remediation implemented, with explicit external-evidence blockers. Production
copying remains blocked. This is not production-ready, profitable, independently
audited or forward validated.** No finding is marked RESOLVED merely because it blocks.

Repository `/home/user/paper-copy-lab`, branch `main`, reference/current HEAD
`288a69f64c24438cfe69ea176e6f3d6ce7333499`. Initially clean. Changes remain UNCOMMITTED
as required. No push/merge/PR/deployment. Existing preview worker was stopped gracefully;
new application was NOT started against runtime. No user accounts/wallets queried.

## Finding-by-finding status

| Finding | Original problem | Changes made | Tests / evidence | Remaining limitation | Final status |
|---|---|---|---|---|---|
| H01 | No shared atomic/exhaustive checkpoint; premature watermark; late/boundary loss; filtered positions | Durable raw pages/rows/delivery/cursor batches; terminal-only capture frontier; resumable incomplete batches; no timestamp source watermark/admission; explicit unverified baseline evidence; freshness checks; valid CLOSED request; missing inventory not zero | IntegrityTests failure/restart/boundary/completeness/filter/status tests; migration-evidence.json | REST still cannot prove a complete source cut, inactive/dust coverage or late-insert completeness. Wallet remains quarantined; needs audited canonical block/receipt/balance adapter | PARTIALLY RESOLVED |
| H02 | Economic hashes collapse fills; arbitrary tied order | Production observations never become economic events via hashes; row multiplicity/provider order retained; canonical numeric key for grouping only; ambiguity flags; fixture certificates separate; conflict/order/reorg containment and future event links | Identity, numeric, same-second opposing, cursor overlap, conflict, duplicate evidence tests; independent raw page invariants | Ordinary APIs expose no supported unique log identity/order. No decoded opaque cursors or invented source fields. Production adapter must prove per-event attribution | PARTIALLY RESOLVED |
| H03 | Lifecycle inventory incomplete and double-counting risk | Explicit evidenced BUY/SELL/SPLIT/MERGE/REDEEM/RESOLUTION/CONVERSION/NEG_RISK/COMBO/TRANSFER legs, source cost/cash journal, effect/transfer uniqueness; pure conversion basis carry; unknown/corrections and unsupported allocation quarantine | Typed synthetic cases plus 10-operation independent Fraction replay; expected cash and realized both 3/2, ending zero inventory | No certified full contract/ABI/RPC history or real decoder; complex conversions/reorg rollback not implemented. Production observations cannot mutate source or paper ledgers | PARTIALLY RESOLVED |
| H04 | Disable/rebaseline misses exits and leaves false paper holdings | Monitoring history, gaps, baseline versions, last complete batch/source checkpoint fields; enable requires review; separate source/paper comparison evidence and holds; soft removal retains history; no retrospective fills | Gap, short/long enable, missed SELL/MERGE, missing history, paper mismatch/removal tests; migration adds holds for old positions | No trustworthy source history to reconstruct a real gap. No automatic release; requires complete source reconstruction and operator/auditor review, not a fresh REST snapshot | PARTIALLY RESOLVED |
| H05 | No separate audit or actual-wallet forward observations | Reproducible evidence package, independent source/paper Fraction verifiers, migration safety tests, raw forward export and explicit readiness false | 119 tests; paper-replay.json (500 fills), source-replay.json/repeat (10 typed events), HTTP and browser evidence | Third-party auditor absent, wallets not supplied, actual forward source/execution/restart/lifecycle behaviour not evaluated | PARTIALLY RESOLVED |

## Implementation boundaries

### Durable source capture

Collection creates a persistent batch with fixed parameters/window. Every accepted page
and all row ordinals commit atomically with next cursor. Terminal capture frontier
commits in that same transaction, never ahead of raw rows. Interrupted batches remain
incomplete with error/cursor and resume original parameters after reopening. Failed
responses, retry evidence and raw multiplicity remain inspectable. Missing/inconsistent
pagination is NOT a terminal empty result.

A capture frontier certifies **durable received pages only**, never chain completeness.
Late inserts behind traversed cursors cannot be proven covered; subsequent walks start
from original monitoring boundary, not a moving 300-second local overlap, but still
cannot arm the wallet. Unsupported historical availability/rate/scale must not be
mistaken for completeness. No processing watermark is advanced for unverified source.

### Baseline / freshness / filters

All REST baselines are explicitly unverified, with batch references, status, scope and
integer-boundary limitations. No two-read matching rule or overwrite of source_positions.
Data status age, computed time, chain/progress and serving mechanisms gate health;
freshness is not checkpoint proof. Positions request scope explicitly includes archives
where permitted, asks for token floor 0, and still records that dust semantics/inactive
coverage are incomplete. CLOSED no longer sends include_archived. Missing rows remain
unknown, not zero. No integer-second source record can silently cross into inventory
when excluded from copying; production observations never reach that mutation path.

### Identity / lifecycle / continuity

Synthetic certificates are explicitly labelled local test evidence; no chain block,
log or transaction position is fabricated. Synthetic environments cannot start the
application or relabel production DBs. Ordinary observations are retained and tagged,
including identical-looking rows. A provider cursor position is not a canonical order.

Source transformations require all evidenced legs, explicit cash/basis and effect
provenance. Pure conversion carries basis rather than inventing a realized loss.
Resolution alone neither removes inventory nor pays cash. Redemption and transfer
underlying effects cannot apply twice. Unsupported/corrected/reorg evidence holds the
wallet instead of silently reversing past accounting. Source ledger and paper ledger
remain separate. New source information during gaps never creates a backdated fill.

## Files changed

Implementation:
- `lab/integrity.py` (new): raw capture/admission, identity separation, lifecycle and holds.
- `lab/migrations.py` (new): additive migration 3, explicit backup/digest/rollback checks.
- `lab/validation.py` (new): read-only forward evidence representation, null missing metrics.
- `lab/public.py`: durable collector, Data API status, no unsafe admission/invalid filters.
- `lab/store.py`: new-DB v3; existing DB refuses implicit migration; synthetic marker.
- `lab/engine.py`: fail-closed ingress/process/execute/exit/settlement, fixture certification.
- `lab/wallets.py`: monitoring/gap/reconciliation recording and pending action cancellation.
- `lab/main.py`, `lab/dashboard.html`: integrity status/holds visible; synthetic DB startup refusal.

Tests/tools:
- `tests/test_integrity.py` (new); `tests/test_lab.py` (original 52 retained).
- `tools/source_verify.py`, `tools/remediation_evidence.py`, `tools/migrate_source.py`,
  `tools/export_validation.py`, `tools/remediation_browser.py` (new).
- `tools/audit.py`: read-only DB, explicit environment classification; independent arithmetic preserved.
- `tools/fixture_validation.py`: explicit synthetic DB and new output path, preserving old evidence.
- `tools/http_check.py`: selectable evidence output, preserving old evidence.

Documentation: this report; append-only updates in AUDIT, ARCHITECTURE, FORWARD_REPORT,
JOURNAL, CONTINUE and README. New `docs/remediation/` contains design, official extracts,
onchain capability assessment, all new logs/evidence and file manifest. Exact file
paths/hashes are in `docs/remediation/manifest.json`; existing strategies/config and
accounting module remain unchanged.

## Migration and runtime preservation

Migration 3 adds only new tables; it does NOT reset balances or rebuild runtime data.
Legacy positions/events/fills/ledgers/config and original audit rows remain unchanged.
New quarantine/gap/hold records cover legacy inventory. Existing DB startup refuses
migration before PRAGMA/schema writes. Explicit migration requires stopped worker lock,
new verified online SQLite backup, integrity check and before/after old-table digests;
DDL is transactional. Error rolls back new tables/version; backup remains available.

Tests demonstrate additive row preservation, rollback and refusal to auto-upgrade on
DISPOSABLE legacy fixtures. `migration-evidence.json` records backup verification,
versions 1/2/3 and preservation digests, plus a held legacy paper position.

**Actual runtime database was not opened by Store, migrated, reset, overwritten or
recreated in this programme.** After graceful old-worker shutdown, its SHA-256 remained:
`cdbf549d5f39f9cb53a18b7e9fa9aad961083ae4914ca869c72bc705a6c1deb3`.
Existing prior backup remained:
`05749631d7ada4ede38834dec060006c44f4d0e4ed0c2f6df70822ea9ba10c44`.
See runtime-preservation.json. Graceful shutdown may flush old WAL normally; no claim
is made that its pre-shutdown main-file bytes were identical. It was not restarted.

## Tests and exact results

Command:
```
python3 -m unittest discover -s tests -v
```
Final full transcript: `docs/remediation/tests-final.txt`.
**119 run; 119 passed; 0 failed; 0 errors; no skipped/disabled tests.**
52 original strategy/accounting tests retained; 67 focused tests added. Original
fixtures now explicitly mark disposable DBs synthetic. Two original baseline tests
were strengthened to require raw current_size preservation/quarantine, not unsafe
admission. First attempt: 50 passed/2 API fixture errors; retained tests-attempt-1.txt.
Tests-attempt-2 through subsequent numbered logs are retained. No risk/strategy
threshold, configuration or old financial test was weakened/deleted.

Additional commands (all controlled disposable fixtures, no user data):
```
python3 tools/remediation_evidence.py
python3 tools/fixture_validation.py
python3 tools/http_check.py --out docs/remediation/http-evidence.json
python3 tools/remediation_browser.py
```
- Independent source Fraction replay: 10 operations, expected source cash=realized=3/2,
  zero ending inventory and zero errors; two identical deterministic reports.
- Independent paper Fraction replay: 500 fills / 10 worlds after backup/restore; zero errors.
- Both verifiers avoid production accounting imports; tampered source inventory test fails as expected.
- Disposable HTTP checks pass; no upstream wallet requests.
- Browser: all nine pages pass under intercepted fixtures; zero JS errors, no mobile overflow.

These independent algorithms were authored within this same remediation session.
They are **not** a genuinely separate auditor or real forward validation.

## Remaining limitations and required evidence

1. **Atomic complete source baseline:** ordinary REST cannot certify it. All real
   copying blocked. Need exhaustive block-consistent balances, covered token/contracts
   and finalized event boundary with documented provider/RPC guarantees.
2. **Ordinary fill identity/ordering:** no supported per-row log ID. All ambiguous raw
   observations retained/quarantined. Need receipts/logs with chain/block hash, log/item
   identity and reliable wallet/fill attribution, including corrections/reorg handling.
3. **Lifecycle coverage:** pure evidenced fixture legs work; full real decoding and
   complex cash-generating conversions/reorg rollback not certified. Unknown mappings
   blocked. Need versioned ABIs/contracts, deployment/checkpoint history, archive range
   coverage, transfer/lifecycle mapping and verified basis policy.
4. **Monitoring gap recovery:** missing history cannot be reconstructed by assertion.
   Positions remain held for review. Need full source interval and separate paper
   reconciliation; missed SELL does not imply successful historical paper execution.
5. **Execution evidence:** exporter preserves books, fills, due/arrival times and nullable
   metrics, and new executable fills retain exact book context atomically. Old fills lack
   that link; candidate book IDs are explicitly not proof of consumption. Need calibrated
   latency/depth/fee/finality assumptions before executable realism can be certified.
6. **Separate audit/forward:** absent auditor and supplied wallets. No new real forward
   claims. Need independent review, then user addresses and controlled observation
   approval; evaluate real completeness, execution, restart and lifecycle behaviours.
7. **Operational scale:** full-history walks and ambiguity grouping are conservative,
   not optimized for high volume; no volume/retention/SLA certification. Fail closed on
   limits/errors. Need sustained load, provider bounds and safe retention review.

## User-facing answer

The source-data failure modes now block rather than silently inventing confidence.
CopyLab is **NOT yet safe to begin wallet-driven paper copying**. Controlled synthetic
validation is ready and passed. Do not supply credentials. Next action: arrange a
separate auditor to reproduce this package and review a canonical source adapter plan.
Keep runtime stopped/unmigrated until migration/deployment is separately approved.
