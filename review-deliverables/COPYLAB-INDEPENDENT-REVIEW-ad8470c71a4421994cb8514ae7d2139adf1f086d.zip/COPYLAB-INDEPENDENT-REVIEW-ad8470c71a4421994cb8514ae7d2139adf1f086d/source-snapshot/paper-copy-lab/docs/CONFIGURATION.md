# Configuration reference

All amounts are virtual USD; prices are [0,1] per outcome share. Decimal-like settings are JSON strings to avoid float inputs in accounting. Strategy sample counts and cycle settings are numbers.

| Setting | Default | Meaning |
|---|---:|---|
| paper_only | true | Mandatory; cannot enable real trading |
| starting_capital | 1000 | Per model per counterfactual track, immutable for existing run |
| poll_seconds | 15 | Target cycle interval; slow I/O may extend it |
| detection_latency_seconds | 2 | Additional delay after event arrival, on top of actual source-to-detection delay |
| execution_latency_seconds | 2 | Executable due-time delay; actual execution waits next suitable book, so can be ~one poll later |
| max_event_age_seconds | 180 | No copying old source events as if current; executable book wait timeout |
| book_max_age_seconds | 30 | Book freshness and stale-mark flag threshold |
| copy_fraction | 0.02 | Fraction of source observed buy notional |
| max_copy_amount | 25 | Scheduling buy-notional cap; fee-inclusive risk recheck may reject at cap |
| max_position | 100 | Remaining cost cap per token across wallets in this model/track |
| max_wallet_exposure | 250 | Remaining cost cap per source wallet |
| max_market_exposure | 150 | Remaining cost cap per condition id (all outcomes) |
| max_portfolio_exposure | 700 | Remaining cost cap across portfolio |
| max_daily_loss | 50 | Marked equity drop versus first snapshot in UTC day |
| max_drawdown | 0.15 | New entry circuit breaker from marked peak |
| minimum_liquidity | 20 | Total displayed ask notional; not a guarantee inside execution price band |
| maximum_entry_price | 0.95 | Absolute executable buy price limit |
| max_price_deviation | 0.05 | Absolute per-share move versus reference accepted by depth walk; applies to sells too |
| max_trades_hour | 20 | Recent simulated-order rate per model/track; rejected orders also count |
| depth_participation | 0.10 | Maximum simulated share of each displayed book level per world/book |
| models | A–E | Separate name, stop, profit, and qualification/risk overrides; see STRATEGIES.md |

No environment variables or signing secrets are needed. Runtime JSON is persisted and must match on restart. To change non-capital configuration: stop worker, edit JSON, run `python3 tools/configure.py`, restart. This writes an audit record with old/new config. It does not rewrite old decisions or fills. In-progress historical experiments should generally retain frozen strategy parameters; start a new DB to compare parameter experiments without mixing regimes.

Advanced simulation assumptions still fixed in code: fee exponent=1 support, immediate verified-token settlement, eight-place half-even quantization, 300-second overlap, 60-second quiet baseline, 300-second wallet-performance refresh and fixed retry count. These are documented limitations, not fully configurable features.
