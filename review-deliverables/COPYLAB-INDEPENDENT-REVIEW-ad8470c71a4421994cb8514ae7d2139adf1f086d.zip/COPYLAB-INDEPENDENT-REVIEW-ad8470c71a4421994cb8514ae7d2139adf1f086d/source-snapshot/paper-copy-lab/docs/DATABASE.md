# SQLite schema, migrations, recovery

Database: `data/lab.sqlite`, WAL mode, synchronous FULL. Financial amounts are decimal text. No exchange credentials are stored. Runtime DB and online backup are excluded from Git but persist as workspace files.

| Table | Role |
|---|---|
| migrations | Version 1 initial schema; version 2 adds closed position cycles. Both migrations are additive/idempotent |
| settings | Persisted run config, per-wallet inventory admission metadata and public source-performance snapshots |
| wallets | Registry, soft removal, enable state, activity watermark, last successful poll |
| audit | Timestamped registry/config/quarantine/resolution records |
| events | Raw upstream trade plus normalized identity, detection/source clocks, processing/quarantine state |
| source_positions | Shared source inventory denominator; NOT paper portfolio inventory |
| books | Raw public bid/ask levels with local arrival timestamp |
| markets | Market/token mapping, title, raw Gamma metadata, observed fee schedule |
| decisions | One accepted/blocked decision per source event/model/track |
| orders | Independent local paper intents, due times, rejection and fill/partial/settlement state |
| fills | Actual simulated quantity, price, fee, signed slippage and realized PnL |
| ledger | Reproducible cash, cost, realized and fee movements linked one-to-one to fills |
| positions | Remaining shares/cost by model/track/source/token |
| closed_positions | Fully closed cycles aggregating all partial exits, cost/proceeds/PnL |
| snapshots | Time series metrics and equity; maximum drawdown/peak persistence |
| health | Last observation of each component; timestamps must be checked for staleness |

Primary uniqueness prevents ordinary replay duplication. There are no destructive migrations. `Store.tx` serializes worker/UI access; order/event status is rechecked inside mutations. One worker per DB enforced by OS lock at application startup. Do not launch multiple writers bypassing that entrypoint.

Backup: `python3 -m lab.main --backup data/backups/<name>.sqlite`. The backup API is safe with the main worker running. Verify via Python sqlite3 `PRAGMA integrity_check` and `tools/audit.py --db <backup>`. Restore only with worker stopped, to a new filename; preserve old evidence. Unit tests verify backup and restarted accounting; synthetic independent replay additionally verifies 500 fills after backup/restore.

Known persistence limits: no automatic off-host backups/scheduler, retention/pruning/compaction, high-volume load certification, schema downgrade, source-chain reorganization rollback, or accounting corrections workflow. Startup uses CREATE IF NOT EXISTS migrations; replacing tables across future breaking versions needs a real ordered migration script. Never alter past financial rows manually to make tests pass.

---
## Migration 3 — coordinated source-integrity remediation

Existing schema 2 files refuse automatic startup migration. Explicit
`tools/migrate_source.py` requires a stopped worker lock, new backup destination,
verified online backup and old-table content digests. It applies all new tables/version
atomically; failures roll back. Actual runtime was not upgraded. Temporary legacy
migration/rollback tests pass; new gap/hold records do not rewrite old financial rows.

New tables separate capture, observations/flags, baseline evidence, verified source
provenance, source-only effects/journal, monitoring/reconciliation and paper holds.
`execution_context` additionally links each NEW executable fill to exact book ID,
arrival/spread/depth/reference in the same fill transaction. Old fills retain unknown
context, not invented/backfilled books. Full schema is in lab/migrations.py.
