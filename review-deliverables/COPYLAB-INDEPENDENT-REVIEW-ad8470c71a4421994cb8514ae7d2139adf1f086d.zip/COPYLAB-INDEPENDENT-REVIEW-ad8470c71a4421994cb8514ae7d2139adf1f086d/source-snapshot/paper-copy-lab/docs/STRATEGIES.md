# Strategy hypotheses (not proven edges)

Each model has a separate object for entry qualification, a separate sizing outcome and its own exit branch. Accounting/execution infrastructure is intentionally shared code, but state is keyed by model and execution universe. All models use the same source-wallet list and source inventory denominator; none has access to another model's cash or fills.

| Model | Entry rationale / qualification | Sizing | Additional exit logic |
|---|---|---|---|
| A Baseline | Every fresh, otherwise qualifying source buy with a fresh two-sided book | 2% of observed source notional, capped at $25, then independent risk checks | Mirrors sells; 25% stop / 50% gain |
| B Selective | Public source closed positions ≥5; source closed-position win rate ≥55%; spread ≤2.5c; source price ≤85c; current ask no more than source price +1c | Baseline notional ×0.8 | 15% stop / 30% gain; exit on spread deterioration beyond twice entry spread cap |
| C Momentum | At least two source trade observations in past 120 seconds, ≥3 collected book samples; net positive bid move 0.5c–6c; final sample sequence nondecreasing | Baseline notional | 12% stop / 25% gain; three-book declining bid sequence with >1c reversal |
| D Value | Current ask ≤75c and at least 1c cheaper than source execution. Delayed expensive entries blocked rather than filled at historical source price | Baseline notional ×1.1 | 20% stop / 35% gain; exit when bid reaches configured absolute value target (75c) |
| E Risk-adjusted | Smoothed source reliability `(wins+1)/(closes+2)` × remaining drawdown capacity × remaining wallet capacity; scale must exceed 0.05 | Baseline notional × adaptive scale; $400 total / $120 wallet / $80 market exposure, 8% DD limit | 10% stop / 20% gain; portfolio de-risking at half configured drawdown limit |

All models mirror source sells **only when a baseline-backed source inventory denominator is available and consistent**. Sell quantity = copied position shares × min(1, source sell shares / source pre-sell inventory). Partial model exits reduce copied holdings; later source sells cannot oversell them. No copied inventory means no sell fill. Source quantity mismatch or out-of-order input now disables monitoring pending reconciliation.

Global safeguards: fresh event/book, cash, copy cap, position/wallet/market/portfolio cost-basis caps, daily loss, drawdown, frequency, price cap and minimum displayed liquidity. Executable execution rechecks risk after latency and fee inclusion. Exit orders are allowed to reduce exposure despite entry circuit breakers.

## Experimental cautions

- B's metrics are provider-reported closed source positions, not a full independently reconstructed source cash-flow ledger. They are captured at actual decision time (no retrospective use in historical decisions). `include_archived=true` reduces, but does not eliminate, provider selection bias.
- A/B/C/D/E thresholds are research defaults, not optimized or evidence-backed. C's momentum is monitored-token activity and polling-sampled bids, not a complete market tape. Shared source events include monitored wallets only.
- Value entries may produce zero trades when price never discounts; do not weaken rules to manufacture sample size.
- All paper worlds use the same current book for decision-time information. An ideal track still applies current qualification/risk but fills accepted source-copy orders at source price, so it is **not** a frictionless historical backtest. Independent model exits use observed current bid even in ideal mode.
- Risk is cost-basis exposure, not probability-normalized liability or correlated event exposure. No cross-market correlation model or statistical reliability estimator has been validated.
- No strategy superiority or profitability has been established. Compare matched forward windows and report trade counts and confidence limitations.
