# Architecture and accounting contract

## Isolation and safety

New standalone repository created in an empty workspace, no existing Polymarket repositories read or modified. Public network code only invokes fixed allowlisted GET endpoints through curl; no SDK capable of signing is installed as a runtime dependency. There is no live mode switch: `paper_only` must be literal true. UI control writes are local wallet-management operations, not exchange orders.

## Pipeline

1. One process owns a nonblocking OS file lock per database. SQLite uses WAL, synchronous FULL, busy timeout and BEGIN IMMEDIATE for mutations.
2. Wallet registry is shared input, not shared accounting. Stable initial inventory is captured before admission. All observed trades use v2's snake-case fields. Cursor pages must exhaust before a successful watermark update. A 300-second overlap plus event keys handles ordinary indexing delay/restarts.
3. Trades and raw payloads are persisted; detection arrival is distinct from the trade's source timestamp. Event key hashes wallet, transaction, token, side, size, price and timestamp. Missing log indexes leave ambiguity (audit H02).
4. Events wait configured detection delay, then run in timestamp/event-key order. Stale and pre-admission records get ten explicit blocking decisions. Older-than-already-processed records quarantine, never rewrite earlier PnL. Source inventory changes once per observed event, never once per model.
5. Models make decisions at actual **current decision time**, using only already-arrived books/performance; not at the historical wallet timestamp. Each track evaluates its own cash, drawdown and exposures. B uses public source-wallet closed-position statistics, not its own fills (avoids qualification deadlock).
6. Ideal orders can fill at the observed source execution price as an explicit counterfactual. Executable orders wait their execution due time and require a book arriving at or after due time. No past wallet price is treated as executable liquidity.
7. Executable orders walk sorted asks/bids with price-deviation caps, configured depth participation, fee schedule, partial fills and cancellation of unfilled remainder. Same-book fills deplete that portfolio's participation allowance. Different model/track worlds never consume each other's simulated book liquidity.
8. Risk is checked at scheduling and again against actual executable cost including fees. Pending buy amounts reserve approximate source-notional capacity; the execution recheck prevents negative cash if actual prices/fees differ. Daily loss uses UTC day opening snapshot; max drawdown uses historical marked peaks.
9. Fill, position, cash ledger, realized PnL, closure, and order result commit together. Rechecks under the transaction prevent duplicate execution of a stale fetched order. Snapshots and DB backups provide inspection/recovery evidence.

## Ten worlds, not $10,000 capital

Five models, $1,000 each. Each model has an ideal and executable counterfactual ledger. Compare tracks; never add their starting capital together. The experimental capital denominator is $5,000 per execution universe. Each world keys all position/ledger/order/snapshot queries by `(model, track)`; wallet/token cost basis is further separated inside the world.

## Financial definitions

Prices/quantities/cash are Decimal; persisted financial fields are decimal text quantized to 8 places, half-even. No binary float accounting. Source timestamps and transport timestamps use epoch seconds (float only for time). Production mark is **highest observed bid**, not midpoint: an observable conservative top-of-book liquidation mark, not a guarantee the entire inventory can liquidate there.

- Buy debit = shares × fill price + taker fee. Fee is included once in acquisition cost.
- Average remaining cost basis = remaining cost / shares. Partial sell removes proportional remaining cost; final sell removes exact residual basis.
- Sell realized PnL = exit proceeds − exit fee − removed basis.
- Cash = starting capital + sum(ledger cash deltas).
- Open invested capital/exposure = remaining fee-inclusive cost, **not lifetime turnover**.
- Open value = sum(shares × last causally available best bid).
- Unrealized = open value − remaining acquisition cost.
- Total PnL = realized + unrealized = equity − starting capital, within quantization tolerance.
- Equity = cash + open value. ROI = total PnL / immutable starting capital.
- Peak = max(starting capital, current equity, all persisted snapshot equities).
- Maximum drawdown = max(previous recorded maximum, (peak − current equity)/peak). Polling can miss intra-cycle peaks/troughs.
- Slippage is **signed** execution cost versus source reference; price improvement is negative, not hidden. Fees are separate.
- Trade count = filled paper orders (possibly partially filled), not individual source chain logs.
- Win rate = positive fully closed position cycles / all closed cycles; all partial exits aggregate. Exit-fill count is retained separately.

If no bid exists, acquisition cost is carried **only as an explicitly flagged unpriced fallback**, not invented market data. Stale last bids also flag. Entry pauses with stale/unpriced portfolio positions. Equity/PnL with such flags is not fully valued and must not be used to crown a winner. UI warnings and metrics expose the count; automatic ranking suppression remains an open audit item.

## Fees and resolution

Current Gamma `feesEnabled` + `feeSchedule` provide rate/exponent. Unknown schedule or unsupported exponent blocks executable fills. Supported taker fee: shares × rate × price × (1−price), exponent 1. Fee-free markets need explicit false, never inferred from a category. Ideal source-price track assumes zero fee to isolate the price-copying counterfactual; not a reproduction of source economics. No rebates assumed.

Verified `/v2/tokens` `resolved=true` with a final price in [0,1] permits local paper settlement at token payout, including zero and fractions; independent of whether the source wallet redeems. This is an immediate paper-redemption assumption with no gas or collateral-release delay. Pending token orders cancel before settlement; each held lot settles once by reducing shares to zero. Real chain transactions are never submitted.

Source SPLIT/MERGE/REDEEM/CONVERSION and other nontrade events do not get misclassified as trades: they disable source monitoring pending reconciliation. Paper positions are not source holdings, and source redemption is not a second paper payout. Automated source lifecycle reconstruction, reorg rollback and complete neg-risk/combo support remain incomplete.

## API research evidence

Official extracts are stored beside this document: `api-index.txt`, `data-api-v1-to-v2.md`, `data-openapi.json`, `fees.md`, `market-details.md`, `prices-order-books.md`, `wallet-activity.md`. Official migration guide says v1 retired November 2, 2026; live v1 returned retirement error and live `/v2/trades` returned an envelope. Third-party search results conflicted with this date; the implementation follows verified official sources.

Read endpoints used: Gamma `/markets`; CLOB `/time`, `/book`; Data `/v2/trades`, `/v2/activity`, `/v2/positions`, `/v2/tokens`. API status/resolutions are allowlisted for future verification but not used to fabricate finality. curl is used because urllib CLOB returned HTTP 403 in the sandbox. Bounded retries cover 429/5xx/network errors; delays use exponential backoff/jitter. Retry-After interpretation and adaptive global budgets are not implemented.

---
# H01–H05 remediation architecture (supersedes unsafe admission descriptions above)

Reference 288a69f; uncommitted coordinated remediation, no deployment. Strategies and
config unchanged. New `lab/integrity.py` is an evidence gate, not a source of invented
blockchain facts. Production `allowed()` is deliberately false until a separately
reviewed canonical source adapter exists. `Engine.ingest` retains ordinary rows as
observations; it cannot economically hash/dedup them into executable events. Legacy
pending events/positions/orders also cannot bypass this gate.

## Data separation / migration 3
- collection_batches: fixed params/window, durable cursor, next page ordinal,
  incomplete/error state. Pages and observations commit atomically.
- collection_pages: wire response, provider ordinal, cursor_in/out and arrival.
- transport_deliveries: successful receipt, retry/failure bodies and disposition.
- source_observations: original payload/multiplicity; canonical numeric key is
  investigatory grouping ONLY, never event identity. observation_flags expose
  identical economics and same-time opposing rows.
- capture_frontiers: only terminal, durable page capture; explicitly NOT a source
  completeness checkpoint or processed-event watermark. Legacy cursor_time no longer
  advances on collection. Incomplete batches resume saved filters/cursor after restart.
- baseline_evidence: limitations, status, scope and boundary; all ordinary REST
  baselines quarantined. Missing/dust/inactive rows never imply zero. No second-read
  equality heuristic, timestamp admission or automatic old-inventory overwrite.
- verified_events/event_links/copy_event_links: separate evidence identity, economic
  event, observation and internal copy-event IDs. No production verifier attached.
- source_inventory/source_movements/source_effects: source-only typed leg journal,
  basis/cash/realized, effect/transfer overlap guards; not paper ledgers.
- source_states: checkpoint (null when unproven), baseline version, last complete
  batch, source journal order, uncertainty. Status freshness is separate from proof.
- monitoring_history/gaps: operator monitoring intent and unreconciled intervals.
- reconciliation_records/paper_holds: source/paper snapshot and raw quantity differences
  with unknown explicitly null, NOT equal-target assumptions. Existing positions are
  retained and held, never closed at fabricated historical prices.

A newly created synthetic fixture DB is permanently tagged; it cannot be run as the
application and production DBs cannot be relabelled synthetic. Legacy strategy tests
use this explicit environment. A fixture certificate is not an accepted chain ID.

Supported pure transformations carry cost basis without fictitious realized losses.
Resolution observation does not itself redeem. Unknown operations, incomplete legs,
reorg/correction/reversal, overlapping transfer effects or unsupported conversion
cash allocation quarantine. Recovery may reconstruct source evidence but cannot
backdate a paper execution. There is no automatic real source verification/release.

Runtime v1/v2 refuses startup before schema writes. Migration 3 is explicit, under
worker lock, after verified SQLite backup, with legacy-table content digests, atomic
DDL and rollback. It adds holds/gaps without changing old portfolio rows. Only
DISPOSABLE migration fixtures were upgraded in remediation; actual runtime untouched.

New executable fills also persist execution_context with exact book ID/arrival, spread,
levels, reference and classification in the fill transaction. Existing fills without
context remain explicitly unknown; candidate post-due books are not asserted as used.
