# External independent review guide

**This package is preparation for independent review. It is not an independent audit, does not resolve Audit 14, and does not authorise Phase 1A.**

## Authority and delivery boundary

Prepared by the same Arena.ai assistant that authored Audit 14 and the master planning
artifacts. This is an implementation-side handoff, not a separate reviewer report.
No finding is newly confirmed, reclassified, fixed or independently verified here.
No tests, browser, application or worker were run to prepare these documents.

The package is four documents; it deliberately references the actual existing source
and complete evidence rather than duplicating or altering them. To give an external
reviewer a self-contained **input set**, transfer the entire current source/evidence
snapshot using the commands document, not just these four files, and not a clean Git
checkout. All important remediation modules are still uncommitted. Runtime DBs and .git
are excluded from transfer. A manifest inventory and schema/count inspection evidence
are supplied; actual DB export needs separate owner approval if a reviewer later needs it.

## Start here

1. Establish reviewer identity and disclose prior implementation/report involvement.
2. Read all four preparation documents, then the complete Audit 14 report at
   `docs/phase0-audit14/AUDIT_14.md`, its PHASE0_REPORT.md, root master plan/register,
   `docs/REMEDIATION_REPORT.md`, original audit, DESIGN and ONCHAIN_ASSESSMENT.
3. Verify manifests, source hashes, complete working-tree status and reference HEAD.
   The evidence index covers all pre-preparation project files and explains overlap.
4. Independently inspect actual code and tests before executing any supplied harness.
5. Create disposable copies outside the project, preserve an untouched input snapshot,
   deny network and keep original project paths unavailable to the execution sandbox.
6. Reproduce using the matrix and commands. Supplied probes are starting examples;
   write independent variants. Do not approve based only on these authors' test scripts.
7. Produce a new separately authored report, preserving every failure and limitation.
   Stop with APPROVE FOR BOUNDED PHASE 1A, REVISE PLAN or BLOCK. User approval remains
   an additional gate, and no runtime migration/start is authorised by reviewer sign-off.

## Repository map — inspect all dependencies

- `lab/store.py`: legacy schema, Store initialization, transactions, health and backup.
- `lab/migrations.py`: V3 definitions, table_digests, apply_new, upgrade_existing.
- `lab/accounting.py`: fills, ledger/position cycles, metrics and snapshots.
- `lab/integrity.py`: capture, identity, lifecycle, holds/gaps and admission guard.
- `lab/public.py`: GET allowlist, retry client, collector and baseline scope scheduler.
- `lab/engine.py`: raw ingress, decisions, execution, exits, settlement and risk callers.
- `lab/wallets.py`: operator changes, history and re-enable/removal holds.
- `lab/main.py`: startup, state serializer, worker/API and lock ordering.
- `lab/dashboard.html`: actual health/status renderer, warnings and display semantics.
- `lab/config.py`, `lab/strategies.py`, `config.json`: validation, five models and limits;
  inspect for accidental weakened assumptions; never tune these during review.
- `lab/validation.py`: source/paper evidence export and readiness boundaries.
- `tests/test_lab.py`, `tests/test_integrity.py`: entire existing 119-case baseline;
  also inspect regression assertions, fixtures and migration failure tests.
- `tools/audit.py`, `tools/source_verify.py`: separate Fraction arithmetic implementations,
  but not independently authored third-party reviews.
- `tools/remediation_evidence.py`, `tools/fixture_validation.py`: temporary fixture
  generators; outputs overwrite docs/remediation in their CURRENT WORKING DIRECTORY.
- `docs/phase0-audit14/adversarial_checks.py`: eight defect probes plus two guards.
- `docs/phase0-audit14/dashboard_probe.py`: intercepted stale health browser fixture.
- Complete file inventory, archived reports, screenshots, patches and failed attempts:
  see EVIDENCE_INDEX. Do not discard earlier failed tests as irrelevant to provenance.

## H01–H05 and external blockers

| Parent | Local claim to challenge | Evidence not currently supplied/proved |
|---|---|---|
| H01 | Atomic received-page durability and quarantine, not exhaustive source state | Authoritative shared source checkpoint; supported historical/inactive/archive/dust coverage; late insert completeness |
| H02 | Raw multiplicity retained; production guard blocks economic admission | Canonical chain/contract/transaction/block/hash/tx-index/log-index identity, ordering, attribution and finality for ordinary observations |
| H03 | Typed synthetic leg arithmetic and basis carry | Full version-specific real BUY/SELL/SPLIT/MERGE/REDEEM/resolution/conversion/negative-risk/combo/transfer/fee decoder and corrections/reorg evidence |
| H04 | Gap/hold/removal records prevent unreviewed re-enable | Complete actual historical gap reconstruction, trustworthy inventory and reviewed hold release without invented missed paper fills |
| H05 | Reproducible fixture arithmetic/export, readiness false | Genuinely separate review; actual approved wallet-forward history, adequate execution calibration and strategy performance evidence |

A terminal cursor is a capture frontier, not a complete chain checkpoint. Missing inventory
is unknown, not zero. Synthetic certificates/ordinals are not chain identities. Production
allowed() is intentionally false; do not remove it. No real-money capability is permitted.

## Known limits and documentation conflicts

- Nine weaknesses were reproduced previously; A14-10 was inspection-only. All require
  independent assessment, not adoption of labels or supplied severity.
- Existing positive replay: 119 tests, 10 source fixture events and 500 paper fills.
  Those historical results are not new tests or comprehensive financial/source assurance.
- A14-03/04 concern synthetic admission semantics, not a demonstrated production bypass.
- A14-08 is a demonstrated generic type-collision assurance gap, not observed runtime loss.
- Conflict probe searched four relevant tables without a linked observation; independently
  inspect every possible durable location and extend conflict evidence coverage.
- Replay does not prove event completeness, real payout evidence, execution obtainability,
  correction/reorg rollback or correct ledger fields it never checks.
- Executable PnL is an estimate; no adequate forward strategy or liquidity/latency calibration.
- Authentication/operational hardening remain incomplete. Never expose the dashboard.
- README and older instructions contain superseded quiet-baseline assumptions, startup,
  HTTP tests and historical phase numbering. Current master plan/register and code prevail;
  preserve contradictions as review evidence rather than editing historical documents.
- Some prior temporary DB paths in reports no longer exist. Recreate controlled fixtures;
  do not substitute actual runtime DBs. No independent auditor is bundled with this package.

## Environment

README specifies Python 3.11+ (previously tested 3.13); runtime/core tests use standard
library modules, SQLite and Unix fcntl. Linux is recommended for lock/concurrent-process
review. No requirements/lock file is present; cross-version reproducibility is unpinned.
Observed preparation environment: Python 3.13.16, SQLite 3.46.1. Playwright Python package
is currently **not installed**. No dependencies were installed for this preparation.

Browser reproduction needs Playwright, a compatible Chromium and its system libraries.
Use a separate virtual environment and record resolved versions; optional installation
commands are in COMMANDS. Installer network access is separate from an offline audit run
and requires a reviewer-approved environment. Browser binaries may require OS provisioning.
Curl is used by the real client, but is unnecessary for fake-API offline reproductions.
Do not run curl, a collector or an upstream request to satisfy a fixture.

## Reviewer report worksheet (copy into a NEW report outside supplied source)

- [ ] Name/organisation or separately identifiable agent; date and report identifier.
- [ ] Independence declaration; disclose prior code/report/plan authorship or conflicts.
- [ ] Exact source/evidence snapshot hashes, branch/reference HEAD and uncommitted scope.
- [ ] Environment: OS, Python/SQLite, dependency/browser versions, network isolation.
- [ ] Complete actual files inspected and differences from supplied reading list.
- [ ] Every command, working directory, environment, fixture input, exit code and output.
- [ ] For each A14: CONFIRMED/REJECTED/RECLASSIFIED, own severity, code path, independent
      reproduction, proposed-fix sufficiency, missing tests and scope limitations.
- [ ] A14-10 actual dynamic investigation or explicit blocked/not-reproduced limitation.
- [ ] H01–H05 containment versus capability, additional defects and external blockers.
- [ ] Distinguish regression/unit/integration/synthetic/browser/arithmetic/real observations.
- [ ] Full order/Phase 1A assessment; request changes to register without modifying it.
- [ ] Preservation comparison and tests not run; no fabricated result for unavailable case.
- [ ] Recommendation: APPROVE FOR BOUNDED PHASE 1A / REVISE PLAN / BLOCK.
- [ ] Explicitly no runtime migration/start or later-group permission implied; STOP.
