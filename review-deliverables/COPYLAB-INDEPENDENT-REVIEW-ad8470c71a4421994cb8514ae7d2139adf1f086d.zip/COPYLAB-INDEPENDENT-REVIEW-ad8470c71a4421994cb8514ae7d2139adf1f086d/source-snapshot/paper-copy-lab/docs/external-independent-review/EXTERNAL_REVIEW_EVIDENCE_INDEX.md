# External review evidence index

**This package is preparation for independent review. It is not an independent audit, does not resolve Audit 14, and does not authorise Phase 1A.**

All paths below are repository-relative. Contents belong to the supplied working tree,
not just HEAD. Preserve every listed historical attempt, report, screenshot and source file.
No separate archive is created by this preparation. The commands document explains how
to transfer a runtime-free, self-contained source/evidence snapshot to the external auditor.

## Current identity and preparation operations

- Repository: /home/user/paper-copy-lab, main.
- HEAD: 288a69f64c24438cfe69ea176e6f3d6ce7333499.
- Existing manifests validated by actual size/hash checks (overlapping sets):
  - `docs/phase0-audit14/baseline-manifest.json`: 106 entries, zero mismatches.
  - `docs/remediation/manifest.json`: 59 entries, zero mismatches.
  - `docs/phase0-audit14/evidence-manifest.json`: 29 entries, zero mismatches.
  - `docs/master-remediation-planning-2026-11-05/baseline-manifest.json`: 136 entries, zero mismatches.
  - `docs/master-remediation-planning-2026-11-05/evidence-manifest.json`: 12 entries, zero mismatches.

- Inspected source/test/tool/doc text and inventories; used git branch/rev-parse/status/diff,
  byte SHA-256/size checks, AST location inspection, process inventory and dependency metadata.
- No tests, browser, App/main diagnostic or worker executed. No network requests/install.
- No SQLite connection to either runtime database (or any disposable database) was opened.
  sqlite3 version metadata was read only. Real DB bytes were read for SHA-256 preservation.
- No old file modified; exactly the four requested preparation documents created.
- No matching application/worker/migration process observed; no process controlled.

## Complete original Git status

```text
 M README.md
 M docs/ARCHITECTURE.md
 M docs/AUDIT.md
 M docs/CONTINUE.md
 M docs/DATABASE.md
 M docs/FORWARD_REPORT.md
 M docs/JOURNAL.md
 M lab/dashboard.html
 M lab/engine.py
 M lab/main.py
 M lab/public.py
 M lab/store.py
 M lab/wallets.py
 M tests/test_lab.py
 M tools/audit.py
 M tools/fixture_validation.py
 M tools/http_check.py
?? MASTER_DEFECT_REGISTER.md
?? MASTER_REMEDIATION_PLAN.md
?? docs/PHASE_TRACKER.md
?? docs/REMEDIATION_REPORT.md
?? docs/master-remediation-planning-2026-11-05/
?? docs/phase0-audit14/
?? docs/remediation/
?? lab/integrity.py
?? lab/migrations.py
?? lab/validation.py
?? tests/test_integrity.py
?? tools/export_validation.py
?? tools/migrate_source.py
?? tools/remediation_browser.py
?? tools/remediation_evidence.py
?? tools/source_verify.py
```

## Current source anchors (line numbers from preparation snapshot)

- `lab/__init__.py`: 
- `lab/accounting.py`: Accounting:4, __init__:5, metrics:6, fill:39, snapshot:67
- `lab/config.py`: validate:3
- `lab/engine.py`: Engine:7, __init__:8, ingest:9, book:29, context:33, process:51, risk:105, execute:128, reject:186, exits:187, settle:214
- `lab/integrity.py`: dump:7, raw_dump:8, economic_key:10, number:11, Integrity:14, __init__:15, hold:16, allowed:29, gap:36, observe:42, tag:51, collect:65, baseline:119, synthetic_event:127, lifecycle:146
- `lab/main.py`: App:11, __init__:12, run:18, state:30, main:35, Handler:50, send:51, do_GET:53, do_POST:58, log_message:66, stop:69
- `lab/migrations.py`: apply_new:26, table_digests:32, upgrade_existing:41
- `lab/public.py`: PublicClient:5, get:8, pages:25, Collector:37, __init__:38, cycle:39, save_market:88, source_health:98, baseline:113
- `lab/store.py`: dec:7, money:12, now:13, Store:36, __init__:37, tx:66, rows:71, one:73, audit:75, health:76, backup:78
- `lab/strategies.py`: Baseline:3, entry:4, Selective:5, entry:6, Momentum:13, entry:14, Value:22, entry:23, RiskAdjusted:28, entry:29
- `lab/validation.py`: forward_evidence:5
- `lab/wallets.py`: Wallets:4, __init__:5, change:6
- `tests/test_integrity.py`: page:15, row:16, API:18, __init__:19, get:20, IntegrityTests:25, setUp:26, tearDown:28, collect:29, cert:30, incoming:32, test_failure_before_response_has_no_frontier:34, test_partial_page_then_failure_retains_rows_and_cursor:37, test_resume_after_restart_same_batch_no_loss:40, test_failure_inside_page_transaction_rolls_back_without_frontier:45, test_retry_after_write_failure_preserves_attempts:49, test_missing_pagination_is_incomplete_not_zero:53, test_repeat_cursor_keeps_frontier_uncommitted:56, test_late_behind_traversed_cursor_never_certifies_coverage:59, test_identical_legitimate_rows_preserve_multiplicity:62, test_cursor_restart_overlap_preserves_observations:64, test_provider_order_and_ordinal_preserved:66, test_numeric_key_normalization_does_not_deduplicate:68, test_same_transaction_different_tokens_not_collapsed:70, test_same_second_buy_sell_quarantined:72, test_same_second_sell_buy_quarantined:74, test_ambiguous_row_direct_engine_never_economic_event:76, test_synthetic_certificate_duplicate_applies_once:82, test_two_identical_economics_with_distinct_fixture_certificates:84, test_conflicting_identity_quarantines:86, test_production_cannot_accept_synthetic_certificate:88, test_matching_snapshots_do_not_admit:94, test_same_second_boundary_does_not_update_inventory:96, test_dust_archived_and_missing_rows_not_zero:98, test_no_invalid_closed_archived_parameters:100, test_stale_status_blocked:102, test_missing_status_blocked:103, test_partial_and_full_source_sell:104, test_split_explicit_legs:106, test_merge_explicit_legs:108, test_redeem_fractional_payout_once:110, test_resolution_does_not_pay_again:112, test_conversion_evidenced_debit_credit:114, test_negative_risk_evidenced_legs:116, test_combo_evidenced_legs_not_trade:118, test_transfer_plus_lifecycle_no_double_count:120, test_duplicate_payout_different_id_same_effect:122, test_missing_conversion_legs_quarantined:124, test_unknown_operation_quarantined:126, test_reorg_correction_reversal_block_instead_of_rewrite:128, test_disable_open_positions_records_hold:132, paper:134, test_missed_sell_during_gap_never_historical_fill:135, test_missed_merge_during_gap_keeps_paper:137, test_short_gap_enable_not_trusted:139, test_long_gap_not_trusted:141, test_missing_history_retains_open_gap:143, test_soft_removal_retains_evidence:146, test_incomplete_reconciliation_does_not_match_by_balance:148, test_unmatched_legacy_paper_is_held:150, test_independent_source_replay_expected_cash_and_realized:155, test_independent_source_replay_detects_tamper:159, test_verifiers_do_not_import_production_accounting:163, test_conversion_carries_basis_without_realized_loss:168, test_unverified_conversion_allocation_is_blocked:170, test_ambiguity_flags_visible:172, test_synthetic_forward_export_cannot_claim_real_results:174, test_zero_wallets_zero_forward_results:177, test_synthetic_db_cannot_start_real_application:184, test_production_legacy_pending_event_has_no_inventory_effect:187, test_duplicate_verified_transport_links_retained_once_economically:196, test_healthy_status_does_not_prove_baseline:201, test_unparseable_response_body_preserved:206, BadAPI:207, get:209, test_empty_cursor_not_terminal_evidence:212, test_verified_order_regression_quarantines:215, MigrationTests:218, setUp:219, tearDown:221, test_existing_refuses_auto_migration_without_changes:222, test_verified_backup_additive_and_idempotent_refusal:226, test_failed_migration_rolls_back_schema:229
- `tests/test_lab.py`: LabTest:8, setUp:9, tearDown:12, book:13, event:17, order:19, fill:22, test_ten_independent_ledgers:25, test_partial_sells_fee_basis:30, test_oversell_rolls_back:34, test_idempotent_events:38, test_missing_books_blocks:41, test_executable_requires_post_latency_book:43, test_fees_formula:46, test_unknown_fee_blocks:50, test_partial_depth:52, test_wallet_validation_and_history:54, test_disabled_pending_buys:57, test_restart_does_not_reset:59, test_backup_recovery:61, test_config_mismatch_refused:63, test_stale_events_not_replayed:66, test_out_of_order_quarantined:68, test_no_future_mark:70, test_drawdown:72, test_equity_identity_random_lifecycle:74, test_api_rejects_order_endpoint:79, test_models_different_entries:81, test_closed_position_winrate_not_partial_fills:83, test_reopened_position_separate_lifecycle:86, test_settlement_fractional_payout_and_idempotence:89, test_settlement_losing_token:92, test_unresolved_not_settled:94, test_hybrid_partial_and_full_source_sell:96, test_unbaselined_wallet_does_not_copy:101, test_source_inventory_mismatch_blocks_sell:103, test_enable_rebaselines_and_preserves_history:105, test_invalid_data_rejected:107, test_market_and_wallet_exposure_limits:110, test_trade_frequency_limit:112, test_execution_rechecks_drawdown:114, test_model_specific_exits:116, test_selective_uses_source_performance:119, test_value_requires_discount:121, test_momentum_confirmation:123, test_daily_loss_limit:125, test_stale_portfolio_pauses_entries:127, test_pagination_duplicate_cursor_fails:129, API:130, get:131, test_baseline_current_size_v2:133, API:134, get:135, test_baseline_not_admitted_during_activity:139, API:140, get:141, test_transaction_crash_rolls_back_all_writes:143, test_selective_spread_exit:148, test_momentum_reversal_exit:150, test_value_target_exit:152, test_same_book_liquidity_not_reused:154, test_order_reexecution_does_not_duplicate:156, test_config_validation_rejects_real_mode:158, test_market_minimum_order_size:162, test_actual_fee_inclusive_copy_cap:164, test_executable_fill_retains_exact_book_context:166
- `tools/audit.py`: 
- `tools/browser_check.py`: 
- `tools/configure.py`: 
- `tools/export_validation.py`: ReadOnly:6, __init__:7, rows:8, one:9
- `tools/fixture_validation.py`: 
- `tools/forward_report.py`: stamp:6
- `tools/http_check.py`: request:11
- `tools/migrate_source.py`: 
- `tools/remediation_browser.py`: route:11
- `tools/remediation_evidence.py`: event:12, leg:15, CapturedAPI:29, get:30
- `tools/source_verify.py`: verify:8

## Reading/evidence groups

1. Root master plan/register; docs/phase0-audit14/AUDIT_14.md and PHASE0_REPORT.md.
2. Entire lab, tests, tools and config.json, plus README warnings and older docs.
3. docs/phase0-audit14: original 106-file baseline, backend/browser scripts and results,
   regression logs, copied DB schemas/counts, reproduced source/paper/migration/readiness,
   status/diff/process inventories, 59-entry verification and final preservation manifest.
4. docs/remediation: original audit, DESIGN, implementation.patch, auditor instructions,
   all tests-attempt-1 through -9 and tests-final, source/paper/migration/export/readiness,
   browser/HTTP evidence and official contract/onchain snapshots. Historical HTTP evidence
   is reading material only; do not rerun app-start tools under this review restriction.
5. docs/master-remediation-planning-2026-11-05: 136-file pre-planning baseline, 12-entry
   final planning artifact manifest, inventories, exact diffs/status/process checks and
   copied DB inspection. Current master plan supersedes older phase numbering.
6. Remaining docs: original verification/backup/forward logs and JSON, API specification
   snapshots, configuration/strategy/architecture/database/journal/continuation reports,
   browser installs/screenshots and old test attempts. Public sentinel books are not wallet
   forward copy observations. Historical official snapshots are not current chain proof.
7. data entries below are protected identity metadata, NOT input to reproduction. Schema,
   counts and integrity results already exist in copied-inspection JSON; no actual runtime
   content is required to demonstrate the A14 fixture defects.

The reviewer-blocker report outside this repository is not required technical evidence.
It is not an independent audit. Earlier source/evidence ZIPs outside the project are not
needed when the full listed current tree is transferred. No other bot project is a dependency.

## Known missing materials

- A genuinely independent reviewer and separately authored technical verdicts.
- Executed dynamic A14-10 concurrency evidence; only an unexecuted proposal is provided.
- Playwright/Chromium environment is not provisioned here; browser reproduction may need
  separate approved installation. No pinned Python dependency/browser/OS lockfile exists.
- Canonical source completeness/identity/finality and actual operation decoder proof.
- Complete actual source-gap history and real wallet-driven forward/execution calibration.
- Sufficient untouched strategy evaluation and complete auth/operational/restore/soak proof.
- Some generated temporary databases in historical reports are intentionally deleted;
  regenerate synthetic cases, never invent a historical DB or substitute runtime data.

These do not prevent offline review of supplied code and most minimal fixtures, but
prevent claiming all external source/system milestones complete or independent approval.

## Complete pre-preparation file inventory

Size/hash cover all existing project files except Git internals and generated cache/
node_modules paths. The four new documents are excluded from this baseline (no circular
self-hash). Their final preservation check is recorded below. Do not add manifest counts
as if disjoint. Exported copies omit data/ and must explicitly note that redaction.

| Path | Bytes | SHA-256 |
|---|---:|---|
| `.gitignore` | 48 | `faae6d82b50a9cde75ec06ee8c4d3a7b18f086d3cb197fe55a308c544bcdb731` |
| `MASTER_DEFECT_REGISTER.md` | 18866 | `aa7fef2405c55173ef0f7275b94b87b43f8351ece6c830ee39bad612c5124e30` |
| `MASTER_REMEDIATION_PLAN.md` | 26589 | `2bf9897bbec820489aa6f2a1c804d84ac2ea8292d0512fc74d3f98bdeee9141d` |
| `README.md` | 5498 | `7df109937cc8eef2cf33274592044209ef83de81c5a51a64352eaad5f3fba174` |
| `config.json` | 1585 | `fb98f125dd537ccc0a9911162ca16bd4813051c9af94c48ce9b928194cfe2ab5` |
| `data/lab-verified-backup.sqlite` | 770048 | `05749631d7ada4ede38834dec060006c44f4d0e4ed0c2f6df70822ea9ba10c44` |
| `data/lab.sqlite` | 1662976 | `cdbf549d5f39f9cb53a18b7e9fa9aad961083ae4914ca869c72bc705a6c1deb3` |
| `data/lab.sqlite.worker.lock` | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `docs/ARCHITECTURE.md` | 11302 | `5d685c75dcc223b3866af69528957fc3f2a087ee508aebc9502763091d755dda` |
| `docs/AUDIT.md` | 10775 | `1a247383e95b6541508c8eedc9f833cdc4894bd0a2312decccc3fa442e3be9aa` |
| `docs/COMPLETION_REPORT.md` | 7011 | `60c3669d798cfda9f71adecb3c446ec7109ffc032f8a8762cc713ac5b5e0e4f8` |
| `docs/CONFIGURATION.md` | 2941 | `9fbce8c8742fca1c3d7106c1c5d6673584324e1664658247a766618846ff2539` |
| `docs/CONTINUE.md` | 6077 | `3f270bbf1c1ec1ebf23fee640931ad4b9f05592826a3b24ce5f8735e923e19a1` |
| `docs/DATABASE.md` | 3744 | `39050c511964f5d20a09d603def1bb0093fcc392a6068b32690a084b6068f45d` |
| `docs/FORWARD_REPORT.md` | 3491 | `a3a697706bd1d6cf0766dbaaf86637455cec72f30033794c4363d9ed6fcc29be` |
| `docs/JOURNAL.md` | 6770 | `f8cc62996e8724dc3d08b012a3826b342e9a8844bcc956f442f8272fc2d11ab7` |
| `docs/PHASE_TRACKER.md` | 2838 | `11b4fbf2748ada03df37e35acab89aa2bdbb52c63b8c8669bc0efdcc593a649f` |
| `docs/REMEDIATION_REPORT.md` | 13537 | `be94ef137282df0922440e82e846f631c29fac6049493397aed2a3699ac03e3e` |
| `docs/STRATEGIES.md` | 3930 | `1b229152a92ede5ed2e24661947aab1566a4527b998d21146aa76defaf5c80fc` |
| `docs/api-index.txt` | 15337 | `fa077764b491e41cff64ffb79e3984ef876ea28f9279025bbbee8262a3623ce8` |
| `docs/audit-evidence.json` | 453 | `c2869fb540ef2cc2944e2d2f838313a96a6498ffdce5138d9e996bb16725de25` |
| `docs/audit-fixture-evidence.json` | 473 | `30c5ad25f2171bcded81d576c5452c2de7f019434c5f6c4973d9c6c490db4028` |
| `docs/audit-run.txt` | 454 | `1d4dd6ae680307760aa0e5ce3a05d1935e1bb83241468df3133e0265a69114b5` |
| `docs/backup-audit-evidence.json` | 469 | `e3a1b1a7042439b5015f5bbef5c0bde11c3ed19f8521fe3e5217c7f4f7128849` |
| `docs/backup-audit-run.txt` | 470 | `f671a7828547dda45356e0b2cf5db4283003a409fc3311204a3f19aeea078066` |
| `docs/browser-dependencies.log` | 14564 | `29230ff8525a17352e99bb5c576858c3d1f6a8d8d923df86bcd415d5a200101a` |
| `docs/browser-evidence.json` | 929 | `428623123ffb8df9100934de2e2aea9df6077c6261642ce63e71cf416866883c` |
| `docs/browser-install.log` | 6777 | `a27f411bd276b9998fa4433ef73e5691991f3c68c5303b9e0d23bc78dfc5bf21` |
| `docs/browser-run.txt` | 930 | `f4d21a2b3817a28239dc5be9d8211ad6ab83ea7a6679a9dfa54cb828c1276dd0` |
| `docs/dashboard-desktop.png` | 188409 | `0939666da51598454374f0fef2fa525f89cd1af10d0eddb72d1c86926efa14a2` |
| `docs/dashboard-mobile.png` | 166214 | `1949cf9fac62cf00bc02a3bc001563b2c1519848b55aba25e2e88acaff3b2366` |
| `docs/data-api-v1-to-v2.md` | 5326 | `d7ca679fea29966a2c2695e4b1b8256d6a7e88512dafb9f6cfa2030691570970` |
| `docs/data-openapi.json` | 158115 | `cf4ceff85c26e6586c4164377dc4a1e9c1196ea7fa3ed94ce11a0fc083ca8fea` |
| `docs/fees.md` | 5952 | `2b2b8dcc545d4eb39ec8bedfc2489b19c6b59a1baeaa71111222af51454d25e6` |
| `docs/final-runtime-evidence.json` | 856 | `461129f30c91fd3e51724d9a1df4d8beaf0e928da6bfa1ecb2703d81b4e6a1f7` |
| `docs/fixture-run.txt` | 474 | `41fb186dd37276d7a8c28b9787586e5e1ba8607369f8103e2d7ae5f69a24354d` |
| `docs/forward-evidence.json` | 1422 | `9ecaa131cccf958201fd96eb077d5aa4f5ecc751ffcc30ac0ffc44a4b5118c45` |
| `docs/forward-run.txt` | 732 | `cde29863d1ee53e16b1f17f049c292c4fd447d95b5ba1e7bd3c18050cafd9f98` |
| `docs/http-evidence.json` | 363 | `87d3fca519bb716b3749db0489a61f965fb8154045ed441f0430cc501c84a9d2` |
| `docs/http-run.txt` | 364 | `2be9ee550a471146a956f939b63914f0dd921e2170a9288c09c3a41306ded470` |
| `docs/market-details.md` | 27740 | `7ba9f44650163b5afd6b51768a2e2c9a2675d696a06877e9e980dd5745275540` |
| `docs/master-remediation-planning-2026-11-05/baseline-manifest.json` | 21171 | `d7170fbd9c244935b0e16e6ea6424f3b4013cffdcc9863d211c9cc3c52bc3c6c` |
| `docs/master-remediation-planning-2026-11-05/database-copy-inspection.json` | 724 | `42cfe198fe2b27b3a67ec51b2256e53c711c97c44c022b490d500424235e9e19` |
| `docs/master-remediation-planning-2026-11-05/evidence-manifest.json` | 2250 | `228f7562ac898889e2f21d932facbb5fdf0040b25bd6dd0637f9b3742a8804ad` |
| `docs/master-remediation-planning-2026-11-05/git-diff-before.patch` | 64372 | `0683b873469dd04f406226c14a86e0e3aec4633374afc556cfe117987d5d1cf8` |
| `docs/master-remediation-planning-2026-11-05/git-status-before.txt` | 722 | `758c06f81a3d65b9fb7d14b90ce129606b0a23f4052310d01f2b2468bb085e60` |
| `docs/master-remediation-planning-2026-11-05/git-status-final.txt` | 781 | `0ea38971335abeaf0b430cb14bc6c31e7d2ef28e0f47aa4d364f6f2a03242d08` |
| `docs/master-remediation-planning-2026-11-05/inventory.json` | 5057 | `1090856cef70e21b2d63624c7fa61191659fca2741f198cdc214fc248bbc75ce` |
| `docs/master-remediation-planning-2026-11-05/preservation-checks.json` | 324 | `a5ff67f4b6d4ee7528654021d1aaece77907e12f1ef594315b799805ea73ea05` |
| `docs/master-remediation-planning-2026-11-05/preservation-final.json` | 1368 | `12078902b977b1bd230a6efa9edb96bef1767411e9e07866f56c7529697946bc` |
| `docs/master-remediation-planning-2026-11-05/processes-after.txt` | 55728 | `9ca2a5c39f1acd773d38ec64dc6b8728a3d4f2b34170050e04121444cdd01631` |
| `docs/master-remediation-planning-2026-11-05/processes-before.txt` | 38193 | `ea9b9079022f4d9a8395eceb24cfc8ea3cc6b0aa37a87f3d3af4ec3885eeebd4` |
| `docs/phase0-audit14/AUDIT_14.md` | 12062 | `1d670d424cb9e4bab8a37fdb580c35d74d6e81cb013a9e3d575c1c12191263c2` |
| `docs/phase0-audit14/PHASE0_REPORT.md` | 9008 | `846a7111308c8b84ee240d9fd25b7db961e89dcc25630ea4d5e03c371c0199b3` |
| `docs/phase0-audit14/adversarial-results.json` | 4080 | `abeafe069eee135e2dda77e06de9a3f61d1872bf04270eac1d2f4ee9986732eb` |
| `docs/phase0-audit14/adversarial-run.txt` | 4081 | `f791171f7b31a5d1ab96c4a55977379c95d14aa6715b921c2e9b1a2118c75641` |
| `docs/phase0-audit14/adversarial_checks.py` | 8601 | `10318dcbb487d77f94cf878a4b4b86b0dd79c6441be1f108a1ff35f3806cd7ab` |
| `docs/phase0-audit14/baseline-manifest.json` | 16360 | `c85e3dabdd190d9161279d94c515ca58b52d120c63f518428e55cab7a95cf642` |
| `docs/phase0-audit14/baseline-reproduction.json` | 720 | `d03a84dcb2bdf31784ee09fce45d50a45c38a59ad9066402b9932c1d02a14e9e` |
| `docs/phase0-audit14/dashboard-results.json` | 372 | `c93749ca3783758a84f2ea9cff08be87ba5db30361c512668c46d101af97ce2d` |
| `docs/phase0-audit14/dashboard-run.txt` | 373 | `c13dab289deab604087ae774d997aad9f4ea3d9983cc274c31d74d3f8dbe338b` |
| `docs/phase0-audit14/dashboard-stale-health.png` | 157886 | `a1585774344309e8e59323c8a9bedf920feaa41d9769c930dbb90f3d76d7135d` |
| `docs/phase0-audit14/dashboard_probe.py` | 2026 | `9788cfe4f3aabcaead75dabed6fe873ec7a7c82569c699deb5425b39fdd97c06` |
| `docs/phase0-audit14/database-inspection.json` | 7630 | `870d6097c1107a17ed0f37d7de802c8aea855649d0b1a6f9e2362487f9b6a677` |
| `docs/phase0-audit14/evidence-manifest.json` | 4862 | `a36d40c7eb97ce643c38cabb32248c403d4451ecc56286bbe19eac50424dbebd` |
| `docs/phase0-audit14/git-diff-final.patch` | 64372 | `0683b873469dd04f406226c14a86e0e3aec4633374afc556cfe117987d5d1cf8` |
| `docs/phase0-audit14/git-status-final.txt` | 674 | `3f1c939aa84dc6b8f67fb48a355ed1b8c51ff293988b482ed604a6dec20b2bb3` |
| `docs/phase0-audit14/paper-replay.txt` | 507 | `539ba305db7d2a734e383bb0664899a54e3a2e9eab413d7360d63da0b2f3acae` |
| `docs/phase0-audit14/preservation-verification.json` | 943 | `8bf9d86bab7c8e1e0685ca96edc7cd7798ec7c2f044103ae4df4ff4d7d58c401` |
| `docs/phase0-audit14/prior-manifest-verification.json` | 39 | `1ec6e9a0209776122748c208e5ca040e2a9521f5e4f14bcbdb07455a452cee3c` |
| `docs/phase0-audit14/processes-after.txt` | 36763 | `6629a63a41eed11e272882cea01832fbce58447cd67218ce7d4b5b6bae4bc0a0` |
| `docs/phase0-audit14/processes-before.txt` | 33689 | `9b23a3bd279bb7f529b886d1a638e9ff06d62e829b4c528b3e383cc04ba60838` |
| `docs/phase0-audit14/regression.txt` | 13354 | `ecec9a2cec0384a1508f1bcf1012649750fa52eafe9cdd62d7018daf348e6b63` |
| `docs/phase0-audit14/reproduce_baseline.py` | 2422 | `c7159d29f86ffeb1a7a921f6435ba8eebfe0fc9710f6d42c4f9a456677963c07` |
| `docs/phase0-audit14/reproduced-empty-forward-readiness.json` | 2910 | `f2b3055fd56bf30df953b370b8a9d75cdc4e27f1fbe6a0bc6556ba4c8c337909` |
| `docs/phase0-audit14/reproduced-migration-evidence.json` | 1504 | `dabed2c56d197903a60a0ebaecc1837226bad985c0165c27bea3d02bcce620eb` |
| `docs/phase0-audit14/reproduced-paper-replay.json` | 506 | `23d111a9f3b2e0c537093ceb8c618dd84b0771ca47c8b7aa734a2099698bed3a` |
| `docs/phase0-audit14/reproduced-source-replay-repeat.json` | 303 | `ce2bd89d55c2df531983e076b3fb390c306cb26a1636e4ee337499fba2368180` |
| `docs/phase0-audit14/reproduced-source-replay.json` | 303 | `ce2bd89d55c2df531983e076b3fb390c306cb26a1636e4ee337499fba2368180` |
| `docs/phase0-audit14/source-migration-replay.txt` | 729 | `563708aea7e80d3a74926d47617a78fab1c44f08532a02ecf6aa819ddbe8e505` |
| `docs/phase0-audit14/verify_preservation.py` | 2755 | `80d99dfdcb74a919770a86c9f45f1f5078b72529720396c54684c299e76f9a59` |
| `docs/prices-order-books.md` | 35487 | `f42d9c7b33d29a8ba043fde14b67af8419be386be9c3f428c983a4724c700bbc` |
| `docs/remediation/AUDITOR_INSTRUCTIONS.md` | 4235 | `f4f33818ce9ac5138831bf778e781eb5d56b2a9304812b24aeb5bbd104bce32f` |
| `docs/remediation/DESIGN.md` | 2088 | `39a8910878a44f6708f334ccff6b5db96438018cdf89cacf12209187c7356b98` |
| `docs/remediation/ONCHAIN_ASSESSMENT.md` | 2658 | `8afbaa7ec881300339535fa22f34b40ce811538f8a1f671fcb7a04d9bebb4370` |
| `docs/remediation/browser-evidence.json` | 283 | `ee9196e4ed66c78e25bba90511a2486c8912786e095d4d37727f780eeea049d0` |
| `docs/remediation/browser-run.txt` | 284 | `9e6affd5c7088ac68812fba0d648fdd1fb3161ca8d594df93b76345ee1e58049` |
| `docs/remediation/contracts-official.md` | 15519 | `3e87e2f9273eb287874794638b195846f37389caa98da8c9004629ff096b8958` |
| `docs/remediation/empty-forward-readiness.json` | 2910 | `f2b3055fd56bf30df953b370b8a9d75cdc4e27f1fbe6a0bc6556ba4c8c337909` |
| `docs/remediation/health-desktop.png` | 157100 | `ec4e0d8b357fbb7238bd466f0d57cbab6b07e2ca59b9947e748cd4e917d2db48` |
| `docs/remediation/health-mobile.png` | 137907 | `c7ace60d0dc8e8839fae859f6deb7604ec50fd62a0c47cd53515401d370b19b3` |
| `docs/remediation/http-evidence.json` | 363 | `87d3fca519bb716b3749db0489a61f965fb8154045ed441f0430cc501c84a9d2` |
| `docs/remediation/http-run.txt` | 364 | `2be9ee550a471146a956f939b63914f0dd921e2170a9288c09c3a41306ded470` |
| `docs/remediation/implementation.patch` | 64372 | `0683b873469dd04f406226c14a86e0e3aec4633374afc556cfe117987d5d1cf8` |
| `docs/remediation/manifest.json` | 6584 | `bb54b24b9ba6687c19136dacd03438f5e27d5c46457a2b3293b6962fd5617e8f` |
| `docs/remediation/migration-evidence.json` | 1504 | `1aba35a38c9767a05a942c16752785ccda778b391d7c1da005d270d231f7c3b3` |
| `docs/remediation/onchain-official.md` | 13530 | `8e8d8b6a2b4de16516290a143e7521fd61775dc338b877c0d5def2ef1452baac` |
| `docs/remediation/original-audit-288a69f.md` | 8794 | `a4f1052a2fbc28a15a4a85c6bd15e3c94ec3531af6c88ed4f0d03bf96cefffc2` |
| `docs/remediation/paper-replay-run.txt` | 507 | `0946f8645878390101b7919214be0c9e17cb39a4f99e80fae9775d3e043e31d7` |
| `docs/remediation/paper-replay.json` | 506 | `34cb819f7fd7c9b2794252253713f8968ed55c73301d1aaa5bb12b8c46b6864e` |
| `docs/remediation/runtime-preservation.json` | 443 | `64f84b07cf40c805ef36cdd72470c37719a7bedb5958804af054889b7f9d434a` |
| `docs/remediation/source-evidence-run.txt` | 729 | `563708aea7e80d3a74926d47617a78fab1c44f08532a02ecf6aa819ddbe8e505` |
| `docs/remediation/source-replay-repeat.json` | 303 | `ce2bd89d55c2df531983e076b3fb390c306cb26a1636e4ee337499fba2368180` |
| `docs/remediation/source-replay.json` | 303 | `ce2bd89d55c2df531983e076b3fb390c306cb26a1636e4ee337499fba2368180` |
| `docs/remediation/synthetic-forward-export.json` | 16877 | `d332f0e431515e0076a70c9383c597354ff26488030b0fdf51039626c9f8eea4` |
| `docs/remediation/tests-attempt-1.txt` | 7401 | `869c8b9fb481623d42423a9bf2d0b2241c7b766d458ced607a7d28cdf0afcccf` |
| `docs/remediation/tests-attempt-2.txt` | 4771 | `cb83271fa254a157df6f84cb1d6f4fa1ab6be4846cfac9b501816c358b82b08b` |
| `docs/remediation/tests-attempt-3.txt` | 11199 | `cf190970fb279b657b7a7da88a2277d14a2c556387ff7d4a3f73e35b2e139525` |
| `docs/remediation/tests-attempt-4.txt` | 11199 | `898cec314238db7ecd8457259c132c6464f1c68fc62a8b76aafc7b0a792eb53a` |
| `docs/remediation/tests-attempt-5.txt` | 11199 | `afc4893bf2a2b3870317a2264ce19dd889f3e8e9a18f62cdced6829fa574d27c` |
| `docs/remediation/tests-attempt-6.txt` | 11199 | `8838d86cddbafe5383a42b1363b03a0066d7757ae7fd0769bb2111dd7abf2b7f` |
| `docs/remediation/tests-attempt-7.txt` | 12567 | `a4036622dfe793e24135c3f5d90ffc3486018256977650ea823af07773035b3d` |
| `docs/remediation/tests-attempt-8.txt` | 12567 | `7df7600eafe17e352405c87a25dc5d73dbdd46ebe8e774a126adf24916b0f183` |
| `docs/remediation/tests-attempt-9.txt` | 12567 | `5bfb36547b3534c3a082850a2ac1ccc2b673e7674d83a684153d0a88cc9869d7` |
| `docs/remediation/tests-final.txt` | 13354 | `a8343ea7b96ae5a8a147b3cd16d2290cbc8d7c3dce9564bc5f48071aa6af1fa7` |
| `docs/test-run-accounting-review.txt` | 1787 | `cc929dd16e121c3a4f4b6cbbe2703e7a60923c7dcfdaff8708fc0d58f7aae780` |
| `docs/test-run-expanded-retest.txt` | 4863 | `c023f56fe11ee684f33886e05241ca6aa5413e5b093ab846f6eba360e5e136b0` |
| `docs/test-run-expanded.txt` | 5606 | `6c0459a0ca99f6eacf98d597ddabda22b923c97e74da416255dd5bc6568f1f5a` |
| `docs/test-run-final.txt` | 4771 | `b0ade0f4f09076d8e8022d4604f4f7cadbb0b794f0e1494ff41307d0a8ecd8d5` |
| `docs/test-run-initial.txt` | 3333 | `b9f5ff4836dd8fb1f4a6673860fb5dec08ba6c9f16db6e3a2e4dde28f353a389` |
| `docs/test-run-model-review.txt` | 1787 | `8c9ae2f2617650f8914d1ed194d52ee2ddd12c66b0daa2c19d19ecb66ada21e1` |
| `docs/test-run-remediation.txt` | 1787 | `9591cd51d746741a68942c2cf8322f86e4a697d37a3315ac7ed4d7995ed27693` |
| `docs/wallet-activity.md` | 40636 | `1d6d88a6cd7b0ff16cd8f23fb45895ce7e4e40086199d2377908c5638a5d9c50` |
| `lab/__init__.py` | 69 | `eaed961d749af54e7d724f9811b920d190160b47dd7704af97c4184bf9a860c2` |
| `lab/accounting.py` | 5765 | `bd3e0f815147e63ca96c7426ed87c35134439af544369c6669885fd4e5426420` |
| `lab/config.py` | 1094 | `bb001ab90b0da7013e6d92b16821341e776833e55dc36ee5cf4a3c2880e3e461` |
| `lab/dashboard.html` | 16677 | `6966201fb8df2942e290277fbcc3aa52ab3598e38c54d1746e17b4b0cd8d800d` |
| `lab/engine.py` | 20328 | `572ad8b74ebc2c3c541febd926557e532144feee026f783561abffff23b33453` |
| `lab/integrity.py` | 18740 | `f810009ee438dd212799fe1deb2062abfebae351c2a55c1e19eb765e5e587d0a` |
| `lab/main.py` | 6914 | `ace7de4e156910ffd3664c3e7cf430c71edf6244a5d93844af9b632cce622d73` |
| `lab/migrations.py` | 6475 | `8b7b1bf30b55aea6b47936c9fae79c0014e0a7e0e80752c394b6df56d8b369df` |
| `lab/public.py` | 8904 | `a92c153547dcaae910e984eb105dd00820a4cc7bafc75438375c99870c8abe04` |
| `lab/store.py` | 5613 | `2cc53c3d1410c21e496dddb534c38b201f5447b455c75faf87cecf312ee5772c` |
| `lab/strategies.py` | 2200 | `d57d517928dda47caab816eedf407daa49286f458438124eb6947e5ecc1ff866` |
| `lab/validation.py` | 3071 | `ffe4d795d1aae4ab2cde078a6d137435701de3a1c1a186bfaa5448215a0a4362` |
| `lab/wallets.py` | 2502 | `419cc564e36e7d5ab2af250086e8a5e312b4606a09dad9ac996904c72cf990ed` |
| `tests/test_integrity.py` | 24611 | `9f80ccc4f8c33e5cba7bcbf399d5b5f04c2a92d3c387a7a502dac673c3eabd3f` |
| `tests/test_lab.py` | 17294 | `d10b0cc2c84d70dad9dbaae0014f93a33e0e8b1479bd9b2a000fe06a22d9a77a` |
| `tools/audit.py` | 3284 | `8c20e97d612cd2cfacdf6048858f27f449e238c7e461a2e9d91d764534e4f9b8` |
| `tools/browser_check.py` | 1425 | `9cf9bec91236ba42ec56cdad1afc448e688335ca0e98b382923a415ba94480ca` |
| `tools/configure.py` | 1146 | `20f81345eb8df4966a35cbd87deafb72a0ef03ab3df240edd86a466368026b81` |
| `tools/export_validation.py` | 776 | `f2859563a30af137d6e69f9cce3a2e774791939f8a6c24a46bcf503c3c7f152c` |
| `tools/fixture_validation.py` | 1263 | `758b695e65f127d301c85c3d85e37e4addb3fa80ea0524a69191df35dae7ffcf` |
| `tools/forward_report.py` | 3766 | `62986068d3c42f23b25f3cea3f76b30afdea06e70e22ed19be409e4850eeca40` |
| `tools/http_check.py` | 2601 | `4bd11596af3b9629a95c069e49051c550ba7692b959914f2cceb4ae811aa467c` |
| `tools/migrate_source.py` | 570 | `07bc130a558737559433fea7389739be5f28681e21a58ea7564ecffbd29adb12` |
| `tools/remediation_browser.py` | 1801 | `7933c4261c64a27266bf8ff6d9050ff5d2f8a0af1b14e26e825c36799956248a` |
| `tools/remediation_evidence.py` | 4281 | `4eceece71378f3e05dfc32476fd10f45f08de4bf8a2262c1b4a5b1b631200d3a` |
| `tools/source_verify.py` | 4106 | `42298dbbf535d3356fe3c56633fa9ba83e38a6d6b736376102d6c02f68e21994` |

## Final preservation result

All **149 pre-existing project files** matched original size/SHA-256 after
preparation; zero missing or changed original files. Tracked diff unchanged;
`git diff --check` exit 0. Branch/HEAD unchanged. All five older manifests match.
Only the four requested files in docs/external-independent-review/ were added.
Both runtime/backup byte hashes remain as listed above. Neither was opened through
SQLite or modified; no migration, test, app/worker/browser startup, external request,
package installation, process control or Git write operation was performed.

