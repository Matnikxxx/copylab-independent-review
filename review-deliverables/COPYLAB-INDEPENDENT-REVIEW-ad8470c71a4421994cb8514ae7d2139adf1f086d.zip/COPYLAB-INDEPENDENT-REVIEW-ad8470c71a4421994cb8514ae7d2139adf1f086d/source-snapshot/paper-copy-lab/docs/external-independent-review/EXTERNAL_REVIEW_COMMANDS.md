# External review commands — offline disposable execution

**This package is preparation for independent review. It is not an independent audit, does not resolve Audit 14, and does not authorise Phase 1A.**

**Commands below are instructions, not commands executed during package preparation.**
Review each script first. Use Bash on Linux, no sudo, no application/collector startup.
Keep original repository unavailable to the test sandbox except the initial read-only
snapshot operation. Provision an OS/container network-deny policy before testing; merely
setting proxy variables does not prove offline isolation. If isolation cannot be established,
report BLOCKED rather than silently allowing network or original DB access.

## 1. Identity and disposable input snapshot

Do not use git clone/checkout HEAD alone: untracked remediation would be missing.
The commands copy only this project; no other Polymarket repository is needed.

```bash
set -euo pipefail
export SOURCE=/home/user/paper-copy-lab
export GIT_OPTIONAL_LOCKS=0 PYTHONDONTWRITEBYTECODE=1
# Do not inherit a PYTHONPATH pointing to an original/other repository.
unset PYTHONPATH
[ "$(git -C "$SOURCE" branch --show-current)" = main ]
[ "$(git -C "$SOURCE" rev-parse HEAD)" = 288a69f64c24438cfe69ea176e6f3d6ce7333499 ]
export REVIEW_ROOT="$(mktemp -d /tmp/copylab-external-review.XXXXXXXX)"
export SNAPSHOT="$REVIEW_ROOT/input" WORK="$REVIEW_ROOT/work" RESULTS="$REVIEW_ROOT/results"
mkdir "$RESULTS"
git -C "$SOURCE" status --short > "$RESULTS/source-git-status.txt"
git -C "$SOURCE" diff --no-ext-diff > "$RESULTS/source-tracked.patch"
python3 -B - <<'PY'
import os,shutil,json,hashlib
from pathlib import Path
src=Path(os.environ['SOURCE']).resolve(); dest=Path(os.environ['SNAPSHOT'])
assert src==Path('/home/user/paper-copy-lab') and not dest.exists()
shutil.copytree(src,dest,ignore=shutil.ignore_patterns('.git','data','__pycache__',
    'node_modules','.cache','.venv'))
# Preserve all supplied source/evidence bytes; execution uses another copy.
manifest={str(p.relative_to(dest)):hashlib.sha256(p.read_bytes()).hexdigest()
          for p in dest.rglob('*') if p.is_file()}
Path(os.environ['RESULTS'],'input-hashes.json').write_text(json.dumps(manifest,indent=2))
shutil.copytree(dest,Path(os.environ['WORK']))
assert not (Path(os.environ['WORK'])/'data').exists()
PY
cd "$WORK"
python3 -B -c 'import sys,sqlite3; print(sys.version); print(sqlite3.sqlite_version)'
```

Keep SNAPSHOT untouched. Transfer input + source status/patch + input-hashes to the
external auditor if needed; these contain all code/evidence but no runtime DB or .git.
Manifests that include data/ entries cannot fully validate in this redacted snapshot;
record those as deliberately unavailable, not as successfully checked entries. Source
identity is established by working-tree hashes plus the captured Git metadata, not an
invented clean commit in the copy. Persist REVIEW_ROOT before ending the session;
/tmp is disposable, not a durable evidence archive.

## 2. Supplied backend defect probes (A14-01–08)

```bash
cd "$WORK"
rm -f docs/phase0-audit14/adversarial-results.json
set +e
python3 -B docs/phase0-audit14/adversarial_checks.py > "$RESULTS/backend.log" 2>&1
rc=$?
set -e
printf '%s\n' "$rc" > "$RESULTS/backend.exit"
cat "$RESULTS/backend.log"
cp docs/phase0-audit14/adversarial-results.json "$RESULTS/backend.json"
```

Review the log even if rc=0. The harness records eight defect booleans; it does not assert
the desired invariant for every case. A successful harness exit is not a system PASS.
Output overwrites only WORK's old evidence copies. Compare results to TEST_MATRIX and
SNAPSHOT. Record any missing output rather than trusting a stale copied JSON after failure.
A robust reviewer should delete the WORK output **before** execution (only the copy), or
check its modification time, and should write independently authored variants. Never
remove the SNAPSHOT or original historical output. No code fixes are permitted.

## 3. Browser probe (A14-09)

If not provisioned, optional dependency setup in the review environment only:

```bash
python3 -m venv "$REVIEW_ROOT/venv"
"$REVIEW_ROOT/venv/bin/python" -m pip install playwright
"$REVIEW_ROOT/venv/bin/python" -m playwright install chromium
"$REVIEW_ROOT/venv/bin/python" -m pip freeze > "$RESULTS/python-dependencies.txt"
export PATH="$REVIEW_ROOT/venv/bin:$PATH"
```

No pin is supplied: record the exact resolution/browser build. If browser/system libraries
cannot be safely installed, mark browser case BLOCKED; historical screenshot is not a
replacement. After provisioning, enforce offline isolation before running the probe.

```bash
cd "$WORK"
# Remove only generated copies to prevent stale-result confusion.
rm -f docs/phase0-audit14/dashboard-results.json docs/phase0-audit14/dashboard-stale-health.png
set +e
python3 -B docs/phase0-audit14/dashboard_probe.py > "$RESULTS/browser.log" 2>&1
rc=$?
set -e
printf '%s\n' "$rc" > "$RESULTS/browser.exit"
cat "$RESULTS/browser.log"
[ ! -f docs/phase0-audit14/dashboard-results.json ] || cp docs/phase0-audit14/dashboard-results.json "$RESULTS/browser.json"
[ ! -f docs/phase0-audit14/dashboard-stale-health.png ] || cp docs/phase0-audit14/dashboard-stale-health.png "$RESULTS/"
```

The probe invokes App.state as a serializer on a namespace; it does not construct App,
run main, start a server or collect data. All browser requests are intercepted. The .test
URL is synthetic and must never reach the network. Expected current stale Healthy=true.

## 4. A14-10 diagnostic — disposable Store-only instrumentation, no actual App

No existing dynamic reproducer is supplied in historical evidence. The following is
an **unexecuted proposed diagnostic**, not a verified test. Inspect/adapt it independently.
It invokes main with its App factory replaced by a Store-only stub. It never constructs
real App, starts a server/collector or runs an application loop. Parent owns the lock;
child must report refusal, but current ordering creates the temporary DB first.

```bash
cd "$WORK"
python3 -B - <<'PY' > "$RESULTS/startup-order.log" 2>&1
import fcntl,tempfile,subprocess,sys,json
from pathlib import Path
child = r"""
import sys,json
from pathlib import Path
from types import SimpleNamespace
from lab.store import Store
from lab import main as m
p=Path(sys.argv[1]); stores=[]
def store_only(path,config):
 s=Store(path,config); stores.append(s); return SimpleNamespace(s=s)
m.App=store_only
sys.argv=['store-only-lock-diagnostic','--db',str(p)]
try:
 m.main()
 raise AssertionError('lock should have refused the child before any worker code')
except SystemExit as e:
 print(json.dumps({'lock_refusal':str(e),'db_created_before_refusal':p.exists(),
                   'store_initializers':len(stores),'actual_App_constructed':False}))
 assert 'Another collector' in str(e)
 assert p.exists() and len(stores)==1
finally:
 for s in stores:s.db.close()
"""
with tempfile.TemporaryDirectory(prefix='copylab-lock-review-') as t:
 p=Path(t)/'fixture.sqlite'
 with open(str(p)+'.worker.lock','a') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  result=subprocess.run([sys.executable,'-B','-c',child,str(p)],capture_output=True,text=True,timeout=20)
  print(result.stdout);print(result.stderr);print('child_exit',result.returncode)
  assert result.returncode==0
PY
```

Expected current diagnostic: db_created_before_refusal=true, store_initializers=1,
actual_App_constructed=false, refusal contains 'Another collector', child_exit=0.
This confirms pre-lock Store invocation under instrumented ordering, not every startup
path. Inspect real App.__init__, backup return before lock, migration ownership and
Store side effects separately. Future safe ordering would refuse before Store invocation
and keep the DB absent; changing expectations to match a fix requires a separate review,
not implementing that fix here. Additional alias/crash/backup/read-only tests are missing.

## 5. Optional positive regression/fixture baselines (copied source only)

Inspect first. One existing test constructs App with a synthetic fixture DB solely to
assert immediate rejection; it does not run an app loop/worker. If the review's safety
policy prohibits even that constructor, do not run the whole suite: document the exclusion
and run individually vetted tests instead. Never weaken or delete the assertion.

```bash
cd "$WORK"
python3 -B -m unittest discover -s tests -v > "$RESULTS/regression.log" 2>&1
python3 -B tools/remediation_evidence.py > "$RESULTS/source-migration.log" 2>&1
python3 -B tools/fixture_validation.py > "$RESULTS/paper.log" 2>&1
cp docs/remediation/source-replay*.json docs/remediation/migration-evidence.json docs/remediation/paper-replay.json "$RESULTS/"
```

Historical expected outputs: 119 tests, zero fail/error/skip; source events=10,
cash=realized="3/2", raw observations=2, errors=[]; paper fills=500, portfolios=10,
errors=[]; disposable migration reports legacy preservation. Run commands individually
and record exit codes even on failure; Bash -e may otherwise stop the sequence. Baseline
green is compatible with all documented defects. Never run reproduce_baseline.py here:
it expects ROOT/data files, omitted from this safe review snapshot.

## 6. Dangerous/default-path commands — do not run against originals

| Command / pattern | Hazard | Safe review alternative |
|---|---|---|
| python -m lab.main; --once; --backup | Creates App/Store before lock, can collect or mutate DB; backup is not a read-only startup mode | Inspect source; only Store-only disposable diagnostic above; no actual startup |
| tools/configure.py [--db default] | Opens/mutates data/lab.sqlite settings/audit | Inspect only; if later testing needed, explicit temp fixture, no real config changes |
| tools/migrate_source.py --db REAL --backup ... | Real migration and backup writes | Existing migration tests/generator on new synthetic legacy fixture only |
| Store() or sqlite3.connect('data/lab.sqlite') | Default actual path, may create/write before refusal | Always absolute temp path; read-only SQLite only on explicit copies if separately authorised |
| tools/audit.py with no args | Opens runtime DB read-only and overwrites docs/audit-evidence.json | Use explicit temporary --db and new --out; supplied backend fixture already does this |
| tools/source_verify.py / tools/export_validation.py pointed at REAL | Reads actual DB; output path may overwrite evidence | Only explicit disposable --db and new --out, no original handles |
| tools/forward_report.py | Hardcoded data/lab.sqlite sqlite connect; overwrites forward reports | Inspect archived reports; don't run it |
| tools/http_check.py | Starts actual disposable application/server | Not allowed in this review; do not substitute it for isolated probes |
| tools/browser_check.py | Browser target assumptions and output overwrite | Use vetted intercepted dashboard_probe.py in WORK only |
| tools/remediation_browser.py | Constructs real App even with disposable DB, overwrites prior outputs | Use pure-state dashboard_probe.py instead |
| original evidence/adversarial/dashboard/verify_preservation scripts in place | Overwrite archived audit evidence/status | Run only reviewed scripts in WORK with snapshot retained; do not rerun original preservation generator |
| docs/phase0-audit14/reproduce_baseline.py | Reads/copies ROOT/data and overwrites reports | Separate commands in §5, data omitted; no original DB copy needed |
| README run/config/forward commands, curl, Collector.cycle, App.run | May start monitoring/query wallets/modify state | Read instructions critically; offline fake APIs and no real wallet addresses |

## 7. Preserve and report

Rehash SNAPSHOT against RESULTS/input-hashes.json after testing. Work outputs may change;
SNAPSHOT and original source may not. Compare original branch/HEAD/status, tracked diff
and all original hashes from the preparation index using read-only file access only if
the review runs on the owner machine. No need to open a runtime DB to hash its bytes.
Store independent report/results outside original repo. Keep failing outputs, environment,
commands and explicit not-run cases. No application, worker, wallet query or fix permitted.
