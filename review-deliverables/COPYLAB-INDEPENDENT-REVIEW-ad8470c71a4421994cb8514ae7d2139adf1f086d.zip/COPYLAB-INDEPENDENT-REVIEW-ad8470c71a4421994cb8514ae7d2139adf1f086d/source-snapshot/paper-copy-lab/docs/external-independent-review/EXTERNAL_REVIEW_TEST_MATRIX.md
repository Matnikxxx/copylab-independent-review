# External review test matrix

**This package is preparation for independent review. It is not an independent audit, does not resolve Audit 14, and does not authorise Phase 1A.**

## Reading the outcomes

Historical signatures below are copied from supplied evidence, not newly executed results.
CONFIRMED means the reviewer independently observed the defect; it is NOT a system PASS.
REJECTED needs code and counter-evidence; RECLASSIFIED needs a justified severity/scope
change. A missing dependency/untested scenario is NOT REPRODUCED/BLOCKED, not REJECTED.
Harness exit=0 can mean a defect was successfully reproduced. Assertions for safe behavior
must be distinguished from diagnostic assertions describing the currently broken behavior.

All backend fixtures use temporary DBs and symbolic labels. No manufactured transaction,
block or log identifier should be presented as a real observation. External reviewer should
implement variants independently after understanding the supplied minimal reproductions.

## Source map, setup, corrected invariant and missing tests

| ID / reported severity | Actual code to inspect | Isolated setup | Desired safe outcome (not claimed implemented) | Additional tests/challenges |
|---|---|---|---|---|
| A14-01 — HIGH | tools/audit.py replay; lab/accounting.py metrics/fill; lab/store.py ledger schema | Insert valid fixture BUY; change only ledger.realized to 999; compare metrics with standalone Fraction checker. | Corrupt ledger must produce nonzero verifier exit and an exact ledger-realized mismatch; valid ledgers still pass. | Cash/cost/quantity/partial exit/settlement/rounding; missing/extra/orphan rows, closed→open, wrong model/track; authoritative inputs must not validate themselves. |
| A14-02 — HIGH | tools/source_verify.py verify; migrations.py source_movements/events/effects; integrity.py lifecycle | Insert movement with null/nonexistent parent and cash/realized 999; inspect complete row coverage. | Any orphan must be reported by row ID/reason; no clean errors=[] result. | Wrong parent/wallet/token/provenance/leg; duplicate effects; missing parent movements; unbalanced group; closed-position semantics. |
| A14-03 — HIGH, synthetic-only | integrity.py synthetic_event/lifecycle; source_verify.py leg replay | Submit one-token SPLIT without market/outcome mapping or complete operation specification. | Incomplete/unsupported evidence held/rejected with zero partial journal effects; fully specified symbolic fixture passes. | Multiple outcome/configurations, wrong collateral/quantities, missing leg, fractional basis; not every operation is binary; no fabricated on-chain evidence. |
| A14-04 — HIGH, synthetic-only | integrity.py lifecycle REDEEM/RESOLUTION; source_verify.py; engine.py settle production hold | Buy ten fixture shares at cost 5; redeem them for 20 without payout/finality/operation proof. | Unproved/inconsistent payout quarantined; resolution alone creates no credit; duplicate economic redemption rejected. | Fractional payouts, deductions, wrong token/outcome, missing finality, restart and repeated effects under new IDs. |
| A14-05 — MEDIUM | integrity.py synthetic_event conflict branch; event_links/observations/reconciliation schema | Repeat identity/order with distinctive conflicting payload and no observation; search all durable tables, not only old event. | Both raw original/conflict evidence and metadata retrievable; no silent winner. | Field ordering, missing/extra/null/empty/numeric representations; linked/unlinked evidence, repeated conflict and restart. |
| A14-06 — MEDIUM | public.py PublicClient.get; integrity.py collect success and exception paths; transport_deliveries | Fake get supplies three 503 attempt bodies then raises; inspect durable delivery rows. | Every received attempt retained with scope/status/error/timing; incomplete batch stays incomplete. | Timeout/partial response/malformed/empty bodies, final success, Retry-After, process restart and persistence failure; evidence UNKNOWN if crash before receipt persistence. |
| A14-07 — MEDIUM | integrity.py collect batch lookup/frontier; public.py baseline scheduler | Interrupt CLOSED positions batch; request OPEN, record actual request parameters and returned batch. | Changed scope rejects or creates independent batch; no scope substitution/mixed pages/premature frontier. | Wallet/time/filter/archive/dust/API/pagination changes; identical resume, crash, error, partial page, absent terminal proof. |
| A14-08 — LOW | migrations.py table_digests/upgrade_existing; migration tests | Compare generic SQLite BLOB b'A' to TEXT "b'A'" digest in one-value table. | Different actual storage types yield distinct digest; type-changing disposable migration preservation check fails. | NULL/int/real/text/blob, embedded zero bytes, empty types/table, Unicode, large BLOB, composite key, deterministic multiset/framing and schema coverage scope. |
| A14-09 — MEDIUM | dashboard.html health renderer; main.py state warnings; store.py health; public.py collector health | Intercept real renderer with ts=0, ok=1 fixture; no App construction or backend. | No stale green Healthy; TTL/status/hold/completeness/audit/readiness dimensions explicit. | Fresh/stale/failure/none, incomplete batch, held wallet, unknown source, unavailable DB, stopped worker, reachable-but-stale API. |
| A14-10 — MEDIUM, inspection-only baseline | main.py main/App/backup/lock; store.py init/backup; migrations.py worker ownership | Inspect ordering; independently author/inspect Store-only concurrent diagnostic in COMMANDS §4. | Competing process cannot mutate/init before ownership; refusal before Store writes or explicit read-only path. | New/V3/V2, backup/migration entry points, path aliases, init crash/restart, lock failure and dashboard concurrency; current diagnostic is instrumented, not complete startup proof. |

## Exact archived backend signatures

Run COMMANDS §2 in WORK; locate each case by name, not ordering.

### A14-02 — `source_verifier_orphan_movement`

```json
{
  "case": "source_verifier_orphan_movement",
  "observed": {
    "classification": "synthetic",
    "third_party_audit": false,
    "applied_source_events": 0,
    "source_cash": "0",
    "source_realized": "0",
    "raw_observations": 0,
    "errors": [],
    "scope": "independent arithmetic and durable-capture invariants; not chain completeness or market performance"
  },
  "defect_reproduced": true,
  "classification": "synthetic adversarial evidence, NOT market data"
}
```

### A14-01 — `paper_verifier_misses_realized_ledger_corruption`

```json
{
  "case": "paper_verifier_misses_realized_ledger_corruption",
  "observed": {
    "verifier_exit": 0,
    "verifier_errors": [],
    "reported_equity": "1000.00000000",
    "reported_total_pnl": "999.00000000"
  },
  "defect_reproduced": true,
  "classification": "synthetic adversarial evidence, NOT market data"
}
```

### A14-03 — `single_sided_split_accepted`

```json
{
  "case": "single_sided_split_accepted",
  "observed": {
    "state": "applied",
    "inventory": [
      {
        "token": "T",
        "qty": "10.00000000"
      }
    ],
    "verifier": {
      "classification": "synthetic",
      "third_party_audit": false,
      "applied_source_events": 1,
      "source_cash": "-5",
      "source_realized": "0",
      "raw_observations": 0,
      "errors": [],
      "scope": "independent arithmetic and durable-capture invariants; not chain completeness or market performance"
    }
  },
  "defect_reproduced": true,
  "classification": "synthetic adversarial evidence, NOT market data"
}
```

### A14-04 — `unproved_out_of_range_redemption_accepted`

```json
{
  "case": "unproved_out_of_range_redemption_accepted",
  "observed": {
    "state": "applied",
    "verifier": {
      "classification": "synthetic",
      "third_party_audit": false,
      "applied_source_events": 2,
      "source_cash": "15",
      "source_realized": "15",
      "raw_observations": 0,
      "errors": [],
      "scope": "independent arithmetic and durable-capture invariants; not chain completeness or market performance"
    }
  },
  "defect_reproduced": true,
  "classification": "synthetic adversarial evidence, NOT market data"
}
```

### A14-05 — `conflicting_certificate_payload_lost`

```json
{
  "case": "conflicting_certificate_payload_lost",
  "observed": {
    "state": "conflict",
    "conflicting_payload_retained": false
  },
  "defect_reproduced": true,
  "classification": "synthetic adversarial evidence, NOT market data"
}
```

### A14-06 — `all_failed_retry_bodies_lost`

```json
{
  "case": "all_failed_retry_bodies_lost",
  "observed": {
    "raw_bodies": [
      "last-fixture-error"
    ],
    "batch_status": "incomplete"
  },
  "defect_reproduced": true,
  "classification": "synthetic adversarial evidence, NOT market data"
}
```

### A14-07 — `pending_batch_changes_requested_scope`

```json
{
  "case": "pending_batch_changes_requested_scope",
  "observed": {
    "requested": "OPEN",
    "actually_resumed": {
      "status": "CLOSED",
      "user": "fixture-wallet",
      "cursor": "fixture-cursor"
    }
  },
  "defect_reproduced": true,
  "classification": "synthetic adversarial evidence, NOT market data"
}
```

### A14-08 — `migration_digest_storage_type_collision`

```json
{
  "case": "migration_digest_storage_type_collision",
  "observed": {
    "blob_digest": {
      "fixture": "fe21b3a17c7cc0eb8df88924e2835617fdbffa0018804876726ff74b74edecad"
    },
    "text_digest": {
      "fixture": "fe21b3a17c7cc0eb8df88924e2835617fdbffa0018804876726ff74b74edecad"
    }
  },
  "defect_reproduced": true,
  "classification": "synthetic adversarial evidence, NOT market data"
}
```

### Containment control — `production_execute_exit_settle_restart_containment`

```json
{
  "case": "production_execute_exit_settle_restart_containment",
  "observed": {
    "allowed": false,
    "fills": 0,
    "position_before_restart": {
      "qty": "2",
      "cost": "1"
    },
    "position_after_restart": {
      "qty": "2",
      "cost": "1"
    },
    "holds": 1
  },
  "defect_reproduced": false,
  "classification": "synthetic adversarial evidence, NOT market data"
}
```

### Containment control — `production_to_synthetic_refused`

```json
{
  "case": "production_to_synthetic_refused",
  "observed": {
    "refused": true
  },
  "defect_reproduced": false,
  "classification": "synthetic adversarial evidence, NOT market data"
}
```

The conflict result proves absence only in searched tables; independently inspect raw
observations, alternate conflict/audit storage and linked-evidence branches. Retry probe
models the client attempt_log contract; independently mock subprocess outcomes to challenge
PublicClient itself. Backend harness does not test A14-09/10. For digest reproduction,
observe SQLite typeof rather than assuming Python input types survive column affinity.

## Browser exact archived signature (A14-09)

```json
{
  "classification": "synthetic UI fixtures, no app startup",
  "real_network_requests": 0,
  "api_forward_validation_ready": false,
  "stale_health_rendered_Healthy": true,
  "last_warning": "Token-finality settlements are supported; source merges/conversions quarantine monitoring rather than fabricate trades.",
  "javascript_errors": [],
  "defect_reproduced": true
}
```

Current expected renderer: at least one exact Healthy label for the ts=0 row. A screenshot
and no JS errors support that narrow observation; readiness=false and interception do not
prove every aggregate health branch is truthful. Desired invariant is stale != Healthy.

## A14-10 expected diagnostic and missing material

Historical evidence contains static ordering only. No independently verified concurrency
result is supplied. COMMANDS §4 provides an unexecuted, Store-only instrumentation sketch:
expected current output DB created before refusal=true; initializer count=1; real App
constructed=false; child refusal contains Another collector; child_exit=0. Actual refusal
without any new DB/schema/config writes is the desired corrected outcome. Reviewer must
validate/extend the sketch; do not fabricate an execution result for this package.

## Positive and guard controls

- Valid fixture baseline: 119 tests, 0 failures/errors/skips historically. This includes
  a constructor-rejection test, not a worker startup. Exact counts can change only with
  inspected source changes; explain any mismatch and preserve output.
- Source: applied_source_events=10, source_cash=source_realized="3/2", observations=2,
  errors=[]; repeat report byte-equal. This does not certify operation semantics/completeness.
- Paper: fills_replayed=500, portfolios_checked=10, errors=[], integrity=ok, synthetic.
- Disposable migration: version 3, backup_verified and legacy_rows_preserved true, fixture
  holds present. Existing text fixture success does not disprove type-collision finding.
- Guard controls: production-mode fixture allowed=false; fills=0; qty/cost unchanged 2/1
  across reopen; hold=1. Production→synthetic reclassification refused. Never disable guards.

## H01–H05 review matrix

| ID | Required local challenge | Independent external capability needed | Allowed conclusion without capability |
|---|---|---|---|
| H01 | Page failures inside/outside transaction, terminal cursor, late events and filters; challenge A14-06/07 | Exhaustive historical/checkpoint/balance coverage | Durable received capture may be confirmed; source completeness remains BLOCKED |
| H02 | Same-looking distinct rows, numeric variants, tied opposing events, repeats/conflicts | Canonical real event identity/order/attribution/finality | Multiplicity/quarantine may be confirmed; production identity remains BLOCKED |
| H03 | All typed operations, basis carry, fees, overlaps, missing legs, payouts, corrections | Real version-specific full lifecycle decoder evidence | Synthetic arithmetic only; real lifecycle completion BLOCKED |
| H04 | Disable/re-enable short/long gaps; missed buy/sell/merge; restart/remove open inventory | Complete source history and reviewed reconstruction | Holds/history may be confirmed; actual gap recovery BLOCKED |
| H05 | Independently inspect both verifier implementations; corrupt source/paper records | Separate auditor and later approved real wallet/forward/execution observations | Positive arithmetic fixtures only; no independently audited system/forward validation |

## Per-case results worksheet

Case ID; reviewer; snapshot hash; inspected functions; independent fixture source; command;
expected broken behavior; expected safe behavior; actual raw output/exit; relevant DB rows;
disposition CONFIRMED/REJECTED/RECLASSIFIED or NOT RUN/BLOCKED; own severity and rationale;
additional affected paths; proposed-fix sufficiency; missing tests; limitations; evidence hash.

Stop on unsafe path, unexpected preservation mismatch or attempted real network/database
access. No fix is authorised even after a valid finding is confirmed.
