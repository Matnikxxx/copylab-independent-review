# Audit findings register

**Review status: PARTIAL.** Author review, targeted adversarial regression tests and an independent **process/algorithm** (Fraction replay without importing production accounting) were used. No separate human or separately instructed model auditor was available in this session. Do not label the requested third-party/independent audit complete.

## Confirmed issues remediated and retested

| ID | Severity | Evidence / underlying issue | Remediation | Retest evidence |
|---|---|---|---|---|
| R01 | High | Source sell denominator originally used only post-start buys, ignoring pre-existing inventory | Stable two-read inventory admission before copying; v2 current_size field; mismatches/out-of-order activity now quarantine monitoring | baseline_current_size_v2, baseline_not_admitted_during_activity, hybrid_partial_and_full_source_sell, source_inventory_mismatch_blocks_sell |
| R02 | High | Selective wallet qualification originally read own copied exits, causing no-entry bootstrap deadlock | Public source CLOSED positions (including archived), captured with arrival time, now supply B/E stats | selective_uses_source_performance; real source qualification awaits supplied wallets |
| R03 | Medium | Win rate counted partial exit fills rather than closed cycles | Added persisted closed_positions cycles; sums all partial exits; separate exit-fill count | closed_position_winrate_not_partial_fills, reopened_position_separate_lifecycle |
| R04 | High | A stale fetched pending order/event could be processed again by a second caller | Status rechecked under BEGIN IMMEDIATE; per-DB application worker lock | order_reexecution_does_not_duplicate; transaction_crash_rolls_back_all_writes; idempotent_events |
| R05 | High | Same displayed depth could be reused across sequential orders in one world | Deplete same-book participation allowance using already simulated fills | same_book_liquidity_not_reused; partial_depth |
| R06 | High | Execution risk could change between decision and fill | Fee-inclusive risk recheck with own reservation excluded; stale position and monitoring-health guards | execution_rechecks_drawdown; disabled_pending_buys; stale_portfolio_pauses_entries |
| R07 | High | Source nontrade lifecycle could be mistaken for trade-only inventory continuity | Read activity before publishing trades; nontrade changes disable monitoring and audit payload; no fabricated merge fills | Runtime code inspected; no supplied-wallet real lifecycle case; complete reconciliation remains H03 |
| R08 | Medium | Old /positions and /trades assumptions would fail after v1 retirement | Official v2 schema and cursor envelopes; obsolete route never called | Live API checks and archived official spec; baseline_current_size_v2; pagination_duplicate_cursor_fails |
| R09 | Medium | No payout close-out for zero/fractional resolution | `/v2/tokens` finality gates idempotent immediate paper redemption and cancels pending orders | settlement_fractional_payout_and_idempotence, settlement_losing_token, unresolved_not_settled |
| R10 | Medium | Enabling after disabled interval could trust stale source denominator | Requires new baseline; disabling/removing immediately cancels pending buys | enable_rebaselines_and_preserves_history; old copied holdings still need H04 reconciliation |

Remediated does not mean complete external verification. R01's baseline is conservative but not atomic; H01 remains. R04's process locking is not cluster-safe. R07 is containment, not lifecycle support.

## Open acceptance blockers and limitations

| ID | Severity | Finding and evidence | Required work / current containment |
|---|---|---|---|
| H01 | High | Public position snapshots and trade feeds do not offer a shared atomic source checkpoint. A quiet window can miss upstream-late data. All live wallet cases remain untested | Verify `/v2/status` freshness and align source block/log inventory; otherwise quarantine inconsistent wallets. Quiet admission and mismatch quarantine are mitigation, not proof |
| H02 | High | Trade response has no unique log index in documented schema. Identity can collapse legitimately identical economic rows; timestamp/event-key order is not chain log order for same-second opposing trades | Obtain authoritative unique log ordering or explicitly quarantine ambiguous groups; add real-case reconciliation fixtures. Never claim lossless event lifecycle |
| H03 | High | Full SPLIT/MERGE/REDEEM/conversion/neg-risk/combo source lifecycle is **not implemented**. Nontrade activity quarantines instead | Implement typed lifecycle state machine, position provenance, correction handling and independent tests; no double-counting payouts |
| H04 | High | Monitoring gaps and enable/rebaseline can leave old copied positions out of sync with missed source sells | Replay complete missed source activity with no stale entry fills; reconcile copied lots separately; require operator review in current build |
| H05 | High | Independent third-party/agent audit not completed; no user wallet forward fills available | Assign separate auditor with all specification and evidence; supply wallets; observe real copy events, latency, fees, partial fills, restarts and payouts |
| M01 | Medium | Overlap is 300 seconds; very late upstream rows beyond it may be missed; no reorg rollback | Persist full cursor/reconciliation runs, periodic deep scans and chain provenance. Stale events do not receive historical executable fills |
| M02 | Medium | Executable simulation uses 10% displayed depth, not a calibrated latency/queue/hidden-liquidity/adverse-selection model | Collect forward latency and book sequences, fit bounds, document uncertainty; no claim fills were genuinely obtainable |
| M03 | Medium | Marks use top bid, not depth-liquidated value; unpriced fallback carries cost and can bias ranking | Flagging/entry pause implemented; suppress rankings for stale/unpriced worlds and add liquidation-value reports |
| M04 | Medium | Dashboard recent tables are capped (500 fills/orders, 100 events, 3,000 snapshots); contribution table is explicitly capped, not lifetime | Add paginated/history/export APIs and full-lifetime wallet contributions. DB metrics remain full-history |
| M05 | Medium | Risk defaults and strategies not empirically validated; correlation risk unsupported; copied model samples differ | Forward matched-window evaluation with sufficient sample sizes; do not choose a winner from this session |
| M06 | Medium | Runtime retry backoff exists, but Retry-After/adaptive quotas, archival retention, async I/O and load tests are absent | Add deterministic rate-limit/failure injection, storage policy and sustained-load evidence |
| M07 | Medium | No dashboard auth; CSRF token is readable to authorized page visitors | Keep trusted/local; use authenticated reverse proxy before remote hosting. No exchange credentials exist |
| M08 | Medium | Eight-place generic rounding / immediate final-token paper settlement are assumptions, not verified exchange-native fee/collateral rounding and finality delay | Verify per-protocol rounding and settlement timing, implement explicit policies with boundary tests |
| L01 | Low | Some settings remain code constants; config validator is basic; migration framework is only additive v1/v2 | Add versioned config schema and ordered future migrations; do not silently mutate existing run capital |

## Failed test history (preserved)

- Initial 21-test run: 20 pass / 1 error. Partial-depth fixture also violated minimum-liquidity rule. Corrected fixture to retain enough total liquidity while still producing a partial fill; risk threshold was not weakened.
- Expanded 44-test run: 42 pass / 2 fail. Daily-loss fixture hit position cap first; exposure fixture was exactly on permitted boundary. Adjusted fixtures to isolate intended limits. Subsequent run: 43 pass / 1 fail due decimal textual zero representation (`0E-8` vs `0.00000000`). Assert now compares numerical Decimal zero, not formatting.
- Browser initially failed to launch due missing OS `libnspr4`; installed Playwright Chromium system dependencies, then all nine page smoke checks passed. This was environment remediation, not test suppression.
- Final result is in `test-run-final.txt`; older failed logs remain. No tests were removed or disabled.

## Verification independence

`tools/audit.py` is a separately executed verifier using Python Fraction, SQL and fill replay without calling `Accounting.metrics`. `audit-fixture-evidence.json` records 500 synthetic fills, ten worlds and restored-DB replay with zero mismatches. `audit-evidence.json` describes production DB: zero fills. These must not be conflated. The replay doesn't establish real feed correctness, execution realism or strategy profitability.

---
## Coordinated H01–H05 remediation update (uncommitted; supersedes earlier mitigations)

Original findings and all historical failed evidence above are retained. Full changes,
acceptance mapping and residual limitations: `REMEDIATION_REPORT.md`.

| Finding | Current status | Evidence / remaining blocker |
|---|---|---|
| H01 | PARTIALLY RESOLVED | Durable pages/cursors/frontiers, baseline evidence, freshness, invalid CLOSED filter fixed. REST never establishes a trusted baseline; atomic exhaustive checkpoint unavailable. |
| H02 | PARTIALLY RESOLVED | Raw multiplicity/order preserved, ambiguity flags, no economic-hash production events, conflicts quarantine. No verified ordinary per-log adapter. |
| H03 | PARTIALLY RESOLVED | Explicit evidenced source leg accounting, provenance/effect dedup, resolution versus redemption, basis-preserving pure conversion, unknown/correction quarantine. Real contract decoding/coverage not certified. |
| H04 | PARTIALLY RESOLVED | Persistent gaps/history, reconciliation evidence and paper holds; enable cannot trust prior baseline; no historical fills. Missing real source history still requires audited adapter/operator review. |
| H05 | PARTIALLY RESOLVED | Reproducible synthetic tests, independent Fraction source/paper replay, migration evidence, raw forward export. Separate auditor, supplied wallets and real forward copy observations absent. |

Production copying is intentionally disabled, not falsely marked fixed. Synthetic
certificates are accepted only in synthetic DBs; application rejects those DBs.
Actual runtime was stopped gracefully and not migrated/restarted. No commit/push/PR.
Additional regressions discovered: old baseline tests expected unsafe admission;
fixtures changed to real response envelopes and stronger quarantine assertions, not
removed. Conversion leg arithmetic needed basis carry rather than a fictitious loss;
added dedicated tests and an independently calculated expected source result.
