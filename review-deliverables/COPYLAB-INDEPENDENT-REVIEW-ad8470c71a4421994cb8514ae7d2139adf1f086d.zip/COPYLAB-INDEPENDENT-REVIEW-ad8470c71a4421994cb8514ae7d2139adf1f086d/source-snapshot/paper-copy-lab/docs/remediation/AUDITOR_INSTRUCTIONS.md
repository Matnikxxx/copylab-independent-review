# Separate auditor reproduction instructions

This package was prepared by the implementing agent. Do not adopt its conclusions.
Reference HEAD: 288a69f64c24438cfe69ea176e6f3d6ce7333499. All changes uncommitted.
Original findings are archived in original-audit-288a69f.md; code/docs hashes in manifest.

## Isolation

Use a new disposable checkout/copy of the supplied source, never the user's runtime DB.
No keys/accounts/wallet addresses are needed. Do not run lab.main against runtime.
No network is needed except optional installation of Playwright; official documentation
extracts are included. Do not commit/push/deploy or silently approve by test count.
Fixture labels and ordinals are synthetic, not authoritative chain transactions/logs.

## Reproduce

From repo root with Python 3.11+ and curl installed:
1. `python3 -m unittest discover -s tests -v` → 119 tests, none skipped.
2. `python3 tools/remediation_evidence.py` → disposable source journal/migration fixtures,
   deterministic independent source replay; expected source cash=realized=3/2;
   migration preserves original table hashes, creates backup and holds; actual DB unused.
3. `python3 tools/fixture_validation.py` → 500 synthetic paper fills, ten worlds,
   backup/restore and separate Fraction replay (tools/audit.py).
4. `python3 tools/http_check.py --out docs/remediation/auditor-http.json` → disposable
   local HTTP integration, collector stubbed to no network. This is not deployment.
5. Optional browser: install Playwright + Chromium dependencies, then
   `python3 tools/remediation_browser.py`. All requests intercepted in-memory, nine pages.
6. Inspect failure logs; tests-attempt-1 retains original 2 baseline fixture errors.
   Check no original risk/strategy tests or thresholds were removed/relaxed.

## Independent challenge checklist

- Read implementations of both Fraction verifiers. They must not import production
  accounting; rerun with tampered journal/cash/positions/ordinals and verify rejection.
- Follow every legacy/REST ingress and settlement/exit/order path: prove no production
  observation can bypass Integrity.allowed(), which is false pending canonical adapter.
- Verify synthetic marker cannot convert production DB or start application. Fixture
  certification is intentionally NOT an on-chain identity validation implementation.
- Inject crashes at each page write/terminal frontier, restore and resume original
  cursor/filters. Duplicate receipts and all provider row multiplicity must remain.
- Distinguish complete durable capture from source completeness. Challenge late inserts,
  mutable pages, dust/archived/inactive omissions and stale status; no baseline admission.
- Reconstruct source journal independently: paid basis, sell WAC, carried conversion
  basis, no resolution payout twice, no transfer+descriptor double mutation. Complex
  transformations must quarantine when cost/effect mapping is incomplete.
- Verify every disabled/removed/re-enabled gap, legacy migration hold and source/paper
  difference retains evidence; missed sell must not create a historical paper fill.
- Verify migration lock, online backup verification, atomic DDL rollback and old rows
  preserved. Use temporary files only; no auto-upgrade of runtime.
- Inspect exact executable-book context for new fills. Missing legacy context stays null.
- Audit export classification: empty disposable production-classified run is NOT real
  forward validation; synthetic 500 fills are NOT market results.

## External work required before sign-off

Audit an authoritative source adapter independently: current contract/proxy/version/ABI,
full token universe, archive RPC log/balance completeness at a canonical block,
transaction/log/batch-item identity and event/API mapping, chain reorg/finality and
complete source operation coverage. Documentation addresses alone do not establish it.
No such adapter is installed. Do not simply flip allowed() or update SQL to 'verified'.

Issue a separate report with severity, evidence, disposition and retest. H05 cannot
close until this independent review and user-supplied-wallet forward observations
actually evaluate source/execution/restart/lifecycle behaviours. No profitability claim.
