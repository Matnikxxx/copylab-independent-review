# Public on-chain capability assessment — not adapter certification

Official documentation fetched during remediation (no wallet/account queries):
- https://docs.polymarket.com/resources/contracts.md → contracts-official.md
- https://docs.polymarket.com/resources/onchain-position-data.md → onchain-official.md
- Current endpoint contracts: https://data-api.polymarket.com/v2/openapi.json
- Cursor rules: https://docs.polymarket.com/api-reference/data-api/overview

Documentation lists Polygon CTF at 0x4D97DCd97eC945f40cF65F87097ACe5EA0476045,
PositionManager at 0x006F54F7f9A22e0000CC2AB60031000000ae9fEF,
CTF exchange at 0xE111180000d2663C0091e4f400237545B87B996B,
negative-risk CTF exchange at 0xe2222d279d744050d28e00520010520000310F59,
and Protocol V2 exchange at 0xe3333700cA9d93003F00f0F71f8515005F6c00Aa.
These are documented CONTRACT addresses, not invented monitored wallet addresses.
No contract bytecode/proxy implementation/deployment block was independently verified.

Gamma version selects CTF vs Protocol V2; field presence alone is not enough.
ERC-1155 TransferSingle/TransferBatch are balance authorities. OrderFilled,
OrdersMatched and FeeCharged provide exchange context, not additional balance deltas.
Lifecycle split/merge/convert/redeem descriptors must link underlying transfers.
MigrationConditionRegistered links old/new condition identifiers. Combo operations
and position-manager conversions require operation-specific mapping and cost allocation.

Canonical provenance would require chain ID, block number+hash, transaction position,
transaction hash, log index and batch-item/derived-leg discriminator where applicable.
No such fields are fabricated in this remediation. Fixture ordinals are explicitly
synthetic, not blockchain positions. Ordinary REST does not expose sufficient row IDs.
Combo activity documents tx_hash-log_index and block/log ordering, but is not an
ordinary trade adapter and cannot prove full wallet coverage by itself.

Still unverified: complete contract/ABI history, block-consistent balance reads and
token discovery, archive RPC availability, range-log completeness, provider reorg
signals/finality, source/API-to-log mapping and all market-type lifecycle coverage.
No RPC provider was certified or user wallet queried. Existence of logs is not proof
of a complete index. Consequently NO production canonical adapter is installed.
All ordinary observations and legacy baselines fail closed. Pure evidenced lifecycle
leg accounting is exercised only in synthetic DBs; complex cash-generating conversions,
corrections and unsupported mappings quarantine rather than allocate speculative basis.
