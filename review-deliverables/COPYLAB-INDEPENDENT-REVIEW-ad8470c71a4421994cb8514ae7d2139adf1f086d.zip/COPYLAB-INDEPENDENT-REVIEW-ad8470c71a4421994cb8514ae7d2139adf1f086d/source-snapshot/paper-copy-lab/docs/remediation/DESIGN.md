# Coordinated remediation design (before schema changes)

Reference: 288a69f64c24438cfe69ea176e6f3d6ce7333499, main. No commit/deployment authorised.

Migration 3 adds separate observation/batch/page/delivery, baseline, event provenance,
source journal, monitoring/gap/reconciliation and paper-hold tables. Legacy tables and
rows remain unchanged. Existing v1/v2 files refuse automatic upgrade. An explicit
migration command requires exclusive worker lock, makes a verified online backup,
checks old-table row digests and applies all additions in one transaction. The actual
runtime DB will not be migrated in this programme. Tests use disposable databases.

REST is not an authoritative checkpoint/event adapter. Store every page and row,
including multiplicity and provider order. Commit a capture frontier only after terminal
page validation. This frontier is NOT a chain completeness/processing watermark.
Resume incomplete batches from durable cursor; retries retain delivery evidence.
Late inserts remain possible: complete capture never admits an unverified baseline.

No production canonical source adapter exists. Synthetic certification is confined to
explicitly marked disposable DBs; never encoded as blockchain facts. Production
REST observations always block source-driven copying. Provenance schema allows
future block/hash/log evidence, but accepting it requires a separately audited adapter.

Typed lifecycle events carry explicit evidenced inventory legs and independent source
cash/basis journal. Transfer legs are the balance authority; lifecycle descriptors cannot
apply the same transfer twice. Unsupported/uncertain mapping, reversal/reorg, unknown
payout or correction quarantines rather than constructing missing amounts.

Disabling stops all source actions; portfolio protective exits are distinct. Gaps and
paper/source differences persist. Enable means reconciliation_required, never trust.
No synthetic or historical execution is inserted for missed source events. Existing
paper positions are held for review on uncertainty. H05 package is preparation only.
