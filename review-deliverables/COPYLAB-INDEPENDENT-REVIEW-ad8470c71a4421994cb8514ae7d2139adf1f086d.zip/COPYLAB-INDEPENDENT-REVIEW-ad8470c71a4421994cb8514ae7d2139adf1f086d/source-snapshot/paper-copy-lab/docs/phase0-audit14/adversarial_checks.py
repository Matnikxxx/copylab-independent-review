"""Audit 14 probes only: symbolic synthetic labels, disposable DBs, no networking.
Assertions establish whether existing safeguards catch deliberately invalid evidence.
Does not fix or modify implementation. No actual App/main/server is started.
"""
import sys,json,tempfile,subprocess,importlib.util,sqlite3
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from lab.store import Store,SCHEMA,now
from lab.integrity import Integrity
from lab.engine import Engine
from lab.migrations import upgrade_existing
from lab.main import App
spec=importlib.util.spec_from_file_location('audit14_separate_replay',ROOT/'tools/source_verify.py');sv=importlib.util.module_from_spec(spec);spec.loader.exec_module(sv)
OUT=Path(__file__).parent;C=json.loads((ROOT/'config.json').read_text());results=[]
def record(case,observed,defect):results.append({'case':case,'observed':observed,'defect_reproduced':defect,'classification':'synthetic adversarial evidence, NOT market data'})
def cert(s,identity,kind,payload,ordering):
 i=Integrity(s);e=i.synthetic_event('fixture-wallet',identity,kind,payload,ordering);i.lifecycle(e);return e
with tempfile.TemporaryDirectory(prefix='copylab-audit14-probes-') as tmp:
 t=Path(tmp)
 # The independent source checker currently ignores unlinked movement rows.
 s=Store(str(t/'orphan.sqlite'),synthetic=True)
 s.db.execute('INSERT INTO source_movements(event,wallet,token,delta,cost_delta,cash,realized,leg_identity) VALUES(?,?,?,?,?,?,?,?)',(None,'fixture-wallet','T','0','0','999','999','fixture-orphan'))
 r=sv.verify(s.path);record('source_verifier_orphan_movement',r,r['errors']==[] and r['source_cash']=='0');s.db.close()
 # Paper checker validates fill realized and ledger cash, not ledger realized.
 s=Store(str(t/'paper.sqlite'),C,synthetic=True);e=Engine(s,C)
 oid=s.db.execute('INSERT INTO orders(event,model,track,wallet,token,market,side,qty,reference,due,status,reason) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',('fixture','A','ideal','fixture-wallet','T','M','BUY','10','.5',now(),'filled','synthetic audit fixture')).lastrowid
 o=s.one('SELECT * FROM orders WHERE id=?',(oid,))
 with s.tx():e.a.fill(o,'10','.5','0','0')
 s.db.execute("UPDATE ledger SET realized='999'")
 production_metrics=e.a.metrics('A','ideal');r=subprocess.run([sys.executable,'-B',str(ROOT/'tools/audit.py'),'--db',s.path,'--out',str(t/'paper-audit.json')],cwd=ROOT,capture_output=True,text=True)
 replay=json.loads((t/'paper-audit.json').read_text());record('paper_verifier_misses_realized_ledger_corruption',{'verifier_exit':r.returncode,'verifier_errors':replay['errors'],'reported_equity':production_metrics['portfolio_equity'],'reported_total_pnl':production_metrics['total_pnl']},r.returncode==0 and production_metrics['total_pnl']=='999.00000000');s.db.close()
 # A split with no complementary outcome is accepted by typed accounting and verifier.
 s=Store(str(t/'split.sqlite'),synthetic=True)
 eid=cert(s,'fixture-single-sided-split','SPLIT',{'legs':[{'identity':'fixture-leg','token':'T','delta':'10','basis':'5','cash':'-5'}],'effects':['fixture-effect']},0)
 record('single_sided_split_accepted',{'state':s.one('SELECT state FROM verified_events')['state'],'inventory':s.rows('SELECT token,qty FROM source_inventory'),'verifier':sv.verify(s.path)},s.one('SELECT state FROM verified_events')['state']=='applied');s.db.close()
 # Claimed redemption exceeds one dollar per share, without a payout proof.
 s=Store(str(t/'redeem.sqlite'),synthetic=True)
 cert(s,'fixture-entry','BUY',{'legs':[{'identity':'fixture-entry-leg','token':'T','delta':'10','basis':'5','cash':'-5'}],'effects':['fixture-entry-effect']},0)
 cert(s,'fixture-redeem','REDEEM',{'legs':[{'identity':'fixture-redeem-leg','token':'T','delta':'-10','cash':'20'}],'effects':['fixture-redeem-effect']},1)
 record('unproved_out_of_range_redemption_accepted',{'state':s.one("SELECT state FROM verified_events WHERE kind='REDEEM'")['state'],'verifier':sv.verify(s.path)},s.one("SELECT state FROM verified_events WHERE kind='REDEEM'")['state']=='applied');s.db.close()
 # Conflicting certificate content is not preserved when no observation is linked.
 s=Store(str(t/'conflict.sqlite'),synthetic=True);i=Integrity(s)
 i.synthetic_event('fixture-wallet','fixture-id','BUY',{'original':'fixture'},0)
 i.synthetic_event('fixture-wallet','fixture-id','BUY',{'conflict':'AUDIT14_CONFLICT_VALUE'},0)
 strings='\n'.join(str(tuple(row)) for table in ['verified_events','source_observations','reconciliation_records','event_links'] for row in s.db.execute('SELECT * FROM '+table))
 record('conflicting_certificate_payload_lost',{'state':s.one('SELECT state FROM verified_events')['state'],'conflicting_payload_retained':'AUDIT14_CONFLICT_VALUE' in strings},'AUDIT14_CONFLICT_VALUE' not in strings);s.db.close()
 # All-failed internal retries lose earlier bodies in durable transport evidence.
 s=Store(str(t/'retry.sqlite'),synthetic=True)
 class FailedAPI:
  def get(self,*a,**k):
   self.attempt_log=[{'received':now(),'http_code':'503','body':v,'error':'fixture'} for v in ['first-fixture-error','second-fixture-error','last-fixture-error']];self.last_raw='last-fixture-error';raise RuntimeError('all synthetic retries failed')
 try:Integrity(s).collect(FailedAPI(),'fixture-wallet','/v2/trades',{'user':'fixture-wallet'})
 except RuntimeError:pass
 raws=[x['raw'] for x in s.rows('SELECT raw FROM transport_deliveries')]
 record('all_failed_retry_bodies_lost',{'raw_bodies':raws,'batch_status':s.one('SELECT status FROM collection_batches')['status']},raws==['last-fixture-error']);s.db.close()
 # An interrupted CLOSED walk may stand in for a subsequent OPEN request.
 s=Store(str(t/'scope.sqlite'),synthetic=True);i=Integrity(s)
 class Interrupted:
  n=0
  def get(self,*a,**k):
   self.n+=1
   if self.n==1:return {'data':[],'pagination':{'has_more':True,'next_cursor':'fixture-cursor'}}
   raise RuntimeError('fixture interruption')
 try:i.collect(Interrupted(),'fixture-wallet','/v2/positions',{'user':'fixture-wallet','status':'CLOSED'})
 except RuntimeError:pass
 class Resume:
  params=None
  def get(self,*a,**k):self.params=k;return {'data':[],'pagination':{'has_more':False,'next_cursor':None}}
 api=Resume();i.collect(api,'fixture-wallet','/v2/positions',{'user':'fixture-wallet','status':'OPEN'})
 record('pending_batch_changes_requested_scope',{'requested':'OPEN','actually_resumed':api.params},api.params['status']=='CLOSED');s.db.close()
 # Additive migration digests lose type information (bytes -> str collision).
 from lab.migrations import table_digests
 db=sqlite3.connect(t/'digest.sqlite');db.execute('CREATE TABLE fixture(value)');db.execute('INSERT INTO fixture VALUES(?)',(b'A',));a=table_digests(db,['fixture']);db.execute('UPDATE fixture SET value=?',("b'A'",));b=table_digests(db,['fixture']);record('migration_digest_storage_type_collision',{'blob_digest':a,'text_digest':b},a==b);db.close()
 # Production guards remain closed even when SQL says verified. No real chain facts.
 s=Store(str(t/'production.sqlite'),C);e=Engine(s,C)
 s.db.execute('INSERT INTO source_states(wallet,state,reason) VALUES(?,?,?)',('fixture-wallet','verified','synthetic adversarial marker'))
 s.db.execute('INSERT INTO settings VALUES(?,?)',('inventory:fixture-wallet','{}'))
 s.db.execute('INSERT INTO positions VALUES(?,?,?,?,?,?,?)',('A','ideal','fixture-wallet','T','M','2','1'))
 oid=s.db.execute('INSERT INTO orders(event,model,track,wallet,token,market,side,qty,reference,due,status,reason) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',('fixture','A','ideal','fixture-wallet','T','M','SELL','2','.5',now()-1,'pending','fixture')).lastrowid
 e.execute();e.exits();e.settle('T','1',{'resolved':True,'token_id':'T','final_price':'1'})
 before=s.one('SELECT qty,cost FROM positions');fills=s.one('SELECT COUNT(*) n FROM fills')['n'];allowed=Integrity(s).allowed('fixture-wallet');s.db.close();s=Store(str(t/'production.sqlite'),C)
 record('production_execute_exit_settle_restart_containment',{'allowed':allowed,'fills':fills,'position_before_restart':before,'position_after_restart':s.one('SELECT qty,cost FROM positions'),'holds':len(s.rows('SELECT * FROM paper_holds'))},False);assert not allowed and fills==0 and before==s.one('SELECT qty,cost FROM positions')
 try:Store(s.path,C,synthetic=True)
 except ValueError:conversion_refused=True
 else:conversion_refused=False
 record('production_to_synthetic_refused',{'refused':conversion_refused},not conversion_refused);s.db.close()
(OUT/'adversarial-results.json').write_text(json.dumps(results,indent=2));print(json.dumps(results,indent=2))
