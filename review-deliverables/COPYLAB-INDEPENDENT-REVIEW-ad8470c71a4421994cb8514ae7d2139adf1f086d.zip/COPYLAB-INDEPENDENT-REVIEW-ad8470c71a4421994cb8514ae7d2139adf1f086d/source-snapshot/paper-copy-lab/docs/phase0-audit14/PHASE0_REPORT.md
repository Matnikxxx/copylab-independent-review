# Phase 0 — baseline and Audit 14 report

## Status

**Phase 0 gate: BLOCKED — not PASS.** The read-only assessment has been performed,
but genuinely separate verification is unavailable. Audit 14's technical assessment
is **FAIL** because material defects remain. Passing regression tests do not override
those defects. No Phase 1 implementation has started.

## 1. Repository state

- Repository `/home/user/paper-copy-lab`; branch main.
- HEAD remains 288a69f64c24438cfe69ea176e6f3d6ce7333499.
- Initially 17 modified tracked files plus existing untracked remediation modules,
  reports/tests/tools. Exact original status is in baseline-manifest.json.
- Current working state was the subject, not a clean checkout of HEAD.
- All 59 entries in prior docs/remediation/manifest.json match; no missing/mutated entry.
- New Phase 0 artifacts are confined to this directory and docs/PHASE_TRACKER.md.
- No pre-existing source, settings, tests, documentation or evidence was modified.
- No matching application/collector process observed initially; none started, stopped
  or otherwise controlled. No accounts/live wallet APIs queried; no addresses requested.

## 2. Runtime data and schema

Locations: data/lab.sqlite, data/lab-verified-backup.sqlite, data/lab.sqlite.worker.lock.
No WAL/SHM file observed at baseline. Runtime: 1,662,976 bytes; backup: 770,048 bytes.
SQLite connections were made only to temporary byte-copies, never original files.
Both copies: integrity_check=ok, migrations [1,2], wallets=0, fills=0.
Full table DDL/counts are in database-inspection.json. Code's additive V3 is not applied.

Runtime SHA-256:
cdbf549d5f39f9cb53a18b7e9fa9aad961083ae4914ca869c72bc705a6c1deb3
Backup SHA-256:
05749631d7ada4ede38834dec060006c44f4d0e4ed0c2f6df70822ea9ba10c44
These match the prior preservation evidence. No migration/reset/accounting rewrite.

## 3. Current implementation assessment

| Area | Demonstrated | Unmet / defect |
|---|---|---|
| H01 | Durable raw page/row capture, terminal frontiers, incomplete recovery; no REST baseline trusted | Failed-retry evidence loss; cross-scope resume; canonical completeness absent |
| H02 | Raw multiplicity/order preserved; production observations blocked; synthetic marker distinction | Conflicting certificate content lost; no authoritative production IDs/order |
| H03 | Typed leg arithmetic and pure basis carry on positive fixtures | Incomplete split/redemption semantics accepted in synthetic mode; no real decoder/reorg reconstruction |
| H04 | Disable/enable/removal history, gaps, holds, no retrospective paper fills | No complete real source-gap reconstruction or trusted release path |
| H05 | Valid-fixture source/paper arithmetic replay reproducible in separate processes | Orphan movements and realized-ledger corruption missed; no separate auditor or real forward history |

## 4. Important path map

- Public ingress: PublicClient.get → Integrity.collect → raw deliveries/pages/observations
  → quarantined baseline_evidence. Capture frontier means durable response only.
- Direct engine ingress: Engine.ingest in production → Integrity.observe → hold; no
  economic hash event creation. Synthetic path creates fixture certificates only.
- Decisions: Engine.process → Integrity.allowed; false for real environments before
  source inventory/order creation. New synthetic legs are not a real adapter.
- Execution: Engine.execute gate and paper_holds before Accounting.fill; executable
  fills retain context. Accounting.fill itself is an internal trusted write primitive,
  not an authenticated external interface; do not treat it as an independent safety gate.
- Model exits: Engine.exits refuses production allowed=false and held positions.
- Settlement: production Engine.settle holds instead of crediting a payout; fixture
  branch can settle. API warning about settlement capability is overbroad.
- Restart: Store refuses implicit V2→V3; production gate persists across reopen.
  main initializes Store before worker lock (A14-10).
- Monitoring: Wallets.change → history/gap/hold on disable/enable/remove; re-enable
  changes operator intent, not trusted baseline. Soft removal keeps evidence.
- Dashboard: state serializer readiness=false; health renderer uses stale ok flags
  without TTL, and labels must not be read as independent verification.

## 5. Audit 14 defects requiring correction

Full evidence, severity, line references and required corrections: AUDIT_14.md.

1. HIGH — paper verifier accepts corrupted ledger realized PnL.
2. HIGH — source verifier ignores orphan source movements.
3. HIGH (synthetic-only) — SPLIT accepted without sufficient outcome/operation evidence.
4. HIGH (synthetic-only) — REDEEM accepts unproved/inconsistent payout.
5. MEDIUM — conflicting certificate payload not always preserved.
6. MEDIUM — all-failed retries lose earlier response bodies.
7. MEDIUM — interrupted collection scope can substitute for a different requested scope.
8. LOW — migration content digest loses SQLite storage type distinctions.
9. MEDIUM — stale component health renders green Healthy.
10. MEDIUM, inspection-only — mutable DB initialization precedes worker lock.

No actual-runtime corruption or exposed real-trading capability demonstrated. The
currently global fail-closed guard contains real source-copy actions; do not remove it.

## 6. Test/evidence results

- Original regression command, in disposable mirror:
  python3 -B -m unittest discover -s tests -v
  Result: 119 run; 119 pass; zero failures/errors/skips.
- Reproduced remediation source/migration and paper scripts in that mirror only, so
  existing reports were not overwritten. 10 source operations and 500 paper fills pass
  their valid fixtures; deterministic source report matches repeat.
- Backend adversarial probes: 10 scenarios, 8 confirmed defects and 2 containment checks.
- Browser probe: 1 scenario, stale green health reproduced, zero JS errors; no server,
  App initialization or real network. Only pure state serialization/intercepted fixtures.
- HTTP server tests were intentionally NOT rerun: this phase forbids application startup.
- No forward observations collected. All new financial/event evidence is synthetic.

Reproduce this assessment with:
  python3 -B docs/phase0-audit14/reproduce_baseline.py
  python3 -B docs/phase0-audit14/adversarial_checks.py
  python3 -B docs/phase0-audit14/dashboard_probe.py
Use a new evidence directory/copy for a later audit rather than overwriting this record.

## 7. Acceptance checklist

[x] Actual Git/working-tree state understood and manifested before changes.
[x] Existing modifications and historical evidence preserved.
[x] Runtime and backup locations identified; copies inspected; originals unchanged.
[x] Source, decision, execution, exit, settlement, restart and dashboard paths mapped.
[x] H01–H05 claims tested/inspected where locally possible, with counterexamples retained.
[x] Defects and proposed engineering scopes documented.
[x] No application/monitoring startup, live API requests, migrations or Phase 1 changes.
[ ] Genuinely separate reviewer verified actual code/evidence — BLOCKED, unavailable.
[ ] Material defect remediation and independent re-audit — NOT DONE in read-only Phase 0.
[ ] Phase gate approved — NOT GRANTED.

Checkboxes represent evidence collection, not an independent PASS assertion.

## 8. Exact next step / proposed next engineering scope

Remain at **Phase 0 review gate**. Obtain genuinely separate review of Audit 14, validate
its findings and approve a bounded remediation scope. No automatic Phase 1 start.

Candidate Phase 1 after approval: fix A14-02, A14-05, A14-06, A14-07 and strengthen
source-verifier invariants; assess A14-08/A14-10 as data-safety prerequisites. Research
canonical checkpoint/identity coverage without arming real wallets. Record A14-03/04
for the lifecycle gate, A14-01 for accounting/verification, and A14-09 for reporting.
Do not skip their later gates or claim them fixed by a phase-1 document.

If independent review remains unavailable, report BLOCKED and keep real copying and
runtime migration disabled. No wallet addresses are needed at this stage.

## 9. Final preservation verification

`preservation-verification.json`: all **106 pre-existing files** have identical size
and SHA-256; no missing/changed original file; no unexpected new project path.
Branch/HEAD unchanged. `git diff --check` exits 0. The full tracked diff was captured
and inspected; it is entirely pre-Phase-0 content, proven by the baseline file hashes.
59/59 previous remediation-manifest entries match. Runtime and backup hashes still
match their pre-assessment values. Final status and process inventory are retained.

The evidence manifest hashes the final assessment artifacts (excluding itself); it is
an integrity index, not an auditor signature. The companion ZIP contains this evidence,
the tracker and current source/test/tool/config files, but **no runtime database**.
