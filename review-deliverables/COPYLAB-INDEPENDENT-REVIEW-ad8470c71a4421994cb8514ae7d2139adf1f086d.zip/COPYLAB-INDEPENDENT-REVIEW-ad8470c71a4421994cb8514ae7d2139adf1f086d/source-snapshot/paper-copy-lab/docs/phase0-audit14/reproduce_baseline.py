"""Phase 0: execute inspected code only in an isolated disposable mirror.
No application/server/collector startup; no runtime SQLite handle is opened.
"""
import tempfile,shutil,subprocess,os,json,sqlite3,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=ROOT/'docs/phase0-audit14'
env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'}
results=[]
with tempfile.TemporaryDirectory(prefix='copylab-audit14-') as temp:
 mirror=Path(temp)/'repo'
 shutil.copytree(ROOT,mirror,ignore=shutil.ignore_patterns('.git','data','__pycache__','node_modules','phase0-audit14'))
 for label,command in [('regression',['python3','-B','-m','unittest','discover','-s','tests','-v']),('source-migration-replay',['python3','-B','tools/remediation_evidence.py']),('paper-replay',['python3','-B','tools/fixture_validation.py'])]:
  r=subprocess.run(command,cwd=mirror,env=env,capture_output=True,text=True,timeout=120)
  (OUT/(label+'.txt')).write_text(r.stdout+r.stderr)
  results.append({'check':label,'command':command,'exit_code':r.returncode,'scope':'synthetic disposable mirror; no server or wallet queries'})
 for name in ['source-replay.json','source-replay-repeat.json','paper-replay.json','migration-evidence.json','empty-forward-readiness.json']:
  if (mirror/'docs/remediation'/name).exists():shutil.copyfile(mirror/'docs/remediation'/name,OUT/('reproduced-'+name))
 databases={}
 for name in ['lab.sqlite','lab-verified-backup.sqlite']:
  original=ROOT/'data'/name;copy=Path(temp)/name;shutil.copyfile(original,copy)
  # No running writer/WAL was observed; inspect ONLY the disposable bytes.
  db=sqlite3.connect(str(copy));db.row_factory=sqlite3.Row
  tables=[dict(x) for x in db.execute("SELECT name,sql FROM sqlite_master WHERE type='table'")]
  databases[name]={'source_hash':hashlib.sha256(original.read_bytes()).hexdigest(),'copy_hash':hashlib.sha256(copy.read_bytes()).hexdigest(),'integrity':db.execute('PRAGMA integrity_check').fetchone()[0],'migrations':[dict(x) for x in db.execute('SELECT * FROM migrations')],'tables':tables,'counts':{t['name']:db.execute('SELECT COUNT(*) FROM "'+t['name'].replace('"','""')+'"').fetchone()[0] for t in tables},'sqlite_opened_on':'disposable byte-copy only'}
  db.close()
 (OUT/'database-inspection.json').write_text(json.dumps(databases,indent=2))
 (OUT/'baseline-reproduction.json').write_text(json.dumps(results,indent=2))
 print(json.dumps(results,indent=2))
