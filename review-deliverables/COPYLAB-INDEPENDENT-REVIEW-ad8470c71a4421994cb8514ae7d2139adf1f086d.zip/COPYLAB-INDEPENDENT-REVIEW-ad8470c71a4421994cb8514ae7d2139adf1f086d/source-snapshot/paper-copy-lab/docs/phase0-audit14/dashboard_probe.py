"""Read-only UI audit via intercepted in-memory fixtures. No App construction,
main/run/server/collector startup, wallet inputs or real network requests."""
import sys,json,tempfile
from pathlib import Path
from types import SimpleNamespace
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from lab.store import Store
from lab.engine import Engine
from lab.main import App
from playwright.sync_api import sync_playwright
OUT=Path(__file__).parent;config=json.loads((ROOT/'config.json').read_text())
with tempfile.TemporaryDirectory(prefix='copylab-audit14-ui-') as tmp:
 s=Store(tmp+'/empty.sqlite',config)
 # Invoke only the read-only state serializer, not App.__init__/main/run.
 state=App.state(SimpleNamespace(s=s,e=Engine(s,config),c=config,csrf='synthetic-ui-fixture'))
 state['health']=[{'component':'synthetic-old-health','ts':0,'ok':1,'detail':'fixture: stale observation, not current health'}];s.db.close()
 with sync_playwright() as p:
  b=p.chromium.launch(headless=True,args=['--no-sandbox']);pg=b.new_page(viewport={'width':1440,'height':1000});errors=[];pg.on('pageerror',lambda e:errors.append(str(e)))
  def route(r):
   if r.request.url.endswith('/api/state'):r.fulfill(content_type='application/json',body=json.dumps(state))
   else:r.fulfill(content_type='text/html',body=(ROOT/'lab/dashboard.html').read_text())
  pg.route('**/*',route);pg.goto('http://copylab.test/#health');pg.wait_for_selector('#content table')
  stale_green=pg.get_by_text('Healthy',exact=True).count()>0
  warning=state['warnings'][-1]
  pg.screenshot(path=str(OUT/'dashboard-stale-health.png'),full_page=True);b.close()
 result={'classification':'synthetic UI fixtures, no app startup','real_network_requests':0,'api_forward_validation_ready':state['forward_validation_ready'],'stale_health_rendered_Healthy':stale_green,'last_warning':warning,'javascript_errors':errors,'defect_reproduced':stale_green}
 (OUT/'dashboard-results.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
