# Audit 14 — read-only technical assessment of H01–H05 remediation

## Authority, scope and verdict

Reference/current HEAD: `288a69f64c24438cfe69ea176e6f3d6ce7333499`, branch `main`.
The uncommitted working tree, not just that commit, was the audit target. All 59
entries in the previous remediation manifest match. This report is prepared by the
implementation agent. **No genuinely separate reviewer was available. It is NOT an
independent third-party/agent audit or phase approval.** Existing replay programs were
run in separate processes; their arithmetic implementation is separate, not authorship.

Technical result: **FAIL** — material verification/semantic defects reproduced despite
119/119 existing tests passing. Independent sign-off: **BLOCKED**. Production source
copying stayed fail-closed in tested entry points; no external bypass or real-money
capability was demonstrated. Findings in synthetic-only machinery are not represented
as demonstrated real-wallet exploitation. No implementation fixes were made in Phase 0.

## Method

- Preserve file/Git/process manifest before changes; inspect source and old evidence.
- No live APIs, accounts, wallet monitoring or real source observations.
- No App construction/start, application server, Collector.cycle or process control.
- Test/replay original implementation in a disposable mirror (no .git or runtime data).
- Inspect schema/history/counts/integrity on disposable byte-copies of actual database
  and backup, not SQLite connections to originals. No active writer/WAL was observed.
- Adversarial probes use symbolic fixture labels and explicit synthetic values; no
  blockchain IDs, addresses, log indexes or block numbers manufactured.
- Browser probe uses fully intercepted in-memory responses and only the state
  serialization function on a disposable DB; no application initialization/server.

## Confirmed findings

### A14-01 — HIGH: paper verifier misses ledger realized-PnL corruption

Files: `tools/audit.py:15–31`, `lab/accounting.py:8–11,25–36`.
Probe: `paper_verifier_misses_realized_ledger_corruption`.

A disposable synthetic BUY is recorded correctly, then its ledger realized field is
changed to 999. `Accounting.metrics` reports equity 1000 and total PnL 999; the identity
`equity − starting = total PnL` is broken. The standalone verifier exits 0 with no errors.
It checks fill-level realized results and ledger cash, but never reconciles ledger
realized/fee/cost fields, closure cycles, or snapshots against replay.

This is an assurance defect under controlled tampering, not evidence that the normal
fill path spontaneously corrupts runtime PnL. Required correction: full bidirectional
ledger/fill/closure reconciliation and equity identity tests, including corrupt/missing/
extra rows and independently recomputed marks. Do not rely on the current green replay
as comprehensive PnL verification. No real DB was changed.

### A14-02 — HIGH: source verifier ignores unlinked journal movements

File: `tools/source_verify.py:12–38`.
Probe: `source_verifier_orphan_movement`.

A synthetic movement with no event, cash=999, realized=999 remains in source_movements.
The independent replay reports source cash=0, realized=0 and errors=[] because it only
traverses movements reached from verified_events. It does not verify all stored movement
rows/effects exactly once. Required correction: orphan/extra journal/effect/link checks,
full expected-versus-stored coverage and cash/realized reconciliation, not just checking
rows found by the expected direction. No foreign keys in current schema compensate.

### A14-03 — HIGH, synthetic-only: SPLIT lacks operation-specific completeness checks

File: `lab/integrity.py:161–199`; checker `tools/source_verify.py:18–34`.
Probe: `single_sided_split_accepted`.

A synthetic SPLIT containing only one outcome, without condition/complementary outcome
mapping or evidence of complete legs, is marked applied; independent replay accepts it.
The implementation checks positive legs and paid-basis totals, not the contract/market
operation semantics or exhaustive outcome set. This is not proof every possible split
must have a particular binary shape; rather, no evidence identifies *which* operation
this single leg represents. Required correction: operation-specific verified mappings/
coverage, or quarantine incomplete descriptors. Generic typed legs must not be described
as complete split reconstruction. Real source processing remains globally blocked.

### A14-04 — HIGH, synthetic-only: REDEEM accepts payout without settlement proof

File: `lab/integrity.py:169–199`; checker `tools/source_verify.py:24–34`.
Probe: `unproved_out_of_range_redemption_accepted`.

Ten fixture shares redeem for 20 cash without a payout numerator/denominator, token
finality or collateral proof. Source realized PnL becomes 15 and the independent checker
accepts it. The generic burn/debit check is insufficient to establish a valid ordinary
outcome payout or explain a nonstandard operation. Required correction: explicit verified
redemption semantics, payout and finality evidence; reject/quarantine unspecified or
inconsistent cash legs. Checker must independently validate those semantics, not merely
repeat arithmetic from trusted cash fields. This path is synthetic-only today.

### A14-05 — MEDIUM: conflicting certificate payload can disappear

File: `lab/integrity.py:127–143`.
Probe: `conflicting_certificate_payload_lost`.

With no observation linked, a conflicting synthetic certificate changes the existing
event state to conflict and creates a hold, but stores neither the replacement payload
nor an immutable conflict record. The probe's distinctive replacement content cannot
be found in event/observation/reconciliation/link tables. Ordinary REST raw capture is
not affected by this specific probe. Required correction: append-only conflict evidence
including supplied payload/provenance/order and observation link, before quarantine.

### A14-06 — MEDIUM: all-failed retries lose earlier response bodies

File: `lab/integrity.py:80–86,111–118`; `lab/public.py:15–28`.
Probe: `all_failed_retry_bodies_lost`.

When get() ultimately raises after three supplied failure attempts, only last_raw is
persisted. Earlier attempt_log entries are flushed only after get() returns. The batch
correctly remains incomplete, but the claim that every HTTP attempt is retained is
false for this branch. Required correction: durable attempt reporting on all exits,
including timeouts/invalid JSON/terminal HTTP errors, while retaining incomplete state.

### A14-07 — MEDIUM: resumed collection scope can differ from caller's requested scope

File: `lab/integrity.py:69–75`; caller `lab/public.py:baseline`.
Probe: `pending_batch_changes_requested_scope`.

An interrupted positions CLOSED walk is resumed when the next call requests OPEN:
selection uses wallet+endpoint only and adopts old params. Preserving the original
walk is appropriate; returning it as the requested OPEN step is not. Baseline calls
positions twice for distinct scopes, so its batch list can omit the intended OPEN
walk. All baselines remain quarantined, containing the economic risk.

Required correction: explicit collection intent/scope key and scheduler/resume outcome;
never confuse finishing pending scope A with successfully capturing requested scope B.
Do not solve this by changing parameters mid-cursor or dropping incomplete batches.

### A14-08 — LOW: migration preservation digest is not storage-type preserving

File: `lab/migrations.py:32–38`.
Probe: `migration_digest_storage_type_collision`.

SQLite BLOB b'A' and TEXT "b'A'" produce identical hashes due to json default=str.
No such original runtime corruption was observed. Existing successful migration tests
still demonstrate their specific text fixture preservation, but not type-exact content.
Required correction: typed deterministic cell encoding and schema/index/trigger coverage
where preservation is claimed. Do not claim the digest detects every storage change.

### A14-09 — MEDIUM: stale historical health still renders green “Healthy”

File: `lab/dashboard.html`, health renderer at line 11; state `lab/main.py:34`.
Probe: `dashboard_probe.py`, screenshot `dashboard-stale-health.png`.

The real renderer shows a fixture health row with ts=0 and ok=1 as green Healthy.
Timestamp is displayed but not used to expire the state. API readiness remains false,
so this is misleading component health, not proof copying was enabled. An additional
warning says token-finality settlements are supported although production settle()
currently only holds. Required correction: explicit TTL/unknown/stale health semantics
and capability labels matching production-mode restrictions.

### A14-10 — MEDIUM, code-inspection finding: DB initialization precedes worker lock

File: `lab/main.py:38–44`; `lab/store.py:37–70`.

main() constructs App/Store before obtaining the worker flock. Store can open/create
DBs, issue PRAGMAs/schema operations and initialize settings before single-writer
ownership is checked. No application was launched to probe this because Phase 0 forbids
startup. Version-2 refusal is confirmed separately and is a useful containment, but is
not a universal pre-lock no-write guarantee for version 3/new files.

Required correction: acquire/validate worker ownership before mutable initialization;
separate read-only validation/backup flows. Test lock contention and path aliases in a
future approved disposable operational-hardening scope. No runtime migration approved.

## Additional limitations (not newly demonstrated exploits)

- No production canonical source adapter; `Integrity.allowed()` returns false for real
  environments regardless of SQL status. This is deliberate containment, not capability.
- H04 records gaps/holds, but no complete source-gap reconstruction or release exists.
- Reorg/correction/reversal handling quarantines, not canonical rollback/replay.
- Synthetic legs and fixture certificates are not authenticated blockchain evidence.
- No FK relationships in inspected runtime schema or new V3 definitions; explicit
  referential coverage in verifiers and migrations is needed before durable operation.
- Current replay verifies supplied arithmetic, not complete execution-book/fee/depth
  realism or market/source completeness. No new forward results were collected.
- Snapshot health/UI tables are not a complete independent reconciliation dashboard.
- Requested DATA_INTEGRITY, EXECUTION_MODEL, OPERATIONS and FINAL_VALIDATION documents
  do not yet exist; they were not fabricated during this read-only assessment.

## Confirmed containment and reproducibility

- Existing test suite: 119 tests, 119 pass, no failures/errors/skips in isolated mirror.
- Source fixture replay: 10 typed events, expected cash/realized=3/2, deterministic report.
- Paper fixture replay: 500 fills/10 portfolios, no errors on original valid fixture.
- Adversarial probe sets: 10 backend scenarios (8 defects, 2 confirmed safeguards),
  plus 1 browser scenario (1 defect). Passing reproduction scripts mean the described
  behaviours were observed, NOT that the flawed system passed the desired invariant.
- Production-classified disposable DB: execute/exits/settle/reopen created zero fills,
  retained inventory/cost and created a hold even with a forged local 'verified' state.
- Production-to-synthetic relabelling through Store API rejected.
- Original/backup hashes unchanged; SQLite originals not opened. Copies show versions
  1/2, integrity ok, zero wallets/fills. V3 migration only reproduced in temporary files.

## Independence and release gate

No separate reviewer approved this result. Separate arithmetic processes reproduced
expected fixtures but failed adversarial coverage above; they cannot approve themselves.
Audit 14 is an evidence package for independent review. No implementation remediation,
new phase, runtime migration, app startup or wallet activation is approved by this audit.
