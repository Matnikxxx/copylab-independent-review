"""Hash all pre-Phase-0 project files. Git/process inventory only; no DB handles."""
import hashlib,json,os,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent
def git(*args):return subprocess.run(['git',*args],cwd=ROOT,env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'},capture_output=True,text=True,check=True).stdout
baseline=json.loads((OUT/'baseline-manifest.json').read_text());changed=[]
for name,expected in baseline['files'].items():
 p=ROOT/name
 if not p.is_file():changed.append({'path':name,'reason':'missing'});continue
 if p.stat().st_size!=expected['size'] or hashlib.sha256(p.read_bytes()).hexdigest()!=expected['sha256']:changed.append({'path':name,'reason':'size/hash mismatch'})
skip={'.git','__pycache__','node_modules','.cache'}
current={str(p.relative_to(ROOT)) for p in ROOT.rglob('*') if p.is_file() and not skip.intersection(p.relative_to(ROOT).parts)}
new=sorted(current-set(baseline['files']))
unexpected=[p for p in new if not (p.startswith('docs/phase0-audit14/') or p=='docs/PHASE_TRACKER.md')]
status=git('status','--short');(OUT/'git-status-final.txt').write_text(status)
diff=git('diff','--no-ext-diff');(OUT/'git-diff-final.patch').write_text(diff)
check=subprocess.run(['git','diff','--check'],cwd=ROOT,capture_output=True,text=True,env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'})
processes=subprocess.run(['ps','-eo','pid,ppid,comm,args'],capture_output=True,text=True,check=True).stdout
(OUT/'processes-after.txt').write_text(processes)
head=git('rev-parse','HEAD').strip();branch=git('branch','--show-current').strip()
result={'original_file_count':len(baseline['files']),'changed_or_missing_original_files':changed,'unexpected_new_paths':unexpected,'head_unchanged':head==baseline['head'],'branch_unchanged':branch==baseline['branch'],'head':head,'branch':branch,'git_diff_check_exit':check.returncode,'git_diff_check_output':check.stdout+check.stderr,'phase0_source_implementation_changes':0,'runtime_databases_opened':False,'runtime_hashes':{n:hashlib.sha256((ROOT/n).read_bytes()).hexdigest() for n in ['data/lab.sqlite','data/lab-verified-backup.sqlite']},'prior_manifest':json.loads((OUT/'prior-manifest-verification.json').read_text()),'limitations':['Hashes establish byte preservation at the check time, not proof of arbitrary concurrent activity.','All code and old-document modifications shown by final git diff predate Phase 0, as established by identical file hashes.']}
result['preserved']=not changed and not unexpected and result['head_unchanged'] and result['branch_unchanged'] and check.returncode==0
(OUT/'preservation-verification.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2));raise SystemExit(not result['preserved'])
