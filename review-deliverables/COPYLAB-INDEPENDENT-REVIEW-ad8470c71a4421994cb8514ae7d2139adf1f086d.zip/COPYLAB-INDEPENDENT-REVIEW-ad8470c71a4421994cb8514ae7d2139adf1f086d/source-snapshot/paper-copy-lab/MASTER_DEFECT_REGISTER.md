# CopyLab — Master Defect Register

**2026-11-05 · Part 18 planning baseline · no implementation authorised**

Central current register. Keep IDs permanently; append disposition/evidence/reviewer
history rather than deleting closed findings. The latest master prompt's phase mapping
supersedes earlier proposed numbering, without modifying historical reports/trackers.

**Programme gate: BLOCKED.** Phase 0 needs genuinely separate review and explicit bounded
scope approval. Audit 14 technical result remains FAIL. No finding is VERIFIED_FIXED.
OPEN below means queued known issue/requirement, not authority to work on it.
BLOCKED identifies an external evidence/dependency/approval condition. Requirements may
already have partial local functionality; OPEN does not assert every listed feature is
absent. Severities for extended requirements are planning priorities, subject to reviewer
assessment; they are not new independently confirmed audit findings.

## Evidence key

- **A**: [Audit 14](docs/phase0-audit14/AUDIT_14.md).
- **P**: [Phase 0 report](docs/phase0-audit14/PHASE0_REPORT.md).
- **B**: [backend probes](docs/phase0-audit14/adversarial-results.json) and their
  [source](docs/phase0-audit14/adversarial_checks.py). Synthetic; historical, not rerun now.
- **U**: [browser results](docs/phase0-audit14/dashboard-results.json) and
  [probe](docs/phase0-audit14/dashboard_probe.py). Intercepted fixture, no real source proof.
- **H**: [H01–H05 remediation report](docs/REMEDIATION_REPORT.md), partial containment
  assertions subject to Audit 14 counterexamples; not independent sign-off.
- **V**: [fresh manifest checks](docs/master-remediation-planning-2026-11-05/preservation-checks.json)
  and [copied DB inspection](docs/master-remediation-planning-2026-11-05/database-copy-inspection.json).
- **Plan**: [current scope, tests, dependencies and acceptance](MASTER_REMEDIATION_PLAN.md).
- Exact current paths/function names below identify source inspected; separate reviewer
  must inspect the actual files and independently reproduce claims, not rely only on A/H.

## 1. Audit 14 findings — all retained

| ID | Defect / requirement | Severity | Phase | Status | Evidence | Remaining blocker |
|---|---|---|---|---|---|---|
| A14-08 | Migration digest conflates BLOB content and equivalent-looking TEXT through default=str | LOW | 1A first | OPEN | A/B: migration_digest_storage_type_collision; lab/migrations.py table_digests | Typed/length-framed deterministic encoding; full requested type, Unicode, BLOB, empty/composite tests and type-changing preservation rejection; independent review and approval |
| A14-10 | Mutable initialization precedes worker lock; backup branch also precedes ownership check | MEDIUM | 1A first | OPEN | A inspection-only; lab/main.py main/App, lab/store.py Store; no concurrency reproduction yet | Safe complete startup/backup/migration/read-mode design; independent disposable contention/crash/alias tests; no actual app/worker start |
| A14-02 | Source verifier traverses only event-reachable rows, ignoring orphan movements | HIGH | 1B | OPEN | B: source_verifier_orphan_movement; tools/source_verify.py verify reports errors=[] for orphan cash/realized=999 | Full bidirectional row/effect/leg/provenance/wallet/historical-position coverage; requested 10 fixtures and exact diagnostics; review |
| A14-01 | Paper verifier misses ledger realized-PnL corruption and complete cycle reconciliation | HIGH | 1C | OPEN | B: paper_verifier_misses_realized_ledger_corruption; tools/audit.py; accounting.metrics shows equity=1000/PnL=999 while verifier exits 0 | Independent financial reconstruction, complete linkage/valuation/rounding checks and all requested corruption cases; review |
| A14-03 | Synthetic SPLIT accepted without sufficient operation/outcome configuration and leg completeness | HIGH, synthetic-only | 1D | OPEN | B: single_sided_split_accepted; integrity.lifecycle and source_verify accept fixture | Fully specified fixture operation rules and independent checks; invalid/incomplete rejection; no fabricated chain evidence; real decoder remains separate |
| A14-04 | Synthetic REDEEM accepts unproved or inconsistent payout | HIGH, synthetic-only | 1D | OPEN | B: unproved_out_of_range_redemption_accepted; 10 shares→20 cash accepted without payout proof | Resolved outcome, quantity, payout rule, actual operation and deductions evidence; duplicate/restart/resolution-only tests; review |
| A14-05 | Conflicting synthetic certificate payload can be lost when observation is absent | MEDIUM | 1E | OPEN | B: conflicting_certificate_payload_lost; integrity.synthetic_event conflict branch | Preserve complete original/conflict raw evidence and metadata immutably; all representation/restart tests; additive-schema design if needed |
| A14-06 | All-failed transport retries retain only last response body | MEDIUM | 1F | OPEN | B: all_failed_retry_bodies_lost; integrity.collect exception path, PublicClient.get | Durable per-attempt request/response/error/timing/header evidence including crash/timeout and success-after-failure; no secrets; review |
| A14-07 | Pending CLOSED positions batch can substitute for requested OPEN batch | MEDIUM | 1G | OPEN | B: pending_batch_changes_requested_scope; integrity.collect keyed wallet+endpoint; public.baseline | Immutable complete scope identity, explicit mismatched-resume handling and scope-specific frontier/coordinator tests; no lost evidence |
| A14-09 | Old ok flag renders green Healthy; settlement capability warning exceeds production behavior | MEDIUM | 1H; full UI in 9 | OPEN | U: ts=0 renders Healthy; main.state warning; dashboard health renderer | Freshness/attempt/success/hold/completeness/audit/readiness dimensions, explicit states, all 10 health cases and browser/API checks; review |

**A14 scope qualification:** nine weaknesses were reproduced in the prior assessment;
A14-10 was identified by inspection. No fresh before/after test ran in Part 18, no fix was
made, and no real-wallet exploit/runtime corruption was demonstrated. Current production
allowed() stays false; containment is not a source-completeness or accounting PASS.

## 2. H01–H05 — parent issues remain open to external evidence

| ID | Defect / requirement | Severity | Phase | Status | Evidence | Remaining blocker |
|---|---|---|---|---|---|---|
| H01 | No shared authoritative exhaustive source checkpoint; boundary/late/filter/inactive/dust coverage uncertain | HIGH | 1F–1G local defects; 2 completion | BLOCKED | H/P; integrity.collect/baseline; raw capture containment; A14-06/07 | Supported canonical history/checkpoint/balance coverage, independent source assessment; fresh/terminal REST is insufficient |
| H02 | Similar economic rows do not prove canonical identity, duplicate treatment or tied-event ordering | HIGH | 1E local preservation; 2 completion | BLOCKED | H/P; integrity.observe/tag/synthetic_event; production global refusal; A14-05 | Real supported chain/contract/tx/block/hash/index/log identity, attribution, ordering and finality; no hash/time/arrival ordering substitute |
| H03 | Full lifecycle reconstruction/basis/cash/duplicate/reorg semantics not proved for real operations | HIGH | 1D fixture semantics; 3 completion | BLOCKED | H/P/A14-03/04; integrity.lifecycle; typed fixtures are not actual decoder evidence | Verified version-specific operation/contract data, complete legs/mappings and safe correction/reorg treatment; separate semantic/arithmetic review |
| H04 | Monitoring gaps cannot be completely reconstructed and reconciled for safe re-enable | HIGH | 4 | BLOCKED | H/P; wallets.change, integrity.gap/hold; old synthetic gap tests | Complete trustworthy historical source inventory and gap reconstruction; independent review before hold release; no snapshot overwrite/backdated fills |
| H05 | Independent audit and actual-wallet forward evidence absent; arithmetic verifiers incomplete | HIGH | 0; 1B–1C; 5–7; 10 | BLOCKED | H/P/B; tools/source_verify.py/audit.py; no separate reviewer or real forward history | Separate reviewer now; verified source and later user-supplied/approved public wallets; adequate forward evidence; final independent audit |

Historical H reports describe partial safety work; BLOCKED here reflects missing evidence
needed to resolve each entire parent issue. No historical claim was rewritten as a fix.

## 3. Programme and system requirements — tracked independently of A14

| ID | Defect / requirement | Severity | Phase | Status | Evidence | Remaining blocker |
|---|---|---|---|---|---|---|
| GOV-00 | Genuinely separate Phase 0 assessment and approved remediation sequence/scope | HIGH | 0 | BLOCKED | A explicitly disclaims independence; Plan §4 | No separate reviewer available; independently inspect/reproduce findings and obtain user approval before 1A |
| SAFE-01 | Permanent paper-only capability restriction and fail-closed production admission | HIGH | Every phase; final 10 | OPEN | integrity.allowed returns false for production; prior B containment; public GET allowlist | Revalidate unchanged guard and no signing/order/private-key capability with every diff; never remove guard for tests or add real trading |
| SAFE-02 | Real runtime DB/backup and historical evidence preservation; no silent schema upgrade | HIGH | Every phase; runtime approval separate | BLOCKED | V: unchanged SHA-256, copies [1,2], integrity ok; fresh 136-file baseline | Explicit runtime migration approval absent; future stop/path/backup/count/digest/disposable migration/restore proof required |
| SRC-01 | Distinguish response/page/event/canonical/finalized/inventory checkpoints | HIGH | 2 | BLOCKED | H01/P; capture_frontiers means durable response only | Source capability contract plus implemented/independently checked semantics; do not relabel cursor as checkpoint |
| SRC-02 | Missing/late/overlap/repeated pages, provider reorder/rate limit/outage and reorg coverage | HIGH | 1F–1G local; 2 canonical | OPEN | H01/H02; tests/test_integrity.py capture cases; known A14 gaps | Adversarial page/frontier/recovery matrix including events behind earlier cursor; real coverage proof remains external |
| SRC-03 | Unknown versus known-zero inventory, archived/inactive/dust/missing-history provenance | HIGH | 2 | BLOCKED | integrity.baseline quarantines REST; H01 | Exhaustive supported baseline and historical balance reconstruction; missing row cannot imply zero |
| LIFE-01 | Real decoder for BUY/SELL/SPLIT/MERGE/REDEEM/RESOLUTION/CONVERSION/NEG_RISK/COMBO/TRANSFER/fees | HIGH | 3 | BLOCKED | H03; no certified real adapter; fixture-only typed leg arithmetic | Official version-specific identities/configuration and actual complete operation data; no synthetic source proof |
| LIFE-02 | Auditable correction/reorg tracing and safe reversal/recompute or quarantine | HIGH | 2–3 | BLOCKED | integrity.lifecycle quarantines correction/reorg rather than reconstructing | Canonical affected-event evidence, durable dependencies/history, safe recovery design and independent adversarial review |
| LIFE-03 | Source/paper separation and economic-effect idempotence | HIGH | 1B–1D; 3; 5 | OPEN | integrity source_movements/effects versus accounting ledger; B containment | All duplicated/partial/overlapping lifecycle effects and decision links checked; no source mutation directly credited as paper fill |
| GAP-01 | Whole-gap reconstruction, explicit re-enable review and preserved removal history | HIGH | 4 | BLOCKED | H04; wallets.change; prior short/long-gap and removal tests | Trustworthy full source history; demonstrate missed BUY/SELL/lifecycle/restart and unexplained-difference hold; preserve open paper positions |
| COPY-01 | Safe address/chain/public-identity onboarding and verified baseline approval | HIGH | 5 | BLOCKED | P: no wallets; V copies wallet count=0 | Phases 0–4, source completeness and explicit activation approval; user supplies wallet addresses only at this phase |
| COPY-02 | Every event has durable copied/rejected/held/duplicate/unsupported/insufficient/source/risk/execution decision | HIGH | 5 | OPEN | engine.process/execute/exits/settle need full pipeline assessment | Full event→decision→fill→ledger traceability including failures/partial exits/settlement/restart; no success without actual paper fill |
| EXEC-01 | Retained as-of book/depth/reference/arrival/fees/spread/slippage/rejection context | HIGH | 1C accounting boundary; 6 model | OPEN | execution_context exists; prior fixture context test; no full independent execution review | Independently check timing/context completeness, partials, stale/suspended/min-size/limits and delayed exits; label missing context uncalibrated |
| EXEC-02 | Calibrated executable estimate with latency/adverse-selection/queue/liquidity uncertainty | HIGH | 6 | BLOCKED | P/master baseline: executable PnL is approximate, no calibration observations | Sufficient approved forward book/delay/fill-opportunity observations and model-error analysis; displayed depth is not guaranteed fill capacity |
| STRAT-01 | Five separate $1,000 portfolios, isolated Ideal/Executable ledgers and strategy definitions | HIGH | 7 | OPEN | config.json, lab/strategies.py/accounting.py; historical ten-portfolio fixtures | Independent cross-model/track isolation tests; documented hypotheses/entry/exit/risk/stop rules; no config changes without approved scope |
| STRAT-02 | Leakage/bias-controlled training/validation/untouched OOS and real forward evaluation | HIGH | 7 | BLOCKED | No sufficient actual forward strategy observations; H05 | Approved legitimate time-indexed data, predeclared evaluation/tuning rules, sample-size and selection/correlation controls; no synthetic profitability claim |
| STRAT-03 | Complete metrics, uncertainty, wallet/market/strategy concentration and correlation | MEDIUM | 7; UI 9 | OPEN | main.state/accounting.metrics provide subset; provisional rankings warning | Independently verified trade/PnL/drawdown/win/loss/profit-factor/hold/rejection/exposure metrics with meaningful denominators, no single-metric winner |
| RISK-01 | Strategy-independent, immediately pre-execution combined risk constraints | HIGH | 8; safety prerequisite for 5 | OPEN | engine.risk/execute currently contain controls; completeness not independently demonstrated | All requested limits, daily loss/drawdown and durable counters/holds; combinations/restart/bypass tests; if inadequate at 5, stop and request rescope |
| UI-01 | Accurate full operational/source/accounting/execution/audit status and per-strategy views | MEDIUM | 1H local; 9 full | OPEN | U and dashboard.html/main.state; A14-09 | No green mandatory stale/unknown/incomplete/held dimension; all requested views with explicit estimates/unverified evidence |
| SEC-01 | Dashboard authentication/session/authorization, CSRF, origin, validation, disclosure and rate limits | HIGH, exposure-conditional | 9; no public exposure earlier | OPEN | main Handler serves state and wallet action endpoint without authentication; binds 0.0.0.0 when started; not started here | No public deployment; design/test real auth/session/authorization beyond CSRF, sensitive errors/env/debug and cross-origin behavior; independent security review |
| OPS-01 | Verified backup, disposable restore and recovery procedure | HIGH | 1A safety; 9 full | OPEN | lab/store.py backup; lab/migrations.py verified-copy flow; V unchanged old backup | Restore drills, failure injection, consistent counts/typed digests and recoverability evidence; no overwrite of existing backup |
| OPS-02 | Worker restart/contention/network/retry-after/logging/alerting/disk/retention/load/soak/shutdown | HIGH | 1A/1F primitives; 9 full | OPEN | A14-10/A14-06; existing main/public/store limited behavior | Approved isolated operational tests, observable alerts and resource bounds; no actual runtime start during engineering tests |
| OPS-03 | Actual runtime activation and migration approval independent of engineering tests | HIGH | Separate gate after prerequisites | BLOCKED | V: V3 not applied; current prompt forbids runtime actions | Path and stopped-worker proof, new backup, disposable migration/restore, independent review and explicit user permission |
| FINAL-01 | Fresh whole-system 45-scenario adversarial suite and financial/source verification | HIGH | 10 | BLOCKED | Existing 119 tests and earlier probes do not constitute final verification | All prior gates, new disposable environment/evidence, exact per-scenario logs/state/accounting/fail-safe outcomes; unexplained mismatches fail |
| FINAL-02 | Genuinely separate final source/accounting/security/operations audit | HIGH | 10 | BLOCKED | A/H05: no independent auditor | Separate reviewer able to inspect actual code/migrations/evidence and challenge/reproduce all claims; no self-certification |
| DOC-01 | Complete truthful engineering/operator/financial/source/strategy/final documentation | MEDIUM | Each applicable phase; 10 closure | OPEN | Existing docs inventory; missing DATA_INTEGRITY/EXECUTION_MODEL/OPERATIONS/FINAL_VALIDATION noted in A | Add only implemented/supported behavior, rounding/evidence limits and reviewer provenance; preserve previous reports |

## 4. Test ownership and closure rules

The Plan §6 specifies before/after fixtures for every A14 finding and affected functions.
Plan §§7–9 define the broader test matrix and local-versus-external boundaries. A genuinely
separate reviewer must reproduce material original failures; merely reading this register
or repeating historical 119-test results does not satisfy Phase 0.

Allowed statuses: OPEN, IN_PROGRESS, PARTIALLY_RESOLVED, BLOCKED,
FIXED_PENDING_VERIFICATION, VERIFIED_FIXED, ACCEPTED_LIMITATION.
A finding may become VERIFIED_FIXED only after original/variation/regression cases and
relevant independent review pass. ACCEPTED_LIMITATION needs explicit rationale and
acceptance; it cannot waive paper-only safety, required source completeness or accounting
correctness. A required capability that is unavailable remains BLOCKED.

For each later update record dated old/new status, approved group, changed-file hashes,
exact test evidence, independent reviewer provenance, remaining blockers and user gate
approval. No row is deleted; children do not silently close parent H issues.

## 5. Part 18 disposition

No code fix or new defect reproduction was performed. A14-10 still needs dynamic
reproduction. The authentication exposure concern is an existing hardening requirement,
not a claim that the currently stopped application was accessed or exploited. Additional
material defects may be found by independent review.

Planning documents delivered; **STOP at Phase 0 review/approval**. No permission to begin
1A or any later group is inferred from their proposed tests or this register.
