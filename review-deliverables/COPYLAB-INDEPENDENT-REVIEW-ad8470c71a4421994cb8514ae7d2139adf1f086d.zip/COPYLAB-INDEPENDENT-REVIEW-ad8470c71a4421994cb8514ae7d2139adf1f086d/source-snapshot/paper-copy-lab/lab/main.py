import argparse,json,logging,threading,time,signal,os,secrets
from pathlib import Path
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
from urllib.parse import urlparse
from .store import Store,now
from .engine import Engine
from .public import Collector
from .wallets import Wallets
from .config import validate
ROOT=Path(__file__).resolve().parent.parent
class App:
    def __init__(self,db,config):
        if config.get('paper_only') is not True: raise ValueError('Only paper mode is permitted')
        self.s=Store(db,config)
        if self.s.synthetic:
            self.s.db.close(); raise ValueError('Synthetic fixture DB cannot run as application/forward observation')
        self.c=config; self.e=Engine(self.s,config); self.collect=Collector(self.s,config,self.e); self.wallets=Wallets(self.s); self.stop=threading.Event(); self.csrf=secrets.token_urlsafe(32)
    def run(self):
        while not self.stop.is_set():
            start=now()
            try:
                self.collect.cycle()
                clock=self.s.one("SELECT * FROM health WHERE component='public_api'")
                if not clock or not clock['ok'] or now()-clock['ts']>60: raise RuntimeError('public API/clock health unavailable; execution paused')
                self.e.process(); self.e.exits(); self.e.execute(); self.e.a.snapshot()
                self.s.health('engine',True,f'cycle completed in {now()-start:.2f}s; PAPER ONLY')
            except Exception as ex:
                logging.exception('cycle failed'); self.s.health('engine',False,ex)
            self.stop.wait(max(1,self.c['poll_seconds']-(now()-start)))
    def state(self):
        with self.s.lock:
            models={k:{'name':v['name'],**{t:self.e.a.metrics(k,t) for t in ('ideal','executable')}} for k,v in self.c['models'].items()}
            rankings=sorted(models,key=lambda k:float(models[k]['executable']['total_pnl']),reverse=True)
            return dict(paper_only=True,csrf=self.csrf,capital=float(self.c['starting_capital'])*5,models=models,rankings=rankings,wallets=self.s.rows('SELECT * FROM wallets'),closed_positions=self.s.rows('SELECT * FROM closed_positions ORDER BY id DESC LIMIT 500'),positions=self.s.rows('SELECT * FROM positions WHERE CAST(qty AS REAL)>0'),orders=self.s.rows('SELECT * FROM orders ORDER BY id DESC LIMIT 500'),fills=self.s.rows('SELECT f.*,o.model,o.track,o.wallet,o.token,o.side FROM fills f JOIN orders o ON o.id=f.order_id ORDER BY f.id DESC LIMIT 500'),decisions=self.s.rows('SELECT * FROM decisions ORDER BY id DESC LIMIT 200'),events=self.s.rows('SELECT * FROM events ORDER BY ts DESC LIMIT 100'),health=self.s.rows('SELECT * FROM health'),curves=self.s.rows('SELECT model,track,ts,equity FROM snapshots WHERE id IN (SELECT id FROM snapshots ORDER BY id DESC LIMIT 3000) ORDER BY id'),source_integrity=dict(states=self.s.rows('SELECT * FROM source_states'),gaps=self.s.rows('SELECT * FROM monitoring_gaps'),holds=self.s.rows('SELECT * FROM paper_holds'),reconciliations=self.s.rows('SELECT * FROM reconciliation_records ORDER BY id DESC LIMIT 100'),batches=self.s.rows('SELECT * FROM collection_batches ORDER BY id DESC LIMIT 100'),baselines=self.s.rows('SELECT * FROM baseline_evidence ORDER BY id DESC LIMIT 100')),forward_validation_ready=False,wallet_performance={r['key'][12:]:json.loads(r['value']) for r in self.s.rows("SELECT * FROM settings WHERE key LIKE 'performance:%'")},audit=self.s.rows('SELECT * FROM audit ORDER BY id DESC LIMIT 50'),warnings=['Provisional rankings: no strategy superiority established.','Ideal and executable are counterfactual tracks; do not add them together as $10,000 invested.','Source copying is blocked: ordinary REST does not prove a canonical checkpoint or event identity.','Token-finality settlements are supported; source merges/conversions quarantine monitoring rather than fabricate trades.'])
def main():
    p=argparse.ArgumentParser(); p.add_argument('--db',default=str(ROOT/'data/lab.sqlite')); p.add_argument('--port',type=int,default=8080); p.add_argument('--once',action='store_true'); p.add_argument('--backup'); args=p.parse_args()
    logging.basicConfig(level=logging.INFO,format='%(asctime)s %(levelname)s %(message)s')
    config=validate(json.loads((ROOT/'config.json').read_text())); app=App(args.db,config)
    if args.backup:
        app.s.backup(args.backup); print('Backup complete:',args.backup); return
    import fcntl
    lock=open(args.db+'.worker.lock','a')
    try: fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    except BlockingIOError: raise SystemExit('Another collector already owns this database. Stop it first.')
    if args.once:
        app.collect.cycle()
        clock=app.s.one("SELECT * FROM health WHERE component='public_api'")
        if not clock or not clock['ok'] or now()-clock['ts']>60: raise SystemExit('public API/clock health unavailable; no execution')
        app.e.process(); app.e.exits(); app.e.execute(); app.e.a.snapshot(); print(json.dumps(app.state(),indent=2)); return
    class Handler(BaseHTTPRequestHandler):
        def send(self,status,body,kind='application/json'):
            b=body.encode(); self.send_response(status); self.send_header('Content-Type',kind); self.send_header('Cache-Control','no-store'); self.send_header('X-Content-Type-Options','nosniff'); self.send_header('Content-Length',str(len(b))); self.end_headers(); self.wfile.write(b)
        def do_GET(self):
            if self.path=='/api/state': self.send(200,json.dumps(app.state()))
            elif self.path in ('/','/index.html'): self.send(200,(ROOT/'lab/dashboard.html').read_text(),'text/html; charset=utf-8')
            elif self.path=='/health': self.send(200,json.dumps(app.s.rows('SELECT * FROM health')))
            else: self.send(404,'{}')
        def do_POST(self):
            if self.path!='/api/wallets': self.send(404,'{}'); return
            if self.headers.get('X-Lab-CSRF')!=app.csrf: self.send(403,json.dumps({'error':'Missing same-origin CSRF token'})); return
            try:
                size=int(self.headers.get('Content-Length','0'))
                if not 0<size<=4096: raise ValueError('invalid request size')
                x=json.loads(self.rfile.read(size)); address=app.wallets.change(x['address'],x['action'],x.get('label','')); self.send(200,json.dumps({'address':address}))
            except (ValueError,KeyError) as ex: self.send(400,json.dumps({'error':str(ex)}))
        def log_message(self,*a): pass
    worker=threading.Thread(target=app.run,daemon=True); worker.start()
    server=ThreadingHTTPServer(('0.0.0.0',args.port),Handler)
    def stop(*_): app.stop.set(); threading.Thread(target=server.shutdown,daemon=True).start()
    signal.signal(signal.SIGTERM,stop); signal.signal(signal.SIGINT,stop)
    try: server.serve_forever()
    finally: app.stop.set(); worker.join(timeout=45); app.s.db.close()
if __name__=='__main__': main()
