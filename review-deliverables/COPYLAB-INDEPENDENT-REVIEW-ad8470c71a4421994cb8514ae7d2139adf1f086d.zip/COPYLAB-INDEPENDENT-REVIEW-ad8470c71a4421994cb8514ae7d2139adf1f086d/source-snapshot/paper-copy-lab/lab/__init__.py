"""Strictly read-only upstream, local paper execution laboratory."""
