import re
from .store import now
from .integrity import Integrity
class Wallets:
    def __init__(self,s): self.s=s
    def change(self,address,action,label=''):
        if not isinstance(address,str) or not re.fullmatch(r'0x[0-9a-fA-F]{40}',address) or int(address[2:],16)==0: raise ValueError('Expected nonzero 0x + 40 hexadecimal address (use Polymarket proxy wallet)')
        address=address.lower()
        with self.s.tx():
            old=self.s.one('SELECT * FROM wallets WHERE address=?',(address,))
            if action=='add':
                if old: raise ValueError('Wallet already exists; enable it instead. History is retained.')
                self.s.db.execute('INSERT INTO wallets(address,label,enabled,added,status) VALUES(?,?,?,?,?)',(address,str(label)[:80],1,now(),'awaiting first poll; source inventory unverified'))
            elif action in ('enable','disable','remove'):
                if not old: raise ValueError('Unknown wallet')
                if action=='enable':
                    # Require a new stable baseline after monitoring gaps.
                    self.s.db.execute('DELETE FROM settings WHERE key=?',('inventory:'+address,))
                if action in ('disable','remove'):
                    self.s.db.execute("UPDATE orders SET status='cancelled',reason='wallet disabled or removed' WHERE wallet=? AND side='BUY' AND status='pending'",(address,))
                self.s.db.execute('UPDATE wallets SET enabled=?,removed=?,status=? WHERE address=?',(int(action=='enable'),int(action=='remove'),'awaiting poll' if action=='enable' else action,address))
            else: raise ValueError('Unknown wallet action')
            self.s.db.execute('INSERT INTO monitoring_history(wallet,ts,action,detail) VALUES(?,?,?,?)',(address,now(),action,'operator intent; not source verification'))
            if action=='add':
                self.s.db.execute('INSERT INTO source_states(wallet,state,reason) VALUES(?,?,?)',(address,'verified' if self.s.synthetic else 'quarantined','synthetic fixture only' if self.s.synthetic else 'no verified checkpoint'))
            else:
                Integrity(self.s).gap(address,'monitoring '+action+'; inventory and paper review required')
                self.s.db.execute("UPDATE orders SET status='cancelled',reason='monitoring interrupted' WHERE wallet=? AND status='pending'",(address,))
            self.s.audit('wallet_'+action,{'address':address,'label':str(label)[:80],'previous':old})
        return address
