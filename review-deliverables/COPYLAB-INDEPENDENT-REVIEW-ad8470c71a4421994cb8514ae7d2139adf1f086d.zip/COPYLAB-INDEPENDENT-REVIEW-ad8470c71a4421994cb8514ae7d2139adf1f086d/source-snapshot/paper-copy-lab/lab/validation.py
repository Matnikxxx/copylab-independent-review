"""Read-only forward evidence export; reports observations, never invents results."""
import json
from .store import now

def forward_evidence(s):
    tables=['execution_context','source_observations','observation_flags','transport_deliveries','collection_pages','collection_batches','capture_frontiers','baseline_evidence','source_states','verified_events','event_links','source_movements','source_inventory','monitoring_history','monitoring_gaps','reconciliation_records','paper_holds','events','decisions','orders','fills','ledger','positions','closed_positions','snapshots','books','markets','health']
    # No wallet address is manufactured. Exports supplied DB records only.
    data={name:s.rows('SELECT * FROM '+name) for name in tables}
    classification=s.one('SELECT kind FROM source_environment WHERE id=1')['kind']
    wallets=s.rows('SELECT * FROM wallets')
    latency=[]
    for fill in data['fills']:
        order=next((o for o in data['orders'] if o['id']==fill['order_id']),None)
        event=next((e for e in data['events'] if order and e['id']==order['event']),None)
        latency.append({'fill':fill['id'],'source_to_fill_seconds':fill['ts']-event['ts'] if event else None,'arrival_to_fill_seconds':fill['ts']-event['detected'] if event else None,'due_to_fill_seconds':fill['ts']-order['due'] if order else None,'classification':classification})
    portfolios={}
    for model in 'ABCDE':
        portfolios[model]={}
        for track in ('ideal','executable'):
            matches=[x for x in data['snapshots'] if x['model']==model and x['track']==track]
            latest=max(matches,key=lambda x:x['id']) if matches else None
            portfolios[model][track]={'metrics':json.loads(latest['metrics']) if latest else None,'as_of':latest['ts'] if latest else None,'missing_reason':None if latest else 'no observed accounting snapshot; not assumed zero'}
    execution_evidence=[]
    for order in data['orders']:
        books=[b for b in data['books'] if b['token']==order['token'] and b['ts']>=order['due']]
        linked=[x for x in data['execution_context'] if any(f['id']==x['fill_id'] and f['order_id']==order['id'] for f in data['fills'])]
        execution_evidence.append({'order':order['id'],'candidate_post_due_book_ids':[b['id'] for b in books],'actual_execution_book_ids':[x['book_id'] for x in linked] if linked else None,'limitation':None if linked else 'no exact execution context retained (ideal, fixture or legacy); candidate books are not proof of consumption'})
    return dict(portfolios=portfolios,execution_evidence=execution_evidence,schema='copylab-forward-evidence-v1',classification=classification,third_party_audit=False,forward_ready=False,supplied_wallet_count=len(wallets),observations_only=True,no_forward_results=not data['fills'],profitability_claim=False,latencies=latency,records=data,limitations=['No audited canonical checkpoint adapter.','Book sequences/fill timestamps/fees and snapshots are evidence, not proof of obtainable execution.','Synthetic fixtures are never forward market evidence.'])
