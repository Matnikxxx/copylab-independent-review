import hashlib,json
from decimal import Decimal
from .store import dec as d,money as m,now
from .accounting import Accounting
from .strategies import STRATEGIES
from .integrity import Integrity, dump, economic_key
class Engine:
    def __init__(self,s,c): self.s=s; self.c=c; self.a=Accounting(s,c)
    def ingest(self,w,row,detected=None):
        if not self.s.synthetic:
            return Integrity(self.s).observe(w,'/v2/trades',row)
        detected=now() if detected is None else detected
        # Include all economic fields; same-tx different outcomes are not collapsed.
        side=row['side']; token=str(row['token_id']); qty=d(row['size']); price=d(row['price']); ts=float(row['timestamp'])
        if side not in ('BUY','SELL') or qty<=0 or not 0<price<1 or ts>detected+5: raise ValueError('invalid upstream trade')
        if row.get('is_combo'): raise ValueError('combo trade unsupported; inventory reconciliation required')
        if row.get('proxy_wallet','').lower()!=w: raise ValueError('wallet filter mismatch')
        # Explicit fixture certification, not a production blockchain identity.
        identity=dump(['fixture',row['transaction_hash'],token,side,ts])
        old=self.s.one('SELECT id FROM verified_events WHERE wallet=? AND identity=?',(w,identity))
        ordinal=old['id'] if old else self.s.one('SELECT COALESCE(MAX(id),0)+1 n FROM verified_events')['n']
        evidence={**row,'size':format(qty.normalize(),'f'),'price':format(price.normalize(),'f')}
        vid=Integrity(self.s).synthetic_event(w,identity,side,evidence,ordinal)
        eid='synthetic-event:'+str(vid)
        with self.s.tx():
            self.s.db.execute('INSERT OR IGNORE INTO events(id,wallet,token,market,side,qty,price,ts,detected,payload) VALUES(?,?,?,?,?,?,?,?,?,?)',(eid,w,token,row['condition_id'],side,m(qty),m(price),ts,detected,json.dumps(row)))
            self.s.db.execute('INSERT OR IGNORE INTO copy_event_links VALUES(?,?)',(eid,vid))
        return eid
    def book(self,token,at=None):
        b=self.s.one('SELECT * FROM books WHERE token=? AND ts<=? ORDER BY ts DESC LIMIT 1',(token,now() if at is None else at))
        if not b: return None
        b.update(json.loads(b['payload'])); return b
    def context(self,e,model,track):
        cfg={**self.c,**self.c['models'][model]}; b=self.book(e['token'])
        if not b or now()-b['ts']>self.c['book_max_age_seconds']: return None
        asks=sorted((d(x['price']),d(x['size'])) for x in b['asks']); bids=sorted((d(x['price']),d(x['size'])) for x in b['bids'])
        if not asks or not bids: return None
        hist=self.s.rows('SELECT payload FROM books WHERE token=? AND ts<=? ORDER BY ts DESC LIMIT 12',(e['token'],now()))
        history=[]
        for h in reversed(hist):
            bs=json.loads(h['payload']).get('bids',[])
            if bs: history.append(max(d(x['price']) for x in bs))
        perf=self.s.one('SELECT value FROM settings WHERE key=?',('performance:'+e['wallet'],))
        performance=json.loads(perf['value']) if perf else {}
        if now()-performance.get('observed',0)>600: performance={}
        closes=performance.get('closes',0); wins=performance.get('wins',0)
        ps=self.s.rows('SELECT * FROM positions WHERE model=? AND track=?',(model,track))
        metrics=self.a.metrics(model,track)
        activity=self.s.one('SELECT COUNT(*) n FROM events WHERE token=? AND ts>=? AND detected<=?',(e['token'],now()-120,now()))['n']
        return dict(activity_count=activity,cfg=cfg,book=b,ask=asks[0][0],bid=bids[-1][0],spread=asks[0][0]-bids[-1][0],liquidity=sum((p*q for p,q in asks),d(0)),history=history,wallet_closes=closes,wallet_wins=wins,wallet_exposure=sum((d(p['cost']) for p in ps if p['wallet']==e['wallet']),d(0)),drawdown=d(metrics['current_drawdown']),positions=ps,metrics=metrics)
    def process(self):
        cutoff=now()-self.c['detection_latency_seconds']
        for e in self.s.rows("SELECT e.* FROM events e LEFT JOIN copy_event_links c ON c.event_id=e.id LEFT JOIN verified_events v ON v.id=c.verified_event WHERE e.status='new' AND e.detected<=? ORDER BY v.ordering",(cutoff,)):
            with self.s.tx():
                if self.s.one('SELECT status FROM events WHERE id=?',(e['id'],))['status']!='new': continue
                w=self.s.one('SELECT * FROM wallets WHERE address=?',(e['wallet'],))
                if not Integrity(self.s).allowed(e['wallet']):
                    for model in 'ABCDE':
                        for track in ('ideal','executable'):
                            self.s.db.execute('INSERT OR IGNORE INTO decisions(event,model,track,ts,reason,qty) VALUES(?,?,?,?,?,?)',(e['id'],model,track,now(),'source checkpoint/identity or reconciliation unverified','0'))
                    self.s.db.execute("UPDATE events SET status='quarantined' WHERE id=?",(e['id'],))
                    continue
                last=self.s.one("SELECT MAX(ts) AS ts FROM events WHERE wallet=? AND token=? AND status='processed'",(e['wallet'],e['token']))
                late=last and last['ts'] is not None and e['ts']<last['ts']
                source=self.s.one('SELECT qty FROM source_positions WHERE wallet=? AND token=?',(e['wallet'],e['token']))
                sq=d(source['qty']) if source else d(0)
                mismatch=e['side']=='SELL' and (sq<=0 or d(e['qty'])>sq)
                if late or mismatch:
                    self.s.db.execute('UPDATE wallets SET enabled=0,status=? WHERE address=?',('inventory/order quarantine; reconciliation required',e['wallet']))
                    self.s.audit('event_quarantine',{'event':e['id'],'late':bool(late),'source_mismatch':mismatch})
                fraction=min(d(1),d(e['qty'])/sq) if sq else None
                for model in 'ABCDE':
                    for track in ('ideal','executable'):
                        reason=None; qty=d(0)
                        if not w or not w['enabled'] or w['removed']: reason='wallet disabled or removed'
                        elif self.s.one("SELECT * FROM health WHERE component=? AND ok=0",('wallet:'+e['wallet'],)): reason='wallet monitoring unavailable'
                        elif not self.s.one('SELECT value FROM settings WHERE key=?',('inventory:'+e['wallet'],)): reason='source inventory not baselined'
                        elif e['ts']<w['added']: reason='pre-monitoring history; no replay fills'
                        elif late: reason='out-of-order event quarantined'
                        elif now()-e['ts']>self.c['max_event_age_seconds']: reason='stale event; no historical executable book'
                        elif mismatch: reason='source inventory mismatch; sell quarantined'
                        elif e['side']=='SELL':
                            p=self.s.one('SELECT * FROM positions WHERE model=? AND track=? AND wallet=? AND token=?',(model,track,e['wallet'],e['token']))
                            if not p or d(p['qty'])<=0: reason='no copied position'
                            elif fraction is None: reason='unknown source inventory; sell quarantined'
                            else: qty=d(p['qty'])*fraction; reason='mirror proportional sell'
                        else:
                            ctx=self.context(e,model,track)
                            if ctx is None: reason='fresh two-sided order book unavailable'
                            else:
                                ok,reason,scale=STRATEGIES[model].entry(e,ctx)
                                if ok:
                                    amount=min(d(e['qty'])*d(e['price'])*d(self.c['copy_fraction'])*scale,d(ctx['cfg']['max_copy_amount']))
                                    price=d(e['price']) if track=='ideal' else ctx['ask']
                                    qty=amount/price
                                    block=self.risk(e,model,track,amount,price,ctx)
                                    if block: reason=block; qty=d(0)
                        self.s.db.execute('INSERT OR IGNORE INTO decisions(event,model,track,ts,reason,qty) VALUES(?,?,?,?,?,?)',(e['id'],model,track,now(),reason,m(qty)))
                        if qty>0:
                            self.s.db.execute('INSERT OR IGNORE INTO orders(event,model,track,wallet,token,market,side,qty,reference,due,status,reason) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',(e['id'],model,track,e['wallet'],e['token'],e['market'],e['side'],m(qty),e['price'],now()+(self.c['execution_latency_seconds'] if track=='executable' else 0),'pending',reason))
                if not late and not mismatch and e['ts']>=w['added']:
                    nq=sq+d(e['qty']) if e['side']=='BUY' else max(d(0),sq-d(e['qty']))
                    self.s.db.execute('INSERT OR REPLACE INTO source_positions VALUES(?,?,?)',(e['wallet'],e['token'],m(nq)))
                self.s.db.execute("UPDATE events SET status=? WHERE id=?",('quarantined' if late or mismatch else 'processed',e['id']))
    def risk(self,e,model,track,amount,price,ctx):
        c=ctx['cfg']; ps=ctx['positions']; met=ctx['metrics']
        if met['unpriced_or_stale_positions']: return 'stale or unpriced portfolio; entry paused'
        if amount>d(c['max_copy_amount']): return 'max_copy_amount'
        if price>d(c['maximum_entry_price']): return 'maximum entry price'
        if ctx['liquidity']<d(c['minimum_liquidity']): return 'minimum liquidity'
        if amount>d(met['available_cash']): return 'insufficient cash'
        pending=self.s.rows("SELECT * FROM orders WHERE model=? AND track=? AND side='BUY' AND status='pending'",(model,track))
        total=sum((d(p['qty'])*d(p['reference']) for p in pending),d(0))
        if amount+total>d(met['available_cash']): return 'pending cash reservations'
        if d(met['open_exposure'])+total+amount>d(c['max_portfolio_exposure']): return 'portfolio exposure'
        for field,cap in [('wallet','max_wallet_exposure'),('market','max_market_exposure'),('token','max_position')]:
            exposure=sum((d(p['cost']) for p in ps if p[field]==e[field]),d(0))
            reserved=sum((d(p['qty'])*d(p['reference']) for p in pending if p[field]==e[field]),d(0))
            if exposure+reserved+amount>d(c[cap]): return cap
        if d(met['current_drawdown'])>=d(c['max_drawdown']): return 'drawdown circuit breaker'
        import datetime
        day=datetime.datetime.now(datetime.timezone.utc).replace(hour=0,minute=0,second=0,microsecond=0).timestamp()
        opening=self.s.one('SELECT equity FROM snapshots WHERE model=? AND track=? AND ts>=? ORDER BY ts LIMIT 1',(model,track,day))
        base=d(opening['equity']) if opening else d(self.c['starting_capital'])
        if base-d(met['portfolio_equity'])>=d(c['max_daily_loss']): return 'daily loss circuit breaker'
        n=self.s.one('SELECT COUNT(*) AS n FROM orders WHERE model=? AND track=? AND due>?',(model,track,now()-3600))['n']
        if n>=c['max_trades_hour']: return 'trade frequency limit'
    def execute(self):
        for o in self.s.rows("SELECT * FROM orders WHERE status='pending' AND due<=? ORDER BY due,id",(now(),)):
            with self.s.tx():
                if self.s.one('SELECT status FROM orders WHERE id=?',(o['id'],))['status']!='pending': continue
                if not self.s.synthetic and not Integrity(self.s).allowed(o['wallet']):
                    self.reject(o,'source integrity/reconciliation unverified'); continue
                if self.s.one('SELECT * FROM paper_holds WHERE model=? AND track=? AND wallet=? AND token=?',(o['model'],o['track'],o['wallet'],o['token'])):
                    self.reject(o,'paper position held for reconciliation'); continue
                book_used=None
                qty=d(o['qty']); ref=d(o['reference']); price=ref; fee=d(0); slip=d(0); reason='filled'
                w=self.s.one('SELECT * FROM wallets WHERE address=?',(o['wallet'],))
                if o['side']=='BUY' and (not w or not w['enabled'] or w['removed'] or self.s.one("SELECT * FROM health WHERE component=? AND ok=0",('wallet:'+o['wallet'],))):
                    self.reject(o,'wallet disabled before execution'); continue
                if o['track']=='executable':
                    b=self.book(o['token'])
                    if not b or b['ts']<o['due'] or now()-b['ts']>self.c['book_max_age_seconds']:
                        if now()-o['due']>self.c['max_event_age_seconds']: self.reject(o,'no post-latency fresh book')
                        continue
                    book_used=b
                    if qty<d(b.get('min_order_size','0')):
                        self.reject(o,'below market minimum order shares'); continue
                    market=self.s.one('SELECT * FROM markets WHERE token=?',(o['token'],))
                    if not market or now()-market['updated']>600 or market['fee_rate'] is None or market['fee_exponent']!='1':
                        self.reject(o,'unknown or unsupported fee schedule'); continue
                    levels=sorted([(d(x['price']),d(x['size'])) for x in b['asks' if o['side']=='BUY' else 'bids']],reverse=o['side']=='SELL')
                    remaining=qty; filled=d(0); value=d(0)
                    used=self.s.rows('SELECT f.qty FROM fills f JOIN orders x ON x.id=f.order_id WHERE x.model=? AND x.track=? AND x.token=? AND x.side=? AND f.ts>=?',(o['model'],o['track'],o['token'],o['side'],b['ts']))
                    consumed=sum((d(f['qty']) for f in used),d(0))
                    for p,q in levels:
                        if p<=0 or p>=1: continue
                        if (o['side']=='BUY' and p>min(ref+d(self.c['max_price_deviation']),d(self.c['maximum_entry_price']))) or (o['side']=='SELL' and p<ref-d(self.c['max_price_deviation'])): continue
                        capacity=q*d(self.c['depth_participation'])
                        depletion=min(capacity,consumed); consumed-=depletion; capacity-=depletion
                        take=min(remaining,capacity)
                        value+=take*p; fee+=take*d(market['fee_rate'])*p*(1-p); filled+=take; remaining-=take
                        if remaining<=0: break
                    if not filled: self.reject(o,'insufficient acceptable liquidity'); continue
                    qty=filled; price=value/filled; slip=qty*(price-ref)*(1 if o['side']=='BUY' else -1)
                    if remaining>0: reason='partial fill; remainder cancelled'
                if o['side']=='BUY':
                    ctx=self.context(o,o['model'],o['track'])
                    if ctx is None: self.reject(o,'fresh risk context unavailable'); continue
                    # Exclude own reservation, then recheck with actual fill cash including fees.
                    self.s.db.execute("UPDATE orders SET status='executing' WHERE id=?",(o['id'],))
                    block=self.risk(o,o['model'],o['track'],qty*price+fee,price,ctx)
                    if block: self.reject(o,'execution risk: '+block); continue
                else:
                    p=self.s.one('SELECT qty FROM positions WHERE model=? AND track=? AND wallet=? AND token=?',(o['model'],o['track'],o['wallet'],o['token']))
                    avail=d(p['qty']) if p else d(0)
                    if avail<=0: self.reject(o,'position already exited'); continue
                    if qty>avail: fee*=avail/qty; slip*=avail/qty; qty=avail
                self.a.fill(o,qty,price,fee,slip)
                fid=self.s.one('SELECT MAX(id) id FROM fills WHERE order_id=?',(o['id'],))['id']
                if book_used:
                    asks=book_used.get('asks',[]);bids=book_used.get('bids',[])
                    spread=min(d(x['price']) for x in asks)-max(d(x['price']) for x in bids) if asks and bids else None
                    self.s.db.execute('INSERT INTO execution_context VALUES(?,?,?,?,?,?,?)',(fid,book_used['id'],o['reference'],book_used['ts'],m(spread) if spread is not None else None,json.dumps({'asks':asks,'bids':bids}),json.dumps({'order_due':o['due'],'classification':'synthetic' if self.s.synthetic else 'observed paper','assumption':'participation-limited depth walk; not real exchange fill'})))
                self.s.db.execute('UPDATE orders SET status=?,reason=? WHERE id=?',('filled' if qty==d(o['qty']) else 'partial',reason,o['id']))
    def reject(self,o,reason): self.s.db.execute("UPDATE orders SET status='rejected',reason=? WHERE id=?",(reason,o['id']))
    def exits(self):
        for p in self.s.rows('SELECT * FROM positions WHERE CAST(qty AS REAL)>0'):
            if self.s.one('SELECT * FROM paper_holds WHERE model=? AND track=? AND wallet=? AND token=?',(p['model'],p['track'],p['wallet'],p['token'])): continue
            if not self.s.synthetic and not Integrity(self.s).allowed(p['wallet']): continue
            b=self.book(p['token'])
            if not b or now()-b['ts']>self.c['book_max_age_seconds'] or not b['bids']: continue
            bid=max(d(x['price']) for x in b['bids']); basis=d(p['cost'])/d(p['qty']); change=(bid-basis)/basis
            cfg=self.c['models'][p['model']]
            reason='model stop loss' if change<=-d(cfg['stop_loss']) else 'model take profit' if change>=d(cfg['take_profit']) else None
            if p['model']=='B' and b['asks']:
                spread=min(d(x['price']) for x in b['asks'])-bid
                if spread>d(cfg['max_spread'])*2: reason='selective spread deterioration'
            elif p['model']=='C':
                history=self.s.rows('SELECT payload FROM books WHERE token=? AND ts<=? ORDER BY ts DESC LIMIT 3',(p['token'],now()))
                marks=[max((d(v['price']) for v in json.loads(x['payload']).get('bids',[])),default=d(0)) for x in history]
                if len(marks)==3 and marks[0]<marks[1]<marks[2] and marks[2]-marks[0]>d('.01'): reason='momentum reversal'
            elif p['model']=='D' and bid>=d(cfg['maximum_price']): reason='value target repricing'
            elif p['model']=='E':
                metrics=self.a.metrics(p['model'],p['track'])
                if d(metrics['current_drawdown'])>=d(cfg['max_drawdown'])/2: reason='risk-adjusted portfolio de-risking'
            if reason:
                with self.s.tx():
                    pending=self.s.one("SELECT id FROM orders WHERE model=? AND track=? AND wallet=? AND token=? AND side='SELL' AND status='pending'",(p['model'],p['track'],p['wallet'],p['token']))
                    if pending: continue
                    eid='exit:'+hashlib.sha256(json.dumps([p, b['ts']],sort_keys=True).encode()).hexdigest()
                    self.s.db.execute('INSERT OR IGNORE INTO orders(event,model,track,wallet,token,market,side,qty,reference,due,status,reason) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',(eid,p['model'],p['track'],p['wallet'],p['token'],p['market'],'SELL',p['qty'],m(bid),now()+(self.c['execution_latency_seconds'] if p['track']=='executable' else 0),'pending',reason))

    def settle(self,token,payout,evidence):
        if not self.s.synthetic:
            with self.s.tx():
                for p in self.s.rows('SELECT DISTINCT wallet FROM positions WHERE token=? AND CAST(qty AS REAL)>0',(token,)):
                    Integrity(self.s).hold(p['wallet'],'REST payout observation requires verified settlement evidence')
            return
        payout=d(payout)
        if not 0<=payout<=1: raise ValueError('invalid payout')
        if evidence.get('resolved') is not True or evidence.get('token_id')!=token: raise ValueError('unverified finality')
        with self.s.tx():
            self.s.db.execute("UPDATE orders SET status='cancelled',reason='token resolved' WHERE token=? AND status='pending'",(token,))
            for p in self.s.rows('SELECT * FROM positions WHERE token=? AND CAST(qty AS REAL)>0',(token,)):
                eid='settlement:'+token+':'+p['wallet']
                oid=self.s.db.execute('INSERT OR IGNORE INTO orders(event,model,track,wallet,token,market,side,qty,reference,due,status,reason) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',(eid,p['model'],p['track'],p['wallet'],token,p['market'],'SELL',p['qty'],m(payout),now(),'settled','verified public token final payout')).lastrowid
                order=self.s.one('SELECT * FROM orders WHERE id=?',(oid,))
                self.a.fill(order,p['qty'],payout,0,0)
            self.s.audit('resolution_observed',{'token':token,'payout':str(payout),'evidence':evidence})
