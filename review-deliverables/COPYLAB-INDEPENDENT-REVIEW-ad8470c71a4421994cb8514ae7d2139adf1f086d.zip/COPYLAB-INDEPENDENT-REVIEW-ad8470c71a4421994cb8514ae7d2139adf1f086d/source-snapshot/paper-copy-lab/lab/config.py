from .store import dec

def validate(c):
    if c.get('paper_only') is not True: raise ValueError('paper_only must remain true')
    if set(c.get('models',{}))!=set('ABCDE'): raise ValueError('Exactly models A–E are required')
    positive=['starting_capital','poll_seconds','book_max_age_seconds','max_event_age_seconds','max_copy_amount','max_position','max_wallet_exposure','max_market_exposure','max_portfolio_exposure','max_daily_loss','minimum_liquidity','max_trades_hour']
    for key in positive:
        if dec(c[key])<=0: raise ValueError(key+' must be positive')
    for key in ['copy_fraction','max_drawdown','maximum_entry_price','max_price_deviation','depth_participation']:
        if not 0<dec(c[key])<=1: raise ValueError(key+' must be in (0, 1]')
    for key in ['detection_latency_seconds','execution_latency_seconds']:
        if dec(c[key])<0: raise ValueError('negative latency')
    for name,m in c['models'].items():
        for k,v in m.items():
            if k=='name':continue
            if dec(v)<=0:raise ValueError(name+'.'+k+' must be positive')
    return c
