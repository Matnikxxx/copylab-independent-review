from .store import dec as d, money as m, now
from decimal import Decimal
ZERO=Decimal(0)
class Accounting:
    def __init__(self,store,config): self.s=store; self.c=config
    def metrics(self,model,track,at=None):
        at=now() if at is None else at
        rows=self.s.rows('SELECT * FROM ledger WHERE model=? AND track=?',(model,track))
        cash=d(self.c['starting_capital'])+sum((d(r['cash_delta']) for r in rows),ZERO)
        realized=sum((d(r['realized']) for r in rows),ZERO)
        fees=sum((d(r['fee']) for r in rows),ZERO)
        ps=self.s.rows('SELECT * FROM positions WHERE model=? AND track=? AND CAST(qty AS REAL)>0',(model,track))
        cost=sum((d(p['cost']) for p in ps),ZERO); value=ZERO; stale=0
        for p in ps:
            b=self.s.one('SELECT * FROM books WHERE token=? AND ts<=? ORDER BY ts DESC LIMIT 1',(p['token'],at))
            import json
            bids=json.loads(b['payload']).get('bids',[]) if b else []
            if bids:
                mark=max(d(x['price']) for x in bids)
                stale+=int(at-b['ts']>self.c['book_max_age_seconds'])
            else:
                # Carry acquisition cost, explicitly flagged unpriced; never present as observed mark.
                mark=d(p['cost'])/d(p['qty']); stale+=1
            value+=d(p['qty'])*mark
        equity=cash+value; total=realized+value-cost
        peaks=self.s.rows('SELECT equity FROM snapshots WHERE model=? AND track=?',(model,track))
        peak=max([d(self.c['starting_capital']),equity]+[d(x['equity']) for x in peaks])
        dd=(peak-equity)/peak if peak else ZERO
        old=self.s.rows('SELECT metrics FROM snapshots WHERE model=? AND track=? ORDER BY id DESC LIMIT 1',(model,track))
        import json
        maxdd=max(dd,d(json.loads(old[0]['metrics'])['maximum_drawdown']) if old else ZERO)
        fs=self.s.rows('SELECT f.* FROM fills f JOIN orders o ON o.id=f.order_id WHERE o.model=? AND o.track=?',(model,track))
        sells=self.s.rows("SELECT f.realized FROM fills f JOIN orders o ON o.id=f.order_id WHERE o.model=? AND o.track=? AND o.side='SELL'",(model,track))
        closed=self.s.rows('SELECT * FROM closed_positions WHERE model=? AND track=?',(model,track))
        wins=sum(d(x['realized'])>0 for x in closed)
        result={k:m(v) for k,v in dict(starting_balance=d(self.c['starting_capital']),available_cash=cash,invested_capital=cost,realized_pnl=realized,unrealized_pnl=value-cost,total_pnl=total,roi=total/d(self.c['starting_capital']),open_position_value=value,open_exposure=cost,portfolio_equity=equity,peak_equity=peak,maximum_drawdown=maxdd,current_drawdown=dd,fees=fees,slippage_costs=sum((d(f['slippage']) for f in fs),ZERO),win_rate=Decimal(wins)/Decimal(len(closed)) if closed else ZERO).items()}
        result.update(trade_count=len(fs),closed_fill_count=len(sells),closed_position_count=len(closed),unpriced_or_stale_positions=stale,provisional=True)
        return result
    def fill(self,order,qty,price,fee,slippage,ts=None):
        # Caller holds the same database transaction as order completion.
        ts=now() if ts is None else ts; qty=d(qty); price=d(price); fee=d(fee)
        if qty<=0 or price<0 or price>1 or fee<0: raise ValueError('invalid fill')
        key=(order['model'],order['track'],order['wallet'],order['token'])
        p=self.s.one('SELECT * FROM positions WHERE model=? AND track=? AND wallet=? AND token=?',key)
        pq=d(p['qty']) if p else ZERO; pc=d(p['cost']) if p else ZERO
        if order['side']=='BUY':
            cost=qty*price+fee
            cash=d(self.metrics(order['model'],order['track'])['available_cash'])
            if cost>cash: raise ValueError('insufficient paper cash')
            nq=pq+qty; nc=pc+cost; cd=-cost; basis=cost; realized=ZERO
        else:
            if qty>pq: raise ValueError('oversell')
            basis=pc if qty==pq else pc*qty/pq
            nq=pq-qty; nc=pc-basis; cd=qty*price-fee; realized=cd-basis; basis=-basis
        db=self.s.db
        db.execute('INSERT OR REPLACE INTO positions VALUES(?,?,?,?,?,?,?)',(*key,order['market'],m(nq),m(nc)))
        fid=db.execute('INSERT INTO fills(order_id,ts,qty,price,fee,slippage,realized) VALUES(?,?,?,?,?,?,?)',(order['id'],ts,m(qty),m(price),m(fee),m(slippage),m(realized))).lastrowid
        db.execute('INSERT INTO ledger(model,track,fill_id,ts,cash_delta,cost_delta,realized,fee) VALUES(?,?,?,?,?,?,?,?)',(order['model'],order['track'],fid,ts,m(cd),m(basis),m(realized),m(fee)))
        if order['side']=='SELL' and nq==0:
            last=self.s.one('SELECT MAX(closing_fill) AS id FROM closed_positions WHERE model=? AND track=? AND wallet=? AND token=?',key)
            prior=last['id'] if last and last['id'] else 0
            cycle=self.s.rows('SELECT f.*,o.side FROM fills f JOIN orders o ON o.id=f.order_id WHERE o.model=? AND o.track=? AND o.wallet=? AND o.token=? AND f.id>? ORDER BY f.id',(*key,prior))
            entry=sum((d(f['qty'])*d(f['price'])+d(f['fee']) for f in cycle if f['side']=='BUY'),ZERO)
            proceeds=sum((d(f['qty'])*d(f['price'])-d(f['fee']) for f in cycle if f['side']=='SELL'),ZERO)
            db.execute('INSERT INTO closed_positions(model,track,wallet,token,market,closing_fill,opened,closed,cost,proceeds,realized) VALUES(?,?,?,?,?,?,?,?,?,?,?)',(*key,order['market'],fid,cycle[0]['ts'],ts,m(entry),m(proceeds),m(proceeds-entry)))

    def snapshot(self):
        import json
        with self.s.tx():
            for model in 'ABCDE':
                for track in ('ideal','executable'):
                    x=self.metrics(model,track)
                    self.s.db.execute('INSERT INTO snapshots(model,track,ts,equity,metrics) VALUES(?,?,?,?,?)',(model,track,now(),x['portfolio_equity'],json.dumps(x)))
