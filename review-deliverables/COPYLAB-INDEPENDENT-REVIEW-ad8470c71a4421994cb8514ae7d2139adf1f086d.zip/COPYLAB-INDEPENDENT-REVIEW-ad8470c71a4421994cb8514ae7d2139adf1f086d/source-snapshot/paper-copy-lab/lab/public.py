"""GET-only, fixed-origin public API client. No signing or order API exists."""
import json,time,random,urllib.parse,subprocess
from .store import now,dec as d
from .integrity import Integrity
class PublicClient:
    ORIGINS={'data':'https://data-api.polymarket.com','gamma':'https://gamma-api.polymarket.com','clob':'https://clob.polymarket.com'}
    ALLOWED={'data':{'/v2/trades','/v2/activity','/v2/positions','/v2/status','/v2/resolutions','/v2/tokens'},'gamma':{'/markets'},'clob':{'/book','/time'}}
    def get(self,service,path,**params):
        if path not in self.ALLOWED.get(service,set()): raise ValueError('not an allowlisted public read endpoint')
        url=self.ORIGINS[service]+path+'?'+urllib.parse.urlencode(params)
        # curl works with this environment's egress proxy (urllib CLOB returned 403).
        error=''; self.attempt_log=[]; self.last_raw=None
        for attempt in range(3):
            r=subprocess.run(['curl','--silent','--show-error','--max-time','12','--proto','=https','--max-redirs','0','-w','\n%{http_code}',url],capture_output=True,text=True,timeout=15)
            body,_,code=r.stdout.rpartition('\n')
            self.attempt_log.append({'received':now(),'http_code':code,'body':body,'error':r.stderr[:1000]})
            self.last_raw=body
            if r.returncode==0 and code=='200':
                self.last_raw=body
                return json.loads(body)
            error=f'{service}{path}: HTTP {code} {r.stderr[:100]}'
            if code and code not in ('429','500','502','503','504','000'): break
            time.sleep(min(8,2**attempt)+random.random())
        raise RuntimeError(error)
    def pages(self,path,**params):
        cursor=None; seen=set()
        for _ in range(1000):
            p=self.get('data',path,**params,**({'cursor':cursor} if cursor else {}))
            if not isinstance(p.get('data'),list): raise ValueError('invalid data envelope')
            yield p['data']
            cursor=p.get('pagination',{}).get('next_cursor')
            if not cursor: return
            if cursor in seen: raise RuntimeError('repeating pagination cursor')
            seen.add(cursor)
        raise RuntimeError('pagination safety cap reached; watermark not advanced')

class Collector:
    def __init__(self,s,c,e,client=None): self.s=s; self.c=c; self.e=e; self.api=client or PublicClient()
    def cycle(self):
        try:
            server=self.api.get('clob','/time')
            self.s.health('public_api',abs(float(server)-now())<30,f'server time {server}; local clock delta {abs(float(server)-now()):.2f}s')
        except Exception as ex: self.s.health('public_api',False,ex)
        status=None
        try:
            status=self.api.get('data','/v2/status')
            good,reason=self.source_health(status)
            self.s.health('data_api',good,reason)
        except Exception as ex:
            self.s.health('data_api',False,str(ex))
        for w in self.s.rows('SELECT * FROM wallets WHERE enabled=1 AND removed=0'):
            try:
                if not self.source_health(status)[0]:
                    with self.s.tx(): Integrity(self.s).gap(w['address'],'Data API freshness unverified')
                self.baseline(w,status)
                self.s.health('wallet:'+w['address'],False,'captured only; canonical checkpoint/identity unavailable')
            except Exception as ex:
                self.s.health('wallet:'+w['address'],False,ex)
                with self.s.tx(): Integrity(self.s).gap(w['address'],'collection failure: '+str(ex))
        tokens={x['token'] for x in self.s.rows("SELECT DISTINCT token FROM events WHERE status='new' UNION SELECT token FROM positions WHERE CAST(qty AS REAL)>0 UNION SELECT token FROM orders WHERE status='pending'")}
        # Always collect a public-data sentinel without choosing or adding a wallet.
        try:
            markets=self.api.get('gamma','/markets',limit=1,active='true',closed='false')
            if markets:
                self.save_market(markets[0]); tokens.update(json.loads(markets[0]['clobTokenIds'])[:1])
            self.s.health('discovery',True,'public market sentinel collected; not a copied wallet')
        except Exception as ex: self.s.health('discovery',False,ex)
        for token in sorted(tokens):
            try:
                resolution=self.api.get('data','/v2/tokens',token_id=token)
                for item in resolution.get('data',[]):
                    if item.get('token_id')==token and item.get('resolved') is True and item.get('final_price') is not None:
                        self.e.settle(token,item['final_price'],item)
                book=self.api.get('clob','/book',token_id=token)
                if str(book.get('asset_id'))!=token: raise ValueError('book token identity mismatch')
                for side in ('bids','asks'):
                    if not isinstance(book.get(side),list): raise ValueError('invalid order book')
                    for level in book[side]:
                        if not 0<=d(level['price'])<=1 or d(level['size'])<0: raise ValueError('invalid level')
                # Arrival timestamp, never exchange timestamp, controls causal availability.
                with self.s.tx(): self.s.db.execute('INSERT INTO books(token,ts,payload) VALUES(?,?,?)',(token,now(),json.dumps(book)))
                metadata=self.s.one('SELECT * FROM markets WHERE token=?',(token,))
                if not metadata or now()-metadata['updated']>300:
                    mm=self.api.get('gamma','/markets',clob_token_ids=token)
                    for market in mm: self.save_market(market)
                self.s.health('book:'+token,True,'fresh public order book')
            except Exception as ex: self.s.health('book:'+token,False,ex)
    def save_market(self,market):
        schedule=market.get('feeSchedule') or {}
        enabled=market.get('feesEnabled')
        rate='0' if enabled is False else str(schedule['rate']) if 'rate' in schedule else None
        exponent='1' if enabled is False else str(schedule.get('exponent','unknown'))
        with self.s.tx():
            for token in json.loads(market.get('clobTokenIds','[]')):
                self.s.db.execute('INSERT OR REPLACE INTO markets VALUES(?,?,?,?,?,?,?)',(token,market['conditionId'],market['question'],rate,exponent,json.dumps(market),now()))

    @staticmethod
    def source_health(status):
        from datetime import datetime
        try:
            x=status['data'];age=x['age_seconds'];computed=datetime.fromisoformat(x['computed_at'].replace('Z','+00:00')).timestamp()
            if age<0 or age>30 or abs(now()-computed)>60: return False,'stale status snapshot'
            ingestion=x['ingestion'];serving=x['serving']
            if ingestion['cursors']<=0 or str(ingestion.get('network')).lower() not in ('polygon','polygon-mainnet','matic') or ingestion.get('chain_id')!=137: return False,'ingestion progress/chain unverified'
            if ingestion.get('min_synced_block') is None or ingestion.get('max_synced_block') is None or ingestion['min_synced_block']>ingestion['max_synced_block']:return False,'missing/inconsistent ingestion bounds'
            if any(r.get('behind_max',1)>0 for r in ingestion.get('lagging',[])):return False,'ingestion streams behind'
            if serving.get('lag_seconds') is None or serving['lag_seconds']>30:return False,'stale serving projection'
            mechanisms={v['name']:v for v in serving['mechanisms']}
            if not {'activity_feed','custody_balances','pnl'}<=set(mechanisms):return False,'missing serving measurements'
            if any(v.get('age_seconds',31)>30 or v.get('blocks_behind') is None or v['blocks_behind']!=0 for v in mechanisms.values()):return False,'serving progress unverified'
            return True,'freshness checked; NOT proof of atomic completeness'
        except (KeyError,TypeError,ValueError):return False,'missing source freshness evidence'
    def baseline(self,w,status=None):
        integrity=Integrity(self.s);batches=[]
        # No timestamp-based source watermark. Restart walks from original monitoring
        # start to capture late rows; no completeness inferred even after full walk.
        start=max(1,int(w['added'])-1);end=int(now())
        specs=[('/v2/positions',dict(user=w['address'],limit=500,filter_type='TOKENS',filter_amount='0',include_archived='true')),
               ('/v2/trades',dict(user=w['address'],start=start,end=end,limit=500,taker_only='false')),
               ('/v2/activity',dict(user=w['address'],start=start,end=end,limit=500,sort_direction='ASC',exclude_deposits_withdrawals='false')),
               ('/v2/positions',dict(user=w['address'],status='CLOSED',limit=500))]
        for endpoint,params in specs:batches.append(integrity.collect(self.api,w['address'],endpoint,params))
        return integrity.baseline(w['address'],batches,status)
