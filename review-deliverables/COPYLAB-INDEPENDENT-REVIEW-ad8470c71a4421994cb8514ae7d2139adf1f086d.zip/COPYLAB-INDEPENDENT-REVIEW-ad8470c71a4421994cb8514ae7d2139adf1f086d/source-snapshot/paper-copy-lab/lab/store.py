import sqlite3, json, time, threading
from contextlib import contextmanager
from decimal import Decimal, ROUND_HALF_EVEN
from pathlib import Path
D = Decimal
Q = D('0.00000001')
def dec(v):
    x = D(str(v))
    if not x.is_finite(): raise ValueError('non-finite number')
    return x

def money(v): return str(dec(v).quantize(Q, rounding=ROUND_HALF_EVEN))
def now(): return time.time()

SCHEMA = '''
CREATE TABLE IF NOT EXISTS migrations(version INTEGER PRIMARY KEY, applied REAL);
CREATE TABLE IF NOT EXISTS wallets(address TEXT PRIMARY KEY,label TEXT,enabled INTEGER,removed INTEGER DEFAULT 0,added REAL,last_poll REAL,status TEXT,cursor_time INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY,ts REAL,action TEXT,payload TEXT);
CREATE TABLE IF NOT EXISTS events(id TEXT PRIMARY KEY,wallet TEXT,token TEXT,market TEXT,side TEXT,qty TEXT,price TEXT,ts REAL,detected REAL,payload TEXT,status TEXT DEFAULT 'new');
CREATE TABLE IF NOT EXISTS source_positions(wallet TEXT,token TEXT,qty TEXT,PRIMARY KEY(wallet,token));
CREATE TABLE IF NOT EXISTS books(id INTEGER PRIMARY KEY,token TEXT,ts REAL,payload TEXT,UNIQUE(token,ts));
CREATE TABLE IF NOT EXISTS markets(token TEXT PRIMARY KEY,market TEXT,title TEXT,fee_rate TEXT,fee_exponent TEXT,payload TEXT,updated REAL);
CREATE TABLE IF NOT EXISTS decisions(id INTEGER PRIMARY KEY,event TEXT,model TEXT,track TEXT,ts REAL,reason TEXT,qty TEXT,UNIQUE(event,model,track));
CREATE TABLE IF NOT EXISTS orders(id INTEGER PRIMARY KEY,event TEXT,model TEXT,track TEXT,wallet TEXT,token TEXT,market TEXT,side TEXT,qty TEXT,reference TEXT,due REAL,status TEXT,reason TEXT,UNIQUE(event,model,track));
CREATE TABLE IF NOT EXISTS fills(id INTEGER PRIMARY KEY,order_id INTEGER,ts REAL,qty TEXT,price TEXT,fee TEXT,slippage TEXT,realized TEXT);
CREATE TABLE IF NOT EXISTS ledger(id INTEGER PRIMARY KEY,model TEXT,track TEXT,fill_id INTEGER UNIQUE,ts REAL,cash_delta TEXT,cost_delta TEXT,realized TEXT,fee TEXT);
CREATE TABLE IF NOT EXISTS positions(model TEXT,track TEXT,wallet TEXT,token TEXT,market TEXT,qty TEXT,cost TEXT,PRIMARY KEY(model,track,wallet,token));
CREATE TABLE IF NOT EXISTS closed_positions(id INTEGER PRIMARY KEY,model TEXT,track TEXT,wallet TEXT,token TEXT,market TEXT,closing_fill INTEGER UNIQUE,opened REAL,closed REAL,cost TEXT,proceeds TEXT,realized TEXT);
CREATE TABLE IF NOT EXISTS snapshots(id INTEGER PRIMARY KEY,model TEXT,track TEXT,ts REAL,equity TEXT,metrics TEXT);
CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY,value TEXT);
CREATE TABLE IF NOT EXISTS health(component TEXT PRIMARY KEY,ts REAL,ok INTEGER,detail TEXT);
CREATE INDEX IF NOT EXISTS ix_events ON events(status,ts);
CREATE INDEX IF NOT EXISTS ix_books ON books(token,ts);
CREATE INDEX IF NOT EXISTS ix_ledger ON ledger(model,track);
'''
class Store:
    def __init__(self,path='data/lab.sqlite',config=None,synthetic=False):
        Path(path).parent.mkdir(parents=True,exist_ok=True)
        self.path=path; self.lock=threading.RLock()
        self.db=sqlite3.connect(path,check_same_thread=False,isolation_level=None)
        self.db.row_factory=sqlite3.Row
        existing=self.db.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()
        if existing:
            version=self.db.execute('SELECT MAX(version) FROM migrations').fetchone()[0]
            if version!=3:
                self.db.close()
                raise ValueError('Explicit backed-up migration 3 required; runtime database not modified')
            kind=self.db.execute('SELECT kind FROM source_environment WHERE id=1').fetchone()[0]
            if synthetic and kind!='synthetic':
                self.db.close(); raise ValueError('Cannot convert production database to synthetic')
        self.synthetic=synthetic if not existing else kind=='synthetic'
        self.db.execute('PRAGMA journal_mode=WAL'); self.db.execute('PRAGMA synchronous=FULL')
        self.db.execute('PRAGMA busy_timeout=5000'); self.db.executescript(SCHEMA)
        self.db.execute('INSERT OR IGNORE INTO migrations VALUES(1,?)',(now(),))
        self.db.execute('INSERT OR IGNORE INTO migrations VALUES(2,?)',(now(),))
        if not existing:
            from .migrations import apply_new
            with self.tx(): apply_new(self.db,synthetic)
        if config is not None:
            old=self.one("SELECT value FROM settings WHERE key='config'")
            if old and json.loads(old['value']) != config:
                self.db.close()
                raise ValueError('Configuration differs from persisted run; explicit migration required')
            self.db.execute('INSERT OR IGNORE INTO settings VALUES(?,?)',('config',json.dumps(config,sort_keys=True)))
    @contextmanager
    def tx(self):
        with self.lock:
            self.db.execute('BEGIN IMMEDIATE')
            try: yield self.db; self.db.execute('COMMIT')
            except BaseException: self.db.execute('ROLLBACK'); raise
    def rows(self,sql,args=()):
        with self.lock: return [dict(r) for r in self.db.execute(sql,args)]
    def one(self,sql,args=()):
        a=self.rows(sql,args); return a[0] if a else None
    def audit(self,action,payload): self.db.execute('INSERT INTO audit(ts,action,payload) VALUES(?,?,?)',(now(),action,json.dumps(payload)))
    def health(self,component,ok,detail):
        with self.lock: self.db.execute('INSERT OR REPLACE INTO health VALUES(?,?,?,?)',(component,now(),int(ok),str(detail)[:1000]))
    def backup(self,path):
        with self.lock:
            dest=sqlite3.connect(path)
            try: self.db.backup(dest)
            finally: dest.close()
