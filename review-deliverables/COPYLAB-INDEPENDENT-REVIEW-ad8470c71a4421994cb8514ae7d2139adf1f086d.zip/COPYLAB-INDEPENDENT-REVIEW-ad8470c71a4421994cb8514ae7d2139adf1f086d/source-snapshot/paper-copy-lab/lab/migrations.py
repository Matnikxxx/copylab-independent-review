"""Additive source-integrity schema. Existing databases require explicit migration."""
import sqlite3,json,hashlib,time
from pathlib import Path
V3='''
CREATE TABLE execution_context(fill_id INTEGER PRIMARY KEY,book_id INTEGER,reference TEXT,arrival REAL,spread TEXT,depth TEXT,evidence TEXT);
CREATE TABLE source_environment(id INTEGER PRIMARY KEY CHECK(id=1),kind TEXT NOT NULL);
CREATE TABLE collection_batches(id INTEGER PRIMARY KEY,wallet TEXT,endpoint TEXT,params TEXT,started REAL,finished REAL,status TEXT NOT NULL,next_cursor TEXT,page_number INTEGER DEFAULT 0,error TEXT,coverage TEXT NOT NULL DEFAULT 'unproven');
CREATE TABLE collection_pages(id INTEGER PRIMARY KEY,batch INTEGER NOT NULL,page_number INTEGER NOT NULL,cursor_in TEXT,cursor_out TEXT,received REAL,raw TEXT NOT NULL,UNIQUE(batch,page_number));
CREATE TABLE transport_deliveries(id INTEGER PRIMARY KEY,batch INTEGER,page_number INTEGER,received REAL,raw TEXT NOT NULL,disposition TEXT);
CREATE TABLE source_observations(id INTEGER PRIMARY KEY,page INTEGER,ordinal INTEGER,wallet TEXT,endpoint TEXT,received REAL,payload TEXT NOT NULL,economic_key TEXT,state TEXT NOT NULL,reason TEXT,UNIQUE(page,ordinal));
CREATE TABLE observation_flags(id INTEGER PRIMARY KEY,observation INTEGER,flag TEXT,group_key TEXT,detail TEXT,UNIQUE(observation,flag,group_key));
CREATE TABLE capture_frontiers(wallet TEXT,endpoint TEXT,batch INTEGER,captured_at REAL,coverage TEXT NOT NULL,PRIMARY KEY(wallet,endpoint));
CREATE TABLE baseline_evidence(id INTEGER PRIMARY KEY,wallet TEXT,created REAL,state TEXT,confidence TEXT,evidence TEXT,limitations TEXT,boundary TEXT);
CREATE TABLE source_states(wallet TEXT PRIMARY KEY,state TEXT,reason TEXT,baseline INTEGER,last_event INTEGER,last_order INTEGER,health_at REAL,last_complete_batch INTEGER,checkpoint TEXT);
CREATE TABLE verified_events(id INTEGER PRIMARY KEY,wallet TEXT,identity TEXT,kind TEXT,provenance TEXT NOT NULL,ordering INTEGER,canonical_payload TEXT NOT NULL,observation INTEGER,state TEXT,reason TEXT,UNIQUE(wallet,identity));
CREATE TABLE event_links(event INTEGER,observation INTEGER,relation TEXT,PRIMARY KEY(event,observation));
CREATE TABLE copy_event_links(event_id TEXT PRIMARY KEY,verified_event INTEGER NOT NULL);
CREATE TABLE source_inventory(wallet TEXT,token TEXT,qty TEXT,cost TEXT,PRIMARY KEY(wallet,token));
CREATE TABLE source_movements(id INTEGER PRIMARY KEY,event INTEGER,wallet TEXT,token TEXT,delta TEXT,cost_delta TEXT,cash TEXT,realized TEXT,leg_identity TEXT,UNIQUE(wallet,leg_identity));
CREATE TABLE source_effects(wallet TEXT,effect_identity TEXT,event INTEGER,PRIMARY KEY(wallet,effect_identity));
CREATE TABLE monitoring_history(id INTEGER PRIMARY KEY,wallet TEXT,ts REAL,action TEXT,detail TEXT);
CREATE TABLE monitoring_gaps(id INTEGER PRIMARY KEY,wallet TEXT,opened REAL,closed REAL,reason TEXT,last_batch INTEGER,state TEXT);
CREATE TABLE reconciliation_records(id INTEGER PRIMARY KEY,wallet TEXT,created REAL,state TEXT,source TEXT,paper TEXT,evidence TEXT,reason TEXT);
CREATE TABLE paper_holds(model TEXT,track TEXT,wallet TEXT,token TEXT,reason TEXT,reconciliation INTEGER,PRIMARY KEY(model,track,wallet,token));
'''
def apply_new(db,synthetic=False):
    for statement in V3.split(';'):
        if statement.strip():db.execute(statement)
    db.execute('INSERT INTO source_environment VALUES(1,?)',('synthetic' if synthetic else 'production',))
    db.execute('INSERT INTO migrations VALUES(3,?)',(time.time(),))

def table_digests(db,tables):
    result={}
    for table in tables:
        # Names obtained only from sqlite_master, not external input.
        rows=db.execute('SELECT * FROM "'+table.replace('"','""')+'"').fetchall()
        encoded=sorted(json.dumps(list(r),default=str,separators=(',',':')) for r in rows)
        result[table]=hashlib.sha256('\n'.join(encoded).encode()).hexdigest()
    return result

def upgrade_existing(path,backup):
    import fcntl
    if not Path(path).is_file():raise ValueError('existing database required')
    lock=open(str(path)+'.worker.lock','a')
    fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    if Path(backup).exists():raise ValueError('backup destination must be new')
    db=sqlite3.connect(str(path),isolation_level=None)
    try:
        if db.execute('PRAGMA integrity_check').fetchone()[0]!='ok':raise ValueError('source integrity failed')
        if db.execute('SELECT MAX(version) FROM migrations').fetchone()[0]!=2:raise ValueError('requires legacy version 2')
        tables=[r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table' AND name!='migrations'")]
        before=table_digests(db,tables)
        dest=sqlite3.connect(str(backup))
        try:
            db.backup(dest)
            if dest.execute('PRAGMA integrity_check').fetchone()[0]!='ok' or table_digests(dest,tables)!=before:raise ValueError('backup verification failed')
        finally:dest.close()
        db.execute('BEGIN IMMEDIATE')
        try:
            if table_digests(db,tables)!=before:raise ValueError('database changed since backup')
            apply_new(db)
            wallets=db.execute('SELECT address FROM wallets UNION SELECT wallet FROM positions UNION SELECT wallet FROM orders').fetchall()
            for (wallet,) in wallets:
                reason='legacy baseline/checkpoint and monitoring continuity unverified'
                db.execute('INSERT INTO source_states(wallet,state,reason) VALUES(?,?,?)',(wallet,'quarantined',reason))
                db.execute('INSERT INTO monitoring_gaps(wallet,opened,reason,state) VALUES(?,?,?,?)',(wallet,time.time(),reason,'unreconciled'))
                paper=[list(x) for x in db.execute('SELECT * FROM positions WHERE wallet=? AND CAST(qty AS REAL)>0',(wallet,))]
                rid=db.execute('INSERT INTO reconciliation_records(wallet,created,state,source,paper,evidence,reason) VALUES(?,?,?,?,?,?,?)',(wallet,time.time(),'operator_review','[]',json.dumps(paper),json.dumps({'migration':3}),reason)).lastrowid
                for model,track,_,token,*_ in paper:db.execute('INSERT INTO paper_holds VALUES(?,?,?,?,?,?)',(model,track,wallet,token,reason,rid))
            if table_digests(db,tables)!=before:raise ValueError('legacy rows changed')
            db.execute('COMMIT')
        except BaseException:db.execute('ROLLBACK');raise
        return {'migration':3,'backup_verified':True,'legacy_table_digests':before,'legacy_rows_preserved':True}
    finally:db.close();lock.close()
