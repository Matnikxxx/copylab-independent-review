"""Evidence-first capture and fail-closed admission. No production canonical adapter.
Internal integer IDs/order are local records, NEVER blockchain identities.
"""
import json,hashlib
from .store import now,dec as d,money as m

def dump(v):return json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False)
def raw_dump(v):return json.dumps(v,sort_keys=True,separators=(',',':'))

def economic_key(row):
    def number(v):return format(d(v).normalize(),'f')
    return dump([row.get('proxy_wallet'),row.get('transaction_hash'),row.get('token_id'),row.get('side'),number(row.get('size',0)),number(row.get('price',0)),row.get('timestamp')])

class Integrity:
    def __init__(self,s):self.s=s
    def hold(self,wallet,reason):
        # Caller may already own transaction; mutation helpers do not nest tx.
        self.s.db.execute('INSERT INTO source_states(wallet,state,reason) VALUES(?,?,?) ON CONFLICT(wallet) DO UPDATE SET state=excluded.state,reason=excluded.reason',(wallet,'quarantined',reason))
        paper=self.s.rows('SELECT * FROM positions WHERE wallet=? AND CAST(qty AS REAL)>0',(wallet,))
        source=self.s.rows('SELECT * FROM source_inventory WHERE wallet=?',(wallet,))
        source_by_token={p['token']:p['qty'] for p in source}
        comparison=[{'model':p['model'],'track':p['track'],'token':p['token'],'paper_qty':p['qty'],'source_qty':source_by_token.get(p['token']),'difference':str(d(p['qty'])-d(source_by_token[p['token']])) if p['token'] in source_by_token else None,'interpretation':'raw quantity difference, NOT expected proportional-copy target; unknown is not zero'} for p in paper]
        rid=self.s.db.execute('INSERT INTO reconciliation_records(wallet,created,state,source,paper,evidence,reason) VALUES(?,?,?,?,?,?,?)',(wallet,now(),'operator_review',dump(source),dump(paper),dump({'comparison':comparison,'source_checkpoint_verified':False,'recovery_requires':'canonical source history and separate paper review; no historical fills'}),reason)).lastrowid
        for p in paper:
            self.s.db.execute('INSERT OR REPLACE INTO paper_holds VALUES(?,?,?,?,?,?)',(p['model'],p['track'],wallet,p['token'],reason,rid))
        self.s.db.execute('UPDATE wallets SET status=? WHERE address=?',('quarantined: '+reason,wallet))
        self.s.db.execute("UPDATE orders SET status='cancelled',reason=? WHERE wallet=? AND status='pending'",('source integrity: '+reason,wallet))
        return rid
    def allowed(self,wallet):
        state=self.s.one('SELECT * FROM source_states WHERE wallet=?',(wallet,))
        if self.s.synthetic:
            # Explicit synthetic DB fixtures exercise downstream algorithms only.
            return (not state or state['state']=='verified') and bool(self.s.one('SELECT value FROM settings WHERE key=?',('inventory:'+wallet,)))
        # No audited real canonical-checkpoint adapter yet. Nothing can arm this.
        return False
    def gap(self,wallet,reason):
        state=self.s.one('SELECT * FROM source_states WHERE wallet=?',(wallet,))
        if not self.s.one("SELECT id FROM monitoring_gaps WHERE wallet=? AND closed IS NULL",(wallet,)):
            self.s.db.execute('INSERT INTO monitoring_gaps(wallet,opened,reason,last_batch,state) VALUES(?,?,?,?,?)',(wallet,now(),reason,state['last_complete_batch'] if state else None,'unreconciled'))
        self.s.db.execute('INSERT INTO monitoring_history(wallet,ts,action,detail) VALUES(?,?,?,?)',(wallet,now(),'gap',reason))
        return self.hold(wallet,reason)
    def observe(self,wallet,endpoint,row):
        # Legacy/direct ingress still preserves the observation, never creates trade events.
        try:key=economic_key(row)
        except Exception:key=None
        with self.s.tx():
            oid=self.s.db.execute('INSERT INTO source_observations(wallet,endpoint,received,payload,economic_key,state,reason) VALUES(?,?,?,?,?,?,?)',(wallet,endpoint,now(),raw_dump(row),key,'quarantined','ordinary row has no authoritative identity')).lastrowid
            self.tag(oid)
            self.hold(wallet,'unverified direct source observation')
        return oid
    def tag(self,oid):
        current=self.s.one('SELECT * FROM source_observations WHERE id=?',(oid,))
        if current['economic_key']:
            group=self.s.rows('SELECT id FROM source_observations WHERE wallet=? AND economic_key=?',(current['wallet'],current['economic_key']))
            if len(group)>1:
                for item in group:self.s.db.execute('INSERT OR IGNORE INTO observation_flags(observation,flag,group_key,detail) VALUES(?,?,?,?)',(item['id'],'identical_economics',current['economic_key'],'multiplicity versus replay unresolved; not deduplicated'))
        row=json.loads(current['payload'])
        if row.get('side') not in ('BUY','SELL'):return
        group=[]
        for item in self.s.rows('SELECT id,payload FROM source_observations WHERE wallet=?',(current['wallet'],)):
            other=json.loads(item['payload'])
            if other.get('timestamp')==row.get('timestamp') and other.get('side') in ('BUY','SELL'):group.append((item,other))
        if len({v.get('side') for _,v in group})>1:
            for item,_ in group:self.s.db.execute('INSERT OR IGNORE INTO observation_flags(observation,flag,group_key,detail) VALUES(?,?,?,?)',(item['id'],'same_timestamp_opposing',str(row.get('timestamp')),'provider order retained; no canonical execution ordering'))
    def collect(self,api,wallet,endpoint,params):
        """Resume durable batches. Request filters and window never change mid-walk.
        Each HTTP attempt is kept; complete capture is not source completeness.
        """
        batch=self.s.one("SELECT * FROM collection_batches WHERE wallet=? AND endpoint=? AND status IN ('incomplete','collecting') ORDER BY id LIMIT 1",(wallet,endpoint))
        if batch:
            bid=batch['id'];params=json.loads(batch['params']);cursor=batch['next_cursor'];page_no=batch['page_number']
        else:
            with self.s.tx():
                bid=self.s.db.execute('INSERT INTO collection_batches(wallet,endpoint,params,started,status) VALUES(?,?,?,?,?)',(wallet,endpoint,dump(params),now(),'collecting')).lastrowid
            cursor=None;page_no=0
        try:
            for _ in range(1000):
                if hasattr(api,'last_raw'):api.last_raw=None
                if hasattr(api,'attempt_log'):api.attempt_log=[]
                response=api.get('data',endpoint,**params,**({'cursor':cursor} if cursor else {}))
                wire=getattr(api,'last_raw',None) or raw_dump(response)
                with self.s.tx():
                    for attempt in getattr(api,'attempt_log',[])[:-1]:
                        self.s.db.execute('INSERT INTO transport_deliveries(batch,page_number,received,raw,disposition) VALUES(?,?,?,?,?)',(bid,page_no,attempt['received'],attempt['body'],'retry HTTP '+attempt['http_code']+': '+attempt['error']))
                with self.s.tx():
                    self.s.db.execute('INSERT INTO transport_deliveries(batch,page_number,received,raw,disposition) VALUES(?,?,?,?,?)',(bid,page_no,now(),wire,'received; validation pending'))
                pagination=response.get('pagination')
                if not isinstance(response.get('data'),list) or not isinstance(pagination,dict) or 'next_cursor' not in pagination or 'has_more' not in pagination:raise ValueError('missing page completion evidence')
                nxt=pagination['next_cursor']
                if bool(nxt)!=bool(pagination['has_more']):raise ValueError('inconsistent terminal page')
                if nxt is not None and (not isinstance(nxt,str) or not nxt):raise ValueError('invalid cursor')
                previous=self.s.rows('SELECT cursor_in FROM collection_pages WHERE batch=?',(bid,))
                if nxt is not None and (nxt==cursor or any(p['cursor_in']==nxt for p in previous)):raise ValueError('repeating cursor')
                with self.s.tx():
                    pid=self.s.db.execute('INSERT INTO collection_pages(batch,page_number,cursor_in,cursor_out,received,raw) VALUES(?,?,?,?,?,?)',(bid,page_no,cursor,nxt,now(),wire)).lastrowid
                    for ordinal,row in enumerate(response['data']):
                        reason='no verified identity/checkpoint; provider order only'
                        try:key=economic_key(row)
                        except Exception:key=None;reason='invalid economic fields; raw preserved'
                        oid=self.s.db.execute('INSERT INTO source_observations(page,ordinal,wallet,endpoint,received,payload,economic_key,state,reason) VALUES(?,?,?,?,?,?,?,?,?)',(pid,ordinal,wallet,endpoint,now(),raw_dump(row),key,'quarantined',reason)).lastrowid
                        self.tag(oid)
                    self.s.db.execute('UPDATE collection_batches SET next_cursor=?,page_number=?,status=?,finished=?,error=NULL WHERE id=?',(nxt,page_no+1,'complete' if nxt is None else 'collecting',now() if nxt is None else None,bid))
                    self.s.db.execute("UPDATE transport_deliveries SET disposition='captured' WHERE batch=? AND page_number=? AND disposition='received; validation pending'",(bid,page_no))
                    if nxt is None:
                        self.s.db.execute('INSERT OR REPLACE INTO capture_frontiers VALUES(?,?,?,?,?)',(wallet,endpoint,bid,now(),'captured pages only; late inserts and source completeness unproven'))
                        self.s.db.execute('INSERT INTO source_states(wallet,state,reason,last_complete_batch) VALUES(?,?,?,?) ON CONFLICT(wallet) DO UPDATE SET last_complete_batch=excluded.last_complete_batch',(wallet,'quarantined','REST checkpoint unverified',bid))
                    self.hold(wallet,'REST data lacks atomic checkpoint and canonical identity')
                if nxt is None:return bid
                cursor=nxt;page_no+=1
            raise ValueError('pagination cap; incomplete batch')
        except Exception as exc:
            with self.s.tx():
                raw=getattr(api,'last_raw',None)
                if raw is not None:
                    self.s.db.execute('INSERT INTO transport_deliveries(batch,page_number,received,raw,disposition) VALUES(?,?,?,?,?)',(bid,page_no,now(),raw,'failed response/capture; retained for recovery'))
                self.s.db.execute("UPDATE collection_batches SET status='incomplete',error=? WHERE id=?",(str(exc),bid))
                self.gap(wallet,'collection incomplete: '+str(exc))
            raise
    def baseline(self,wallet,batches,status):
        # Persist evidence/limitations. Never infer zero/missing completeness.
        with self.s.tx():
            details={'batches':batches,'status':status,'filters':'positions default OPEN; explicit TOKENS 0 floor request, archived true; inactive coverage still absent','boundary':'no atomic source cut; source timestamps are integer seconds'}
            bid=self.s.db.execute('INSERT INTO baseline_evidence(wallet,created,state,confidence,evidence,limitations,boundary) VALUES(?,?,?,?,?,?,?)',(wallet,now(),'quarantined','unverified',dump(details),'dust/filter/inactive coverage and shared checkpoint unproven','no timestamp-based admission')).lastrowid
            self.hold(wallet,'baseline cannot establish atomic exhaustive inventory')
            self.s.db.execute('UPDATE source_states SET baseline=? WHERE wallet=?',(bid,wallet))
        return bid
    def synthetic_event(self,wallet,identity,kind,payload,order,observation=None):
        """Only explicit disposable fixture DBs. No chain fields manufactured.
        Public callers cannot use this to certify a production event.
        """
        if not self.s.synthetic:raise ValueError('No production evidence verifier/adapter installed')
        text=dump(payload)
        with self.s.tx():
            old=self.s.one('SELECT * FROM verified_events WHERE wallet=? AND identity=?',(wallet,identity))
            if old:
                if old['canonical_payload']!=text or old['kind']!=kind or old['ordering']!=order:
                    self.s.db.execute("UPDATE verified_events SET state='conflict',reason='identity payload conflict' WHERE id=?",(old['id'],))
                    self.hold(wallet,'verified identity conflict; review required')
                    return old['id']
                if observation is not None:self.s.db.execute('INSERT OR IGNORE INTO event_links VALUES(?,?,?)',(old['id'],observation,'repeat evidence'))
                return old['id']
            eid=self.s.db.execute('INSERT INTO verified_events(wallet,identity,kind,provenance,ordering,canonical_payload,observation,state) VALUES(?,?,?,?,?,?,?,?)',(wallet,identity,kind,'synthetic fixture, NOT blockchain evidence',order,text,observation,'verified')).lastrowid
            if observation is not None:self.s.db.execute('INSERT INTO event_links VALUES(?,?,?)',(eid,observation,'fixture assertion'))
        return eid

    def lifecycle(self,eid):
        """Apply evidenced legs once; descriptors cannot double-count transfers.
        Production support blocked until a verified decoder/checkpoint exists.
        """
        e=self.s.one('SELECT * FROM verified_events WHERE id=?',(eid,))
        if not e:raise ValueError('unknown event')
        wallet=e['wallet'];kind=e['kind'];p=json.loads(e['canonical_payload'])
        with self.s.tx():
            if e['state']=='applied':return
            if not self.s.synthetic or e['state']!='verified':self.hold(wallet,'unverified lifecycle');return
            if kind in ('CORRECTION','REVERSAL','REORG','UNKNOWN') or kind not in ('BUY','SELL','SPLIT','MERGE','REDEEM','RESOLUTION','CONVERSION','NEG_RISK','COMBO','TRANSFER'):
                self.s.db.execute("UPDATE verified_events SET state='quarantined',reason='unsupported correction or lifecycle' WHERE id=?",(eid,));self.hold(wallet,'unsupported lifecycle: '+kind);return
            state=self.s.one('SELECT * FROM source_states WHERE wallet=?',(wallet,))
            if state and state['last_order'] is not None and (e['ordering'] is None or e['ordering']<=state['last_order']):
                self.s.db.execute("UPDATE verified_events SET state='quarantined',reason='non-monotonic verified source order' WHERE id=?",(eid,));self.hold(wallet,'verified source order regression');return
            legs=p.get('legs',[]);effects=p.get('effects',[])
            if not legs or not effects or any(not x.get('identity') for x in legs):
                self.s.db.execute("UPDATE verified_events SET state='quarantined',reason='missing evidenced legs/effects' WHERE id=?",(eid,));self.hold(wallet,'missing lifecycle reconstruction evidence');return
            if any(self.s.one('SELECT event FROM source_effects WHERE wallet=? AND effect_identity=?',(wallet,x)) for x in effects):
                self.s.db.execute("UPDATE verified_events SET state='quarantined',reason='overlapping effects already applied' WHERE id=?",(eid,));self.hold(wallet,'transfer/lifecycle overlap or repeated payout');return
            staged=[]
            try:
                seen=set()
                for leg in legs:
                    token=leg['token'];delta=d(leg['delta']);cash=d(leg['cash'])
                    if token in seen:raise ValueError('aggregate repeated token legs with explicit provenance first')
                    seen.add(token)
                    if self.s.one('SELECT id FROM source_movements WHERE wallet=? AND leg_identity=?',(wallet,leg['identity'])):raise ValueError('transfer leg already accounted')
                    old=self.s.one('SELECT * FROM source_inventory WHERE wallet=? AND token=?',(wallet,token));q=d(old['qty']) if old else d(0);cost=d(old['cost']) if old else d(0)
                    if q+delta<0:raise ValueError('source oversell or missing inventory')
                    if delta>0:
                        # Incoming basis cannot be inferred from a market quote.
                        added=d(leg['basis']);cd=added;r=d(0)
                        if added<0:raise ValueError('negative basis')
                    elif delta<0:
                        removed=cost if -delta==q else cost*(-delta)/q;cd=-removed;r=cash-removed
                    else:cd=d(0);r=cash
                    if kind=='BUY' and (delta<=0 or cash!=-cd):raise ValueError('invalid buy legs')
                    if kind=='SELL' and (delta>=0 or cash<0):raise ValueError('invalid sell legs')
                    if kind=='RESOLUTION' and (delta!=0 or cash!=0):raise ValueError('resolution alone cannot redeem or change inventory')
                    staged.append((leg,delta,cash,q+delta,cost+cd,cd,r))
            except (ValueError,KeyError,ArithmeticError) as exc:
                self.s.db.execute("UPDATE verified_events SET state='quarantined',reason=? WHERE id=?",(str(exc),eid));self.hold(wallet,str(exc));return
            # Pure conversions preserve cost basis, not fictitious realized losses.
            deltas=[x[1] for x in staged]
            transform=kind in ('CONVERSION','NEG_RISK') or (kind=='COMBO' and any(x<0 for x in deltas) and any(x>0 for x in deltas))
            invalid=None
            if kind=='SPLIT' and (not all(x>0 for x in deltas) or sum(x[2] for x in staged)!=-sum(x[5] for x in staged)):invalid='split requires fully evidenced paid basis'
            if kind in ('MERGE','REDEEM') and not all(x<0 for x in deltas):invalid='merge/redemption requires burn/debit legs'
            if kind=='TRANSFER' and any(x[2]!=0 for x in staged):invalid='transfer cannot fabricate trading proceeds'
            if transform:
                if not (any(x<0 for x in deltas) and any(x>0 for x in deltas)) or any(x[2]!=0 for x in staged) or sum(x[5] for x in staged)!=0:invalid='unsupported conversion cash/basis allocation; verified decoder required'
            if invalid:
                self.s.db.execute("UPDATE verified_events SET state='quarantined',reason=? WHERE id=?",(invalid,eid));self.hold(wallet,invalid);return
            for leg,delta,cash,nq,nc,cd,r in staged:
                if transform or kind=='TRANSFER':r=d(0)
                self.s.db.execute('INSERT OR REPLACE INTO source_inventory VALUES(?,?,?,?)',(wallet,leg['token'],m(nq),m(nc)))
                self.s.db.execute('INSERT INTO source_movements(event,wallet,token,delta,cost_delta,cash,realized,leg_identity) VALUES(?,?,?,?,?,?,?,?)',(eid,wallet,leg['token'],m(delta),m(cd),m(cash),m(r),leg['identity']))
            for effect in effects:self.s.db.execute('INSERT INTO source_effects VALUES(?,?,?)',(wallet,effect,eid))
            self.s.db.execute("UPDATE verified_events SET state='applied' WHERE id=?",(eid,))
            self.s.db.execute('UPDATE source_states SET last_event=?,last_order=? WHERE wallet=?',(eid,e['ordering'],wallet))
