"""Independent entry rules. All inputs are observations available at decision time."""
from .store import dec as d
class Baseline:
    def entry(self,e,c): return True,'baseline proportional entry',d(1)
class Selective:
    def entry(self,e,c):
        cfg=c['cfg']; wins=c['wallet_wins']; closes=c['wallet_closes']
        if closes<cfg['minimum_wallet_closes']: return False,'insufficient observed wallet closes',d(0)
        if d(wins)/d(closes)<d(cfg['minimum_wallet_winrate']): return False,'wallet win rate',d(0)
        if c['spread']>d(cfg['max_spread']): return False,'selective spread',d(0)
        if d(e['price'])>d('0.85') or c['ask']>d(e['price'])+d('0.01'): return False,'selective expensive entry',d(0)
        return True,'qualified wallet and tight entry',d('0.8')
class Momentum:
    def entry(self,e,c):
        cfg=c['cfg']; h=c['history']
        if c['activity_count']<cfg['minimum_trade_events']: return False,'insufficient observed trade activity',d(0)
        if len(h)<cfg['minimum_samples']: return False,'momentum confirmation unavailable',d(0)
        move=h[-1]-h[0]
        if not d(cfg['minimum_momentum'])<=move<=d(cfg['maximum_momentum']): return False,'momentum absent or chase risk',d(0)
        if not all(a<=b for a,b in zip(h[-3:],h[-2:])): return False,'momentum not confirmed',d(0)
        return True,'bounded positive momentum',d(1)
class Value:
    def entry(self,e,c):
        cfg=c['cfg']
        if c['ask']>d(cfg['maximum_price']): return False,'value absolute price cap',d(0)
        if c['ask']>d(e['price'])-d(cfg['minimum_discount']): return False,'no discount to source entry',d(0)
        return True,'discounted observed entry',d('1.1')
class RiskAdjusted:
    def entry(self,e,c):
        reliability=(d(c['wallet_wins'])+1)/(d(c['wallet_closes'])+2)
        remaining=max(d(0),1-c['drawdown']/d(c['cfg']['max_drawdown']))
        concentration=max(d('0.1'),1-c['wallet_exposure']/d(c['cfg']['max_wallet_exposure']))
        scale=reliability*remaining*concentration
        return scale>d('0.05'),'reliability × drawdown × concentration sizing',scale
STRATEGIES=dict(zip('ABCDE',[Baseline(),Selective(),Momentum(),Value(),RiskAdjusted()]))
