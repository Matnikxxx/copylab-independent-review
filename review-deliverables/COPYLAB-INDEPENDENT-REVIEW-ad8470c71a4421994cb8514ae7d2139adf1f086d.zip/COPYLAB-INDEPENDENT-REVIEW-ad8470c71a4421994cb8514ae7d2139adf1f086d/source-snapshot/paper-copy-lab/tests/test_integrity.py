"""Controlled SYNTHETIC evidence only. Labels/ordinals are not chain facts.
Uses the pre-existing test wallet fixture; no production wallet collection.
"""
import unittest,tempfile,json,sqlite3,hashlib,subprocess,sys
from pathlib import Path
from unittest.mock import patch
from lab.store import Store,SCHEMA,now,dec as d
from lab.integrity import Integrity,economic_key
from lab.public import Collector
from lab.engine import Engine
from lab.wallets import Wallets
from lab.migrations import upgrade_existing,table_digests
from test_lab import W

def page(rows,nxt=None):return {'data':rows,'pagination':{'next_cursor':nxt,'has_more':nxt is not None}}
def row(side='BUY',size='10',price='.5',token='T',timestamp=None):
 return {'proxy_wallet':W,'transaction_hash':'tx','side':side,'size':size,'price':price,'token_id':token,'condition_id':'M','timestamp':now() if timestamp is None else timestamp}
class API:
 def __init__(self,*answers):self.answers=list(answers);self.calls=[]
 def get(self,service,endpoint,**kw):
  self.calls.append((endpoint,kw));answer=self.answers.pop(0)
  if isinstance(answer,Exception):raise answer
  return answer

class IntegrityTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.path=self.tmp.name+'/fixture.sqlite';self.c=json.loads(Path('config.json').read_text());self.s=Store(self.path,self.c,synthetic=True);self.i=Integrity(self.s);Wallets(self.s).change(W,'add')
 def tearDown(self):self.s.db.close();self.tmp.cleanup()
 def collect(self,*answers):return self.i.collect(API(*answers),W,'/v2/trades',{'user':W,'start':1})
 def cert(self,key,kind,legs,effects=None):
  p={'legs':legs,'effects':effects or [key]};old=self.s.one('SELECT ordering FROM verified_events WHERE wallet=? AND identity=?',(W,key));ordinal=old['ordering'] if old else self.s.one('SELECT COUNT(*) n FROM verified_events')['n'];eid=self.i.synthetic_event(W,key,kind,p,ordinal);self.i.lifecycle(eid);return eid
 def incoming(self,key='incoming',token='T',qty='10',basis='5'):
  return self.cert(key,'BUY',[{'identity':key+'/leg','token':token,'delta':qty,'basis':basis,'cash':'-'+basis}])
 def test_failure_before_response_has_no_frontier(self):
  with self.assertRaises(RuntimeError):self.collect(RuntimeError('fixture I/O failure'))
  self.assertEqual(self.s.one('SELECT COUNT(*) n FROM source_observations')['n'],0);self.assertIsNone(self.s.one('SELECT * FROM capture_frontiers'))
 def test_partial_page_then_failure_retains_rows_and_cursor(self):
  with self.assertRaises(RuntimeError):self.collect(page([row()], 'fixture-cursor'),RuntimeError('interrupted'))
  b=self.s.one('SELECT * FROM collection_batches');self.assertEqual(b['status'],'incomplete');self.assertEqual(b['next_cursor'],'fixture-cursor');self.assertEqual(self.s.one('SELECT COUNT(*) n FROM source_observations')['n'],1);self.assertIsNone(self.s.one('SELECT * FROM capture_frontiers'))
 def test_resume_after_restart_same_batch_no_loss(self):
  with self.assertRaises(RuntimeError):self.collect(page([row()], 'fixture-cursor'),RuntimeError('interrupted'))
  self.s.db.close();self.s=Store(self.path,self.c);self.i=Integrity(self.s)
  api=API(page([row(token='OTHER')]));bid=self.i.collect(api,W,'/v2/trades',{'user':W,'start':999})
  self.assertEqual(api.calls[0][1]['cursor'],'fixture-cursor');self.assertEqual(api.calls[0][1]['start'],1);self.assertEqual(self.s.one('SELECT COUNT(*) n FROM source_observations')['n'],2);self.assertEqual(self.s.one('SELECT batch FROM capture_frontiers')['batch'],bid)
 def test_failure_inside_page_transaction_rolls_back_without_frontier(self):
  self.s.db.execute("CREATE TRIGGER fixture_failure BEFORE INSERT ON source_observations BEGIN SELECT RAISE(ABORT,'fixture write failure'); END")
  with self.assertRaises(sqlite3.IntegrityError):self.collect(page([row()]))
  self.assertIsNone(self.s.one('SELECT * FROM collection_pages'));self.assertIsNone(self.s.one('SELECT * FROM capture_frontiers'));self.assertEqual(self.s.one('SELECT COUNT(*) n FROM transport_deliveries')['n'],1)
 def test_retry_after_write_failure_preserves_attempts(self):
  self.s.db.execute("CREATE TRIGGER fixture_failure BEFORE INSERT ON source_observations BEGIN SELECT RAISE(ABORT,'fixture'); END")
  with self.assertRaises(sqlite3.IntegrityError):self.collect(page([row()]))
  self.s.db.execute('DROP TRIGGER fixture_failure');self.collect(page([row()]));self.assertEqual(self.s.one('SELECT COUNT(*) n FROM transport_deliveries')['n'],2);self.assertEqual(self.s.one('SELECT COUNT(*) n FROM source_observations')['n'],1)
 def test_missing_pagination_is_incomplete_not_zero(self):
  with self.assertRaises(ValueError):self.collect({'data':[]})
  self.assertIsNone(self.s.one('SELECT * FROM capture_frontiers'))
 def test_repeat_cursor_keeps_frontier_uncommitted(self):
  with self.assertRaises(ValueError):self.collect(page([row()],'fixture-cursor'),page([],'fixture-cursor'))
  self.assertIsNone(self.s.one('SELECT * FROM capture_frontiers'))
 def test_late_behind_traversed_cursor_never_certifies_coverage(self):
  self.collect(page([row(timestamp=now()-10)],'fixture-cursor'),page([]))
  self.collect(page([row(timestamp=now()-20)]));self.assertEqual(self.s.one('SELECT COUNT(*) n FROM source_observations')['n'],2);self.assertFalse(self.i.allowed(W));self.assertIn('unproven',self.s.one('SELECT coverage FROM capture_frontiers')['coverage'])
 def test_identical_legitimate_rows_preserve_multiplicity(self):
  r=row();self.collect(page([r,r]));self.assertEqual(self.s.one('SELECT COUNT(*) n FROM source_observations')['n'],2);self.assertEqual(self.s.one('SELECT COUNT(*) n FROM events')['n'],0)
 def test_cursor_restart_overlap_preserves_observations(self):
  r=row();self.collect(page([r]));self.collect(page([r]));self.assertEqual(self.s.one('SELECT COUNT(*) n FROM source_observations')['n'],2)
 def test_provider_order_and_ordinal_preserved(self):
  a=row('SELL');b=row('BUY');self.collect(page([a,b]));obs=self.s.rows('SELECT * FROM source_observations ORDER BY ordinal');self.assertEqual([json.loads(o['payload'])['side'] for o in obs],['SELL','BUY']);self.assertEqual([o['ordinal'] for o in obs],[0,1])
 def test_numeric_key_normalization_does_not_deduplicate(self):
  a=row(size='10',price='.50',timestamp=now());b={**a,'size':'10.0','price':'0.5'};self.assertEqual(economic_key(a),economic_key(b));self.collect(page([a,b]));self.assertEqual(self.s.one('SELECT COUNT(*) n FROM source_observations')['n'],2)
 def test_same_transaction_different_tokens_not_collapsed(self):
  self.collect(page([row(token='T'),row(token='OTHER')]));self.assertEqual(self.s.one('SELECT COUNT(*) n FROM source_observations')['n'],2)
 def test_same_second_buy_sell_quarantined(self):
  t=now();self.collect(page([row('BUY',timestamp=t),row('SELL',timestamp=t)]));self.assertFalse(self.i.allowed(W));self.assertIsNone(self.s.one('SELECT * FROM source_inventory'))
 def test_same_second_sell_buy_quarantined(self):
  t=now();self.collect(page([row('SELL',timestamp=t),row('BUY',timestamp=t)]));self.assertFalse(self.i.allowed(W));self.assertIsNone(self.s.one('SELECT * FROM source_inventory'))
 def test_ambiguous_row_direct_engine_never_economic_event(self):
  with tempfile.TemporaryDirectory() as tmp:
   s=Store(tmp+'/production.sqlite',self.c)
   try:
    e=Engine(s,self.c);e.ingest(W,row());e.ingest(W,row());self.assertEqual(s.one('SELECT COUNT(*) n FROM source_observations')['n'],2);self.assertIsNone(s.one('SELECT * FROM events'))
   finally:s.db.close()
 def test_synthetic_certificate_duplicate_applies_once(self):
  a=self.incoming();b=self.incoming();self.assertEqual(a,b);self.assertEqual(d(self.s.one('SELECT qty FROM source_inventory')['qty']),10)
 def test_two_identical_economics_with_distinct_fixture_certificates(self):
  self.incoming('first');self.incoming('second');self.assertEqual(d(self.s.one('SELECT qty FROM source_inventory')['qty']),20)
 def test_conflicting_identity_quarantines(self):
  eid=self.incoming();self.i.synthetic_event(W,'incoming','BUY',{'different':'payload'},0);self.assertEqual(self.s.one('SELECT state FROM verified_events WHERE id=?',(eid,))['state'],'conflict');self.assertFalse(self.i.allowed(W))
 def test_production_cannot_accept_synthetic_certificate(self):
  with tempfile.TemporaryDirectory() as tmp:
   s=Store(tmp+'/production.sqlite')
   try:
    with self.assertRaises(ValueError):Integrity(s).synthetic_event(W,'fixture','BUY',{},0)
   finally:s.db.close()
 def test_matching_snapshots_do_not_admit(self):
  api=API(page([{'token_id':'T','current_size':10}]),page([]),page([]),page([]));Collector(self.s,self.c,Engine(self.s,self.c),api).baseline(self.s.one('SELECT * FROM wallets'));self.assertFalse(self.i.allowed(W));self.assertIsNone(self.s.one('SELECT * FROM source_positions'))
 def test_same_second_boundary_does_not_update_inventory(self):
  self.s.db.execute('INSERT INTO source_positions VALUES(?,?,?)',(W,'T','10'));self.s.db.execute('INSERT INTO settings VALUES(?,?)',('inventory:'+W,'{}'));self.s.db.execute('UPDATE wallets SET added=?',(now()+1,));Engine(self.s,self.c).ingest(W,row(timestamp=now()));Engine(self.s,self.c).process();self.assertEqual(d(self.s.one('SELECT qty FROM source_positions')['qty']),10)
 def test_dust_archived_and_missing_rows_not_zero(self):
  self.s.db.execute('INSERT INTO source_positions VALUES(?,?,?)',(W,'T','.01'));api=API(page([]),page([]),page([]),page([]));Collector(self.s,self.c,Engine(self.s,self.c),api).baseline(self.s.one('SELECT * FROM wallets'));self.assertEqual(d(self.s.one('SELECT qty FROM source_positions')['qty']),d('.01'));evidence=json.loads(self.s.one('SELECT evidence FROM baseline_evidence')['evidence']);self.assertIn('inactive',evidence['filters'])
 def test_no_invalid_closed_archived_parameters(self):
  api=API(page([]),page([]),page([]),page([]));Collector(self.s,self.c,Engine(self.s,self.c),api).baseline(self.s.one('SELECT * FROM wallets'));self.assertFalse(any(p.get('status')=='CLOSED' and 'include_archived' in p for _,p in api.calls))
 def test_stale_status_blocked(self):self.assertFalse(Collector.source_health({'data':{'age_seconds':999,'computed_at':'2000-01-01T00:00:00Z'}})[0])
 def test_missing_status_blocked(self):self.assertFalse(Collector.source_health(None)[0])
 def test_partial_and_full_source_sell(self):
  self.incoming();self.cert('partial','SELL',[{'identity':'partial/leg','token':'T','delta':'-4','cash':'3'}]);self.cert('full','SELL',[{'identity':'full/leg','token':'T','delta':'-6','cash':'4'}]);self.assertEqual(d(self.s.one('SELECT qty FROM source_inventory')['qty']),0);self.assertEqual(sum(d(r['realized']) for r in self.s.rows('SELECT realized FROM source_movements')),2)
 def test_split_explicit_legs(self):
  self.cert('split','SPLIT',[{'identity':'split/yes','token':'T','delta':'10','basis':'5','cash':'-5'},{'identity':'split/no','token':'OTHER','delta':'10','basis':'5','cash':'-5'}]);self.assertEqual(self.s.one('SELECT COUNT(*) n FROM source_inventory')['n'],2)
 def test_merge_explicit_legs(self):
  self.incoming('yes','T');self.incoming('no','OTHER');self.cert('merge','MERGE',[{'identity':'merge/yes','token':'T','delta':'-10','cash':'5'},{'identity':'merge/no','token':'OTHER','delta':'-10','cash':'5'}]);self.assertTrue(all(d(r['qty'])==0 for r in self.s.rows('SELECT qty FROM source_inventory')))
 def test_redeem_fractional_payout_once(self):
  self.incoming();self.cert('payout','REDEEM',[{'identity':'payout/leg','token':'T','delta':'-10','cash':'5'}]);self.cert('payout','REDEEM',[{'identity':'payout/leg','token':'T','delta':'-10','cash':'5'}]);self.assertEqual(self.s.one('SELECT COUNT(*) n FROM source_movements')['n'],2)
 def test_resolution_does_not_pay_again(self):
  self.incoming();self.cert('resolution','RESOLUTION',[{'identity':'resolution/leg','token':'T','delta':'0','cash':'0'}]);self.assertEqual(d(self.s.one('SELECT qty FROM source_inventory')['qty']),10)
 def test_conversion_evidenced_debit_credit(self):
  self.incoming();self.cert('convert','CONVERSION',[{'identity':'convert/out','token':'T','delta':'-10','cash':'0'},{'identity':'convert/in','token':'OTHER','delta':'10','basis':'5','cash':'0'}]);self.assertEqual(d(self.s.one('SELECT qty FROM source_inventory WHERE token=?',('OTHER',))['qty']),10)
 def test_negative_risk_evidenced_legs(self):
  self.incoming();self.cert('negative-risk','NEG_RISK',[{'identity':'negative-risk/out','token':'T','delta':'-10','cash':'0'},{'identity':'negative-risk/in','token':'OTHER','delta':'10','basis':'5','cash':'0'}]);self.assertEqual(self.s.one("SELECT state FROM verified_events WHERE kind='NEG_RISK'")['state'],'applied')
 def test_combo_evidenced_legs_not_trade(self):
  self.cert('combo','COMBO',[{'identity':'combo/leg','token':'T','delta':'10','basis':'5','cash':'-5'}]);self.assertIsNone(self.s.one('SELECT * FROM events'));self.assertEqual(self.s.one("SELECT kind FROM verified_events")['kind'],'COMBO')
 def test_transfer_plus_lifecycle_no_double_count(self):
  self.cert('transfer','TRANSFER',[{'identity':'shared-transfer','token':'T','delta':'10','basis':'5','cash':'0'}],['shared-effect']);self.cert('split-description','SPLIT',[{'identity':'shared-transfer','token':'T','delta':'10','basis':'5','cash':'0'}],['shared-effect']);self.assertEqual(d(self.s.one('SELECT qty FROM source_inventory')['qty']),10);self.assertFalse(self.i.allowed(W))
 def test_duplicate_payout_different_id_same_effect(self):
  self.incoming();legs=[{'identity':'redemption/leg','token':'T','delta':'-10','cash':'5'}];self.cert('redemption','REDEEM',legs,['payout-effect']);self.cert('duplicate','REDEEM',legs,['payout-effect']);self.assertEqual(self.s.one('SELECT COUNT(*) n FROM source_movements')['n'],2)
 def test_missing_conversion_legs_quarantined(self):
  self.cert('missing','CONVERSION',[]);self.assertEqual(self.s.one('SELECT state FROM verified_events')['state'],'quarantined')
 def test_unknown_operation_quarantined(self):
  self.cert('unknown','UNKNOWN',[{'identity':'unknown/leg','token':'T','delta':'1','basis':'0'}]);self.assertIsNone(self.s.one('SELECT * FROM source_movements'))
 def test_reorg_correction_reversal_block_instead_of_rewrite(self):
  self.incoming()
  for kind in ['REORG','CORRECTION','REVERSAL']:self.cert(kind,kind,[])
  self.assertEqual(d(self.s.one('SELECT qty FROM source_inventory')['qty']),10);self.assertFalse(self.i.allowed(W))
 def test_disable_open_positions_records_hold(self):
  self.paper();Wallets(self.s).change(W,'disable');self.assertIsNotNone(self.s.one('SELECT * FROM paper_holds'));self.assertIsNotNone(self.s.one('SELECT * FROM monitoring_gaps'))
 def paper(self):self.s.db.execute('INSERT INTO positions VALUES(?,?,?,?,?,?,?)',('A','executable',W,'T','M','2','1'))
 def test_missed_sell_during_gap_never_historical_fill(self):
  self.paper();Wallets(self.s).change(W,'disable');self.incoming();self.cert('missed','SELL',[{'identity':'missed/leg','token':'T','delta':'-10','cash':'6'}]);Wallets(self.s).change(W,'enable');self.assertIsNone(self.s.one('SELECT * FROM fills'));self.assertEqual(self.s.one('SELECT state FROM reconciliation_records ORDER BY id DESC LIMIT 1')['state'],'operator_review')
 def test_missed_merge_during_gap_keeps_paper(self):
  self.paper();Wallets(self.s).change(W,'disable');self.incoming();self.cert('missed-merge','MERGE',[{'identity':'missed-merge/leg','token':'T','delta':'-10','cash':'5'}]);Wallets(self.s).change(W,'enable');self.assertEqual(d(self.s.one('SELECT qty FROM positions')['qty']),2);self.assertFalse(self.i.allowed(W))
 def test_short_gap_enable_not_trusted(self):
  Wallets(self.s).change(W,'disable');Wallets(self.s).change(W,'enable');self.assertFalse(self.i.allowed(W));self.assertEqual(self.s.one('SELECT state FROM monitoring_gaps')['state'],'unreconciled')
 def test_long_gap_not_trusted(self):
  Wallets(self.s).change(W,'disable');self.s.db.execute('UPDATE monitoring_gaps SET opened=0');Wallets(self.s).change(W,'enable');self.assertFalse(self.i.allowed(W))
 def test_missing_history_retains_open_gap(self):
  with self.s.tx():self.i.gap(W,'missing historical events')
  self.collect(page([]));self.assertEqual(self.s.one('SELECT state FROM monitoring_gaps')['state'],'unreconciled')
 def test_soft_removal_retains_evidence(self):
  self.paper();self.collect(page([row()]));Wallets(self.s).change(W,'remove');self.assertIsNotNone(self.s.one('SELECT * FROM source_observations'));self.assertIsNotNone(self.s.one('SELECT * FROM monitoring_history'));self.assertIsNotNone(self.s.one('SELECT * FROM paper_holds'))
 def test_incomplete_reconciliation_does_not_match_by_balance(self):
  self.paper();self.incoming();Wallets(self.s).change(W,'disable');Wallets(self.s).change(W,'enable');self.assertIn('review',self.s.one('SELECT state FROM reconciliation_records ORDER BY id DESC LIMIT 1')['state'])
 def test_unmatched_legacy_paper_is_held(self):
  self.paper()
  with self.s.tx():self.i.hold(W,'no reliable source match')
  self.assertEqual(self.s.one('SELECT reason FROM paper_holds')['reason'],'no reliable source match')

 def test_independent_source_replay_expected_cash_and_realized(self):
  import importlib.util
  spec=importlib.util.spec_from_file_location('independent','tools/source_verify.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
  self.incoming();self.cert('sell','SELL',[{'identity':'sell/leg','token':'T','delta':'-10','cash':'7'}]);a=mod.verify(self.path);b=mod.verify(self.path);self.assertEqual(a,b);self.assertEqual(a['source_realized'],'2');self.assertFalse(a['errors'])
 def test_independent_source_replay_detects_tamper(self):
  import importlib.util
  spec=importlib.util.spec_from_file_location('independent','tools/source_verify.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
  self.incoming();self.s.db.execute("UPDATE source_inventory SET qty='999'");self.assertIn('source ending inventory mismatch',mod.verify(self.path)['errors'])
 def test_verifiers_do_not_import_production_accounting(self):
  import ast
  for path in ['tools/source_verify.py','tools/audit.py']:
   nodes=ast.walk(ast.parse(Path(path).read_text()));imports=[n.module for n in nodes if isinstance(n,ast.ImportFrom)]
   self.assertFalse(any(x and x.startswith('lab') for x in imports))
 def test_conversion_carries_basis_without_realized_loss(self):
  self.incoming();self.cert('carry','CONVERSION',[{'identity':'carry/out','token':'T','delta':'-10','cash':'0'},{'identity':'carry/in','token':'OTHER','delta':'10','basis':'5','cash':'0'}]);self.assertEqual(sum(d(x['realized']) for x in self.s.rows('SELECT realized FROM source_movements')),0)
 def test_unverified_conversion_allocation_is_blocked(self):
  self.incoming();self.cert('badcarry','CONVERSION',[{'identity':'badcarry/out','token':'T','delta':'-10','cash':'0'},{'identity':'badcarry/in','token':'OTHER','delta':'10','basis':'1','cash':'0'}]);self.assertEqual(d(self.s.one('SELECT qty FROM source_inventory')['qty']),10);self.assertFalse(self.i.allowed(W))
 def test_ambiguity_flags_visible(self):
  t=now();r=row(timestamp=t);self.collect(page([r,r,row('SELL',timestamp=t)]));self.assertTrue(self.s.one("SELECT * FROM observation_flags WHERE flag='identical_economics'"));self.assertTrue(self.s.one("SELECT * FROM observation_flags WHERE flag='same_timestamp_opposing'"))
 def test_synthetic_forward_export_cannot_claim_real_results(self):
  from lab.validation import forward_evidence
  self.incoming();v=forward_evidence(self.s);self.assertEqual(v['classification'],'synthetic');self.assertTrue(v['no_forward_results']);self.assertFalse(v['forward_ready']);self.assertFalse(v['profitability_claim'])
 def test_zero_wallets_zero_forward_results(self):
  from lab.validation import forward_evidence
  with tempfile.TemporaryDirectory() as tmp:
   s=Store(tmp+'/empty.sqlite')
   try:
    v=forward_evidence(s);self.assertEqual(v['supplied_wallet_count'],0);self.assertTrue(v['no_forward_results']);self.assertFalse(v['profitability_claim'])
   finally:s.db.close()
 def test_synthetic_db_cannot_start_real_application(self):
  from lab.main import App
  with self.assertRaises(ValueError):App(self.path,self.c)
 def test_production_legacy_pending_event_has_no_inventory_effect(self):
  with tempfile.TemporaryDirectory() as tmp:
   s=Store(tmp+'/production.sqlite',self.c)
   try:
    s.db.execute('INSERT INTO source_positions VALUES(?,?,?)',(W,'T','10'))
    s.db.execute("INSERT INTO events(id,wallet,token,market,side,qty,price,ts,detected,payload) VALUES(?,?,?,?,?,?,?,?,?,?)",('legacy',W,'T','M','BUY','10','.5',now()-10,now()-10,'{}'))
    Engine(s,self.c).process();self.assertEqual(d(s.one('SELECT qty FROM source_positions')['qty']),10);self.assertEqual(s.one('SELECT status FROM events')['status'],'quarantined')
   finally:s.db.close()

 def test_duplicate_verified_transport_links_retained_once_economically(self):
  a=self.i.observe(W,'/v2/trades',row());b=self.i.observe(W,'/v2/trades',row())
  payload={'legs':[{'identity':'transport/leg','token':'T','delta':'10','basis':'5','cash':'-5'}],'effects':['transport/effect']}
  first=self.i.synthetic_event(W,'transport','BUY',payload,0,a);second=self.i.synthetic_event(W,'transport','BUY',payload,0,b);self.i.lifecycle(first);self.i.lifecycle(second)
  self.assertEqual(self.s.one('SELECT COUNT(*) n FROM source_observations')['n'],2);self.assertEqual(self.s.one('SELECT COUNT(*) n FROM event_links')['n'],2);self.assertEqual(d(self.s.one('SELECT qty FROM source_inventory')['qty']),10)
 def test_healthy_status_does_not_prove_baseline(self):
  api=API(page([]),page([]),page([]),page([]))
  with patch.object(Collector,'source_health',return_value=(True,'fixture-only healthy')):
   Collector(self.s,self.c,Engine(self.s,self.c),api).baseline(self.s.one('SELECT * FROM wallets'),{'fixture':'healthy, not checkpoint'})
  self.assertFalse(self.i.allowed(W))
 def test_unparseable_response_body_preserved(self):
  class BadAPI:
   last_raw='not-json'
   def get(self,*a,**kw):self.last_raw='not-json';raise ValueError('invalid json')
  with self.assertRaises(ValueError):self.i.collect(BadAPI(),W,'/v2/trades',{'user':W})
  self.assertEqual(self.s.one('SELECT raw FROM transport_deliveries')['raw'],'not-json');self.assertIsNone(self.s.one('SELECT * FROM capture_frontiers'))
 def test_empty_cursor_not_terminal_evidence(self):
  with self.assertRaises(ValueError):self.collect({'data':[],'pagination':{'next_cursor':'','has_more':False}})
  self.assertIsNone(self.s.one('SELECT * FROM capture_frontiers'))
 def test_verified_order_regression_quarantines(self):
  self.incoming();eid=self.i.synthetic_event(W,'regression','BUY',{'legs':[{'identity':'regression/leg','token':'T','delta':'1','basis':'1','cash':'-1'}],'effects':['regression']},-1);self.i.lifecycle(eid);self.assertEqual(d(self.s.one('SELECT qty FROM source_inventory')['qty']),10);self.assertFalse(self.i.allowed(W))

class MigrationTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.path=Path(self.tmp.name)/'legacy.sqlite';self.db=sqlite3.connect(self.path);self.db.executescript(SCHEMA);self.db.execute('INSERT INTO migrations VALUES(1,?)',(now(),));self.db.execute('INSERT INTO migrations VALUES(2,?)',(now(),));self.db.execute('INSERT INTO audit(ts,action,payload) VALUES(?,?,?)',(now(),'fixture','{}'));self.db.commit()
 def tearDown(self):self.db.close();self.tmp.cleanup()
 def test_existing_refuses_auto_migration_without_changes(self):
  before=self.path.read_bytes()
  with self.assertRaises(ValueError):Store(str(self.path))
  self.assertEqual(before,self.path.read_bytes())
 def test_verified_backup_additive_and_idempotent_refusal(self):
  before=table_digests(self.db,['audit','wallets','positions','ledger']);out=upgrade_existing(self.path,Path(self.tmp.name)/'backup.sqlite');self.assertTrue(out['backup_verified']);self.assertEqual(before,table_digests(self.db,['audit','wallets','positions','ledger']));self.assertEqual(self.db.execute('SELECT MAX(version) FROM migrations').fetchone()[0],3)
  with self.assertRaises(ValueError):upgrade_existing(self.path,Path(self.tmp.name)/'again.sqlite')
 def test_failed_migration_rolls_back_schema(self):
  self.db.execute("CREATE TRIGGER fixture_reject BEFORE INSERT ON migrations WHEN NEW.version=3 BEGIN SELECT RAISE(ABORT,'fixture migration interruption'); END");self.db.commit()
  with self.assertRaises(sqlite3.IntegrityError):upgrade_existing(self.path,Path(self.tmp.name)/'backup.sqlite')
  self.assertIsNone(self.db.execute("SELECT name FROM sqlite_master WHERE name='source_environment'").fetchone());self.assertEqual(self.db.execute('SELECT MAX(version) FROM migrations').fetchone()[0],2)
