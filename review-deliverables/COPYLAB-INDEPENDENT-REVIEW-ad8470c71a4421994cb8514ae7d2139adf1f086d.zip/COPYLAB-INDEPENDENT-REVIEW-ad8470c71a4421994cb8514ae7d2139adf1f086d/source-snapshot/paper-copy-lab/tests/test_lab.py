import unittest,tempfile,json,time,sqlite3,random
from pathlib import Path
from lab.store import Store,dec as d,now
from lab.engine import Engine
from lab.wallets import Wallets
from lab.public import PublicClient,Collector
W='0x'+'1'*40
class LabTest(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory(); self.path=self.tmp.name+'/test.sqlite'; self.c=json.loads(Path('config.json').read_text()); self.c['detection_latency_seconds']=0; self.c['execution_latency_seconds']=0
  self.s=Store(self.path,self.c,synthetic=True); self.e=Engine(self.s,self.c); self.w=Wallets(self.s); self.w.change(W,'add'); self.s.db.execute('UPDATE wallets SET added=?',(now()-100,)); self.book(); self.s.db.execute('INSERT INTO settings VALUES(?,?)',('inventory:'+W,'{}'))
 def tearDown(self): self.s.db.close();self.tmp.cleanup()
 def book(self,bid='0.49',ask='0.51',ts=None,size='10000'):
  ts=now() if ts is None else ts
  self.s.db.execute('INSERT INTO books(token,ts,payload) VALUES(?,?,?)',('T',ts,json.dumps({'bids':[{'price':bid,'size':size}],'asks':[{'price':ask,'size':size}]})))
  self.s.db.execute('INSERT OR REPLACE INTO markets VALUES(?,?,?,?,?,?,?)',('T','M','Test fixture','0.04','1','{}',now()))
 def event(self,side='BUY',qty=100,price=.5,tx='tx',ts=None):
  return self.e.ingest(W,dict(proxy_wallet=W,side=side,token_id='T',condition_id='M',size=qty,price=price,timestamp=ts or now()-1,transaction_hash=tx))
 def order(self,side='BUY',qty='10',model='A',track='ideal'):
  i=self.s.db.execute('INSERT INTO orders(event,model,track,wallet,token,market,side,qty,reference,due,status,reason) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',(str(random.random()),model,track,W,'T','M',side,qty,'0.5',now(),'pending','fixture')).lastrowid
  return self.s.one('SELECT * FROM orders WHERE id=?',(i,))
 def fill(self,side,qty,price,fee='0',model='A',track='ideal'):
  o=self.order(side,str(qty),model,track)
  with self.s.tx(): self.e.a.fill(o,qty,price,fee,'0'); self.s.db.execute("UPDATE orders SET status='filled' WHERE id=?",(o['id'],))
 def test_ten_independent_ledgers(self):
  self.fill('BUY',10,'.5')
  for mo in 'ABCDE':
   for tr in ['ideal','executable']:
    cash=self.e.a.metrics(mo,tr)['available_cash'];self.assertEqual(d(cash),d('995') if (mo,tr)==('A','ideal') else d(1000))
 def test_partial_sells_fee_basis(self):
  self.fill('BUY',100,'.5','1'); self.fill('SELL',40,'.7','.4')
  x=self.e.a.metrics('A','ideal'); self.assertEqual(d(x['realized_pnl']),d('7.2'));self.assertEqual(d(x['invested_capital']),d('30.6'));self.assertEqual(d(x['available_cash']),d('976.6'))
  self.fill('SELL',60,'.8','.6');x=self.e.a.metrics('A','ideal');self.assertEqual(d(x['realized_pnl']),d(24));self.assertEqual(d(x['portfolio_equity']),d(1024)); self.assertEqual(d(x['total_pnl']),d(24))
 def test_oversell_rolls_back(self):
  self.fill('BUY',2,'.5')
  with self.assertRaises(ValueError):self.fill('SELL',3,'.7')
  self.assertEqual(self.s.one('SELECT COUNT(*) n FROM fills')['n'],1)
 def test_idempotent_events(self):
  ts=now()-1;self.event(ts=ts);self.event(ts=ts);self.assertEqual(self.s.one('SELECT COUNT(*) n FROM events')['n'],1)
  self.e.process();self.e.process(); self.assertEqual(self.s.one('SELECT COUNT(*) n FROM decisions')['n'],10)
 def test_missing_books_blocks(self):
  self.s.db.execute('DELETE FROM books');self.event();self.e.process();self.assertEqual(self.s.one('SELECT COUNT(*) n FROM orders')['n'],0)
 def test_executable_requires_post_latency_book(self):
  self.event();self.e.process();self.e.execute();self.assertEqual(self.s.one("SELECT COUNT(*) n FROM fills f JOIN orders o ON o.id=f.order_id WHERE o.track='executable'")['n'],0)
  self.book();self.e.execute();self.assertGreater(self.s.one("SELECT COUNT(*) n FROM fills f JOIN orders o ON o.id=f.order_id WHERE o.track='executable'")['n'],0)
 def test_fees_formula(self):
  self.event();self.e.process();self.book();self.e.execute()
  f=self.s.one("SELECT f.* FROM fills f JOIN orders o ON o.id=f.order_id WHERE o.model='A' AND o.track='executable'")
  self.assertAlmostEqual(float(f['fee']),float(d(f['qty'])*d('.04')*d('.51')*d('.49')),places=7)
 def test_unknown_fee_blocks(self):
  self.event();self.e.process();self.book();self.s.db.execute('UPDATE markets SET fee_rate=NULL');self.e.execute();self.assertTrue(self.s.one("SELECT * FROM orders WHERE track='executable' AND reason='unknown or unsupported fee schedule'"))
 def test_partial_depth(self):
  self.event(qty=10000);self.e.process();self.book(size='100');self.e.execute();f=self.s.one("SELECT f.qty FROM fills f JOIN orders o ON o.id=f.order_id WHERE o.model='A' AND o.track='executable'");self.assertEqual(d(f['qty']),d('10'))
 def test_wallet_validation_and_history(self):
  with self.assertRaises(ValueError):self.w.change('bad','add')
  self.w.change(W,'remove');self.assertEqual(self.s.one('SELECT removed FROM wallets')['removed'],1);self.assertEqual(self.s.one('SELECT COUNT(*) n FROM audit')['n'],2)
 def test_disabled_pending_buys(self):
  self.event();self.e.process();self.w.change(W,'disable');self.book();self.e.execute();self.assertEqual(self.s.one('SELECT COUNT(*) n FROM fills')['n'],0)
 def test_restart_does_not_reset(self):
  self.fill('BUY',10,'.5');self.event();self.e.process();before=self.e.a.metrics('A','ideal');self.s.db.close();self.s=Store(self.path,self.c);self.e=Engine(self.s,self.c);self.assertEqual(before,self.e.a.metrics('A','ideal'));self.e.process();self.assertEqual(self.s.one('SELECT COUNT(*) n FROM decisions')['n'],10)
 def test_backup_recovery(self):
  self.fill('BUY',10,'.5');p=self.tmp.name+'/backup.sqlite';self.s.backup(p);b=Store(p,self.c);self.assertEqual(b.one('PRAGMA integrity_check')['integrity_check'],'ok');self.assertEqual(b.one('SELECT COUNT(*) n FROM ledger')['n'],1);b.db.close()
 def test_config_mismatch_refused(self):
  c={**self.c,'starting_capital':'2000'}
  with self.assertRaises(ValueError):Store(self.path,c)
 def test_stale_events_not_replayed(self):
  self.s.db.execute('UPDATE wallets SET added=0');self.event(ts=now()-1000);self.e.process();self.assertEqual(self.s.one('SELECT COUNT(*) n FROM orders')['n'],0)
 def test_out_of_order_quarantined(self):
  self.event(ts=now()-2);self.e.process();self.event(tx='older',ts=now()-10);self.e.process();self.assertEqual(self.s.one("SELECT COUNT(*) n FROM events WHERE status='quarantined'")['n'],1)
 def test_no_future_mark(self):
  self.fill('BUY',10,'.5');self.book(bid='.9',ts=now()+1000);x=self.e.a.metrics('A','ideal');self.assertEqual(d(x['open_position_value']),d('4.9'))
 def test_drawdown(self):
  self.fill('BUY',100,'.5');self.book(bid='.8');self.e.a.snapshot();self.book(bid='.2');x=self.e.a.metrics('A','ideal');self.assertEqual(d(x['peak_equity']),d(1030));self.assertGreater(d(x['maximum_drawdown']),d('.05'))
 def test_equity_identity_random_lifecycle(self):
  rng=random.Random(12)
  for _ in range(50):
   self.fill('BUY',10,str(rng.uniform(.1,.8)),'.01');self.fill('SELL',4,str(rng.uniform(.1,.8)),'.01');self.fill('SELL',6,str(rng.uniform(.1,.8)),'.01')
   x=self.e.a.metrics('A','ideal');self.assertAlmostEqual(float(x['portfolio_equity']),1000+float(x['total_pnl']),places=5)
 def test_api_rejects_order_endpoint(self):
  with self.assertRaises(ValueError):PublicClient().get('clob','/order')
 def test_models_different_entries(self):
  self.event();self.e.process();reasons={x['model']:x['reason'] for x in self.s.rows("SELECT model,reason FROM decisions WHERE track='ideal'")};self.assertEqual(len(set(reasons.values())),5)
 def test_closed_position_winrate_not_partial_fills(self):
  self.fill('BUY',10,'.5');self.fill('SELL',5,'.8');self.fill('SELL',5,'.1')
  x=self.e.a.metrics('A','ideal');self.assertEqual(x['closed_position_count'],1);self.assertEqual(d(x['win_rate']),d(0));self.assertEqual(d(x['realized_pnl']),d('-.5'))
 def test_reopened_position_separate_lifecycle(self):
  self.fill('BUY',10,'.5');self.fill('SELL',10,'.6');self.fill('BUY',10,'.4');self.fill('SELL',10,'.3')
  rows=self.s.rows('SELECT * FROM closed_positions ORDER BY id');self.assertEqual([d(r['realized']) for r in rows],[d(1),d(-1)]);self.assertEqual(d(self.e.a.metrics('A','ideal')['win_rate']),d('.5'))
 def test_settlement_fractional_payout_and_idempotence(self):
  self.fill('BUY',10,'.4','1');self.e.settle('T','.5',{'resolved':True,'token_id':'T','final_price':'.5'});self.e.settle('T','.5',{'resolved':True,'token_id':'T','final_price':'.5'})
  x=self.e.a.metrics('A','ideal');self.assertEqual(d(x['available_cash']),d(1000));self.assertEqual(x['closed_position_count'],1);self.assertEqual(self.s.one('SELECT COUNT(*) n FROM fills')['n'],2)
 def test_settlement_losing_token(self):
  self.fill('BUY',10,'.4');self.e.settle('T',0,{'resolved':True,'token_id':'T','final_price':0});self.assertEqual(d(self.e.a.metrics('A','ideal')['realized_pnl']),d(-4))
 def test_unresolved_not_settled(self):
  with self.assertRaises(ValueError):self.e.settle('T',1,{'resolved':False,'token_id':'T'})
 def test_hybrid_partial_and_full_source_sell(self):
  self.event(qty=100);self.e.process();self.e.execute()
  self.event(side='SELL',qty=40,price=.5,tx='partial',ts=now());self.e.process();self.e.execute()
  p=self.s.one("SELECT qty FROM positions WHERE model='A' AND track='ideal'");self.assertEqual(d(p['qty']),d('1.2'))
  self.event(side='SELL',qty=60,price=.5,tx='full',ts=now());self.e.process();self.e.execute();self.assertEqual(d(self.e.a.metrics('A','ideal')['invested_capital']),d(0))
 def test_unbaselined_wallet_does_not_copy(self):
  self.s.db.execute('DELETE FROM settings WHERE key=?',('inventory:'+W,));self.event();self.e.process();self.assertEqual(self.s.one('SELECT COUNT(*) n FROM orders')['n'],0)
 def test_source_inventory_mismatch_blocks_sell(self):
  self.fill('BUY',10,'.5');self.event(side='SELL',qty=100);self.e.process();self.assertTrue(self.s.one("SELECT * FROM decisions WHERE reason='source inventory mismatch; sell quarantined'"))
 def test_enable_rebaselines_and_preserves_history(self):
  self.event();self.w.change(W,'disable');self.w.change(W,'enable');self.assertIsNone(self.s.one('SELECT value FROM settings WHERE key=?',('inventory:'+W,)));self.assertEqual(self.s.one('SELECT COUNT(*) n FROM events')['n'],1)
 def test_invalid_data_rejected(self):
  for price in [float('nan'),float('inf'),-1,1.5]:
   with self.assertRaises(ValueError):self.event(price=price)
 def test_market_and_wallet_exposure_limits(self):
  self.fill('BUY',180,'.5');self.event(qty=3000);self.e.process();self.assertEqual(d(self.s.one("SELECT qty FROM decisions WHERE model='A' AND track='ideal'")['qty']),d(0))
 def test_trade_frequency_limit(self):
  self.c['max_trades_hour']=0;self.event();self.e.process();self.assertEqual(self.s.one('SELECT COUNT(*) n FROM orders')['n'],0)
 def test_execution_rechecks_drawdown(self):
  self.event();self.e.process();self.book();self.c['models']['A']['max_drawdown']='0';self.e.execute();self.assertTrue(self.s.one("SELECT * FROM orders WHERE model='A' AND reason='execution risk: drawdown circuit breaker'"))
 def test_model_specific_exits(self):
  self.fill('BUY',10,'.5',model='A');self.fill('BUY',10,'.5',model='E');self.book(bid='.43');self.e.exits()
  self.assertIsNone(self.s.one("SELECT * FROM orders WHERE model='A' AND side='SELL'"));self.assertIsNotNone(self.s.one("SELECT * FROM orders WHERE model='E' AND side='SELL'"))
 def test_selective_uses_source_performance(self):
  self.s.db.execute('INSERT OR REPLACE INTO settings VALUES(?,?)',('performance:'+W,json.dumps({'observed':now(),'wins':8,'closes':10})));self.book(bid='.495',ask='.505');self.event();self.e.process();self.assertGreater(d(self.s.one("SELECT qty FROM decisions WHERE model='B' AND track='ideal'")['qty']),0)
 def test_value_requires_discount(self):
  self.book(bid='.47',ask='.48');self.event();self.e.process();self.assertGreater(d(self.s.one("SELECT qty FROM decisions WHERE model='D' AND track='ideal'")['qty']),0)
 def test_momentum_confirmation(self):
  self.book(bid='.495',ask='.505');self.book(bid='.50',ask='.51');self.event(tx='confirmation',ts=now()-2);self.event();self.e.process();self.assertGreater(d(self.s.one("SELECT qty FROM decisions WHERE model='C' AND track='ideal'")['qty']),0)
 def test_daily_loss_limit(self):
  self.fill('BUY',200,'.5');self.c['models']['A']['max_position']='200';self.book(bid='.2');self.event();self.e.process();self.assertTrue(self.s.one("SELECT * FROM decisions WHERE reason='daily loss circuit breaker'"))
 def test_stale_portfolio_pauses_entries(self):
  self.fill('BUY',10,'.5');self.s.db.execute('DELETE FROM books');self.event();self.e.process();self.assertEqual(self.s.one('SELECT COUNT(*) n FROM decisions WHERE CAST(qty AS REAL)>0')['n'],0)
 def test_pagination_duplicate_cursor_fails(self):
  class API(PublicClient):
   def get(self,*a,**kw):return {'data':[],'pagination':{'next_cursor':'same'}}
  with self.assertRaises(RuntimeError):list(API().pages('/v2/trades'))
 def test_baseline_current_size_v2(self):
  class API:
   def get(self,service,route,**kw):return {'data':[{'token_id':'T','current_size':17}] if route=='/v2/positions' else [],'pagination':{'next_cursor':None,'has_more':False}}
  self.s.db.execute('DELETE FROM settings WHERE key=?',('inventory:'+W,));Collector(self.s,self.c,self.e,API()).baseline(self.s.one('SELECT * FROM wallets'))
  obs=self.s.one("SELECT payload FROM source_observations WHERE endpoint='/v2/positions'");self.assertEqual(json.loads(obs['payload'])['current_size'],17)
  self.assertIsNone(self.s.one('SELECT qty FROM source_positions'));self.assertEqual(self.s.one('SELECT state FROM baseline_evidence')['state'],'quarantined')
 def test_baseline_not_admitted_during_activity(self):
  class API:
   def get(self,service,route,**kw):return {'data':[] if route=='/v2/positions' else [{'transaction_hash':'fixture'}],'pagination':{'next_cursor':None,'has_more':False}}
  self.s.db.execute('DELETE FROM settings WHERE key=?',('inventory:'+W,));Collector(self.s,self.c,self.e,API()).baseline(self.s.one('SELECT * FROM wallets'));self.assertIsNone(self.s.one('SELECT value FROM settings WHERE key=?',('inventory:'+W,)));self.assertEqual(self.s.one('SELECT state FROM baseline_evidence')['state'],'quarantined')
 def test_transaction_crash_rolls_back_all_writes(self):
  o=self.order()
  with self.assertRaises(RuntimeError):
   with self.s.tx():self.e.a.fill(o,10,'.5',0,0);raise RuntimeError('simulated interruption before commit')
  self.assertEqual(self.s.one('SELECT COUNT(*) n FROM fills')['n'],0);self.assertEqual(self.s.one('SELECT COUNT(*) n FROM ledger')['n'],0);self.assertEqual(self.s.one('SELECT COUNT(*) n FROM positions')['n'],0)
 def test_selective_spread_exit(self):
  self.fill('BUY',10,'.5',model='B');self.book(bid='.49',ask='.56');self.e.exits();self.assertEqual(self.s.one("SELECT reason FROM orders WHERE model='B' AND side='SELL'")['reason'],'selective spread deterioration')
 def test_momentum_reversal_exit(self):
  self.fill('BUY',10,'.5',model='C');self.book(bid='.52');self.book(bid='.50');self.book(bid='.49');self.e.exits();self.assertEqual(self.s.one("SELECT reason FROM orders WHERE model='C' AND side='SELL'")['reason'],'momentum reversal')
 def test_value_target_exit(self):
  self.fill('BUY',10,'.5',model='D');self.book(bid='.76',ask='.77');self.e.exits();self.assertEqual(self.s.one("SELECT reason FROM orders WHERE model='D' AND side='SELL'")['reason'],'value target repricing')
 def test_same_book_liquidity_not_reused(self):
  self.order(qty='10',track='executable');self.order(qty='10',track='executable');self.book(size='100');self.e.execute();self.assertEqual(self.s.one("SELECT COUNT(*) n FROM fills f JOIN orders o ON o.id=f.order_id WHERE o.track='executable'")['n'],1)
 def test_order_reexecution_does_not_duplicate(self):
  self.event();self.e.process();self.book();self.e.execute();n=self.s.one('SELECT COUNT(*) n FROM fills')['n'];self.e.execute();self.assertEqual(self.s.one('SELECT COUNT(*) n FROM fills')['n'],n)
 def test_config_validation_rejects_real_mode(self):
  from lab.config import validate
  with self.assertRaises(ValueError):validate({**self.c,'paper_only':False})
  with self.assertRaises(ValueError):validate({**self.c,'copy_fraction':'NaN'})
 def test_market_minimum_order_size(self):
  self.event();self.e.process();self.book();row=self.s.one('SELECT * FROM books ORDER BY id DESC LIMIT 1');payload=json.loads(row['payload']);payload['min_order_size']='5';self.s.db.execute('UPDATE books SET payload=? WHERE id=?',(json.dumps(payload),row['id']));self.e.execute();self.assertTrue(self.s.one("SELECT * FROM orders WHERE model='A' AND track='executable' AND reason='below market minimum order shares'"))
 def test_actual_fee_inclusive_copy_cap(self):
  self.event(qty=10000);self.e.process();self.book();self.e.execute();self.assertTrue(self.s.one("SELECT * FROM orders WHERE model='A' AND track='executable' AND reason='execution risk: max_copy_amount'"))
 def test_executable_fill_retains_exact_book_context(self):
  self.event();self.e.process();self.book();self.e.execute();ctx=self.s.one('SELECT * FROM execution_context');self.assertIsNotNone(ctx);b=self.s.one('SELECT * FROM books WHERE id=?',(ctx['book_id'],));self.assertEqual(ctx['arrival'],b['ts']);self.assertEqual(d(ctx['spread']),d('.02'))
if __name__=='__main__':unittest.main()
