"""Record actual observed data span; never label sentinel observation as trading."""
import sqlite3,json,datetime,hashlib
from pathlib import Path
s=sqlite3.connect('data/lab.sqlite');s.row_factory=sqlite3.Row
rows=[dict(x) for x in s.execute('SELECT id,token,ts,payload FROM books ORDER BY ts')]
def stamp(t):return datetime.datetime.fromtimestamp(t,datetime.timezone.utc).isoformat() if t else None
report={'generated_utc':stamp(datetime.datetime.now(datetime.timezone.utc).timestamp()),'first_book_utc':stamp(rows[0]['ts']) if rows else None,'last_book_utc':stamp(rows[-1]['ts']) if rows else None,'sampled_span_seconds':rows[-1]['ts']-rows[0]['ts'] if rows else 0,'maximum_inter_sample_gap_seconds':max([b['ts']-a['ts'] for a,b in zip(rows,rows[1:])] or [0]),'book_snapshots':len(rows),'unique_tokens':len({x['token'] for x in rows}),'wallets':s.execute('SELECT COUNT(*) FROM wallets').fetchone()[0],'observed_wallet_events':s.execute('SELECT COUNT(*) FROM events').fetchone()[0],'simulated_fills':s.execute('SELECT COUNT(*) FROM fills').fetchone()[0],'portfolio_snapshots':s.execute('SELECT COUNT(*) FROM snapshots').fetchone()[0],'upstream_payload_sha256':hashlib.sha256(''.join(x['payload'] for x in rows).encode()).hexdigest(),'health':[dict(x) for x in s.execute('SELECT * FROM health')],'scope':'Real public market sentinel observation only. No wallet addresses supplied. Not forward copy-trading validation. Restarts create gaps; span is not uninterrupted runtime.','profitability_claim':False}
Path('docs/forward-evidence.json').write_text(json.dumps(report,indent=2))
Path('docs/FORWARD_REPORT.md').write_text(f'''# Forward public-data observation report

Generated: {report['generated_utc']}

- First real public order book: **{report['first_book_utc']}**
- Last included public order book: **{report['last_book_utc']}**
- Sampled first-to-last span: **{report['sampled_span_seconds']:.2f} seconds** (NOT uninterrupted runtime)
- Maximum sample gap: **{report['maximum_inter_sample_gap_seconds']:.2f} seconds**; application restarted during development.
- Public order-book observations: **{report['book_snapshots']}**, distinct sentinel tokens: **{report['unique_tokens']}**.
- Ten-world portfolio snapshots: **{report['portfolio_snapshots']}**.
- User wallets registered: **{report['wallets']}**.
- Observed wallet events: **{report['observed_wallet_events']}**.
- Actual production paper fills: **{report['simulated_fills']}**.

This is real Gamma/CLOB/Data public connectivity and repeated sentinel observation evidence, not evidence of profitable copying, obtainable executions, or successful source-wallet lifecycle monitoring. No arbitrary wallet was added. Capital remains unchanged because there were no copied trades. Synthetic accounting tests and 500-fill verifier stress data are strictly separate from production.

Raw live books remain in `data/lab.sqlite`. The payload hash and component health included in `forward-evidence.json` support reproducibility of this report. The worker may continue collecting after this report's cutoff; regenerate via `python3 tools/forward_report.py` for an updated cutoff.

## Required next validation

Supply proxy-wallet addresses. Record at least a meaningful multi-day forward window with enough copied buys, partial/full source sells and model exits across all models; predefine minimum sample and confidence criteria rather than choosing a winner after seeing outcomes. Exercise lossless restart, actual API failures, rate limits and source lifecycle events. Independently reconcile observed prices, causal due-time books, fee schedules, settlements and accounting. No fixed duration alone establishes profitability.
''')
print(json.dumps({k:v for k,v in report.items() if k!='health'},indent=2))
