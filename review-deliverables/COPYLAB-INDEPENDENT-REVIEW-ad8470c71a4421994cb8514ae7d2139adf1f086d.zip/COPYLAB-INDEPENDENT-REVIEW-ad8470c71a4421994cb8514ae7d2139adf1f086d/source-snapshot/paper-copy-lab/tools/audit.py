"""Independent-process verifier; does not import the production accounting code.
Not a substitute for third-party review. Replays fills with Fraction arithmetic.
"""
import sqlite3,json,argparse,ast
from fractions import Fraction as F
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--db',default='data/lab.sqlite');p.add_argument('--out',default='docs/audit-evidence.json');a=p.parse_args()
s=sqlite3.connect(Path(a.db).resolve().as_uri()+'?mode=ro',uri=True);s.row_factory=sqlite3.Row
errors=[];checked=0;tol=F(1,1000000)
if s.execute('PRAGMA integrity_check').fetchone()[0]!='ok':errors.append('database integrity check failed')
config=json.loads(s.execute("SELECT value FROM settings WHERE key='config'").fetchone()[0])
for model in 'ABCDE':
 for track in ['ideal','executable']:
  cash=F(config['starting_capital']);realized=F(0);positions={}
  for row in s.execute('SELECT f.*,o.side,o.wallet,o.token FROM fills f JOIN orders o ON o.id=f.order_id WHERE o.model=? AND o.track=? ORDER BY f.id',(model,track)):
   checked+=1;key=(row['wallet'],row['token']);q,c=positions.get(key,(F(0),F(0)));qty=F(row['qty']);price=F(row['price']);fee=F(row['fee'])
   if row['side']=='BUY':cash-=qty*price+fee;q+=qty;c+=qty*price+fee;r=F(0)
   else:
    if qty>q:errors.append(f'oversell fill {row["id"]}');continue
    basis=c*qty/q;cash+=qty*price-fee;r=qty*price-fee-basis;realized+=r;q-=qty;c-=basis
   positions[key]=(q,c)
   if abs(r-F(row['realized']))>tol:errors.append(f'realized mismatch fill {row["id"]}')
  ledger_cash=F(config['starting_capital'])+sum((F(x[0]) for x in s.execute('SELECT cash_delta FROM ledger WHERE model=? AND track=?',(model,track))),F(0))
  if abs(ledger_cash-cash)>tol:errors.append(f'cash mismatch {model}/{track}')
  for row in s.execute('SELECT * FROM positions WHERE model=? AND track=?',(model,track)):
   q,c=positions.pop((row['wallet'],row['token']),(F(0),F(0)))
   if abs(q-F(row['qty']))>tol or abs(c-F(row['cost']))>tol:errors.append(f'position mismatch {model}/{track}/{row["token"]}')
  if any(q or c for q,c in positions.values()):errors.append(f'missing stored position {model}/{track}')
  if cash<0:errors.append(f'negative cash {model}/{track}')
orphans=s.execute('SELECT COUNT(*) FROM fills f LEFT JOIN ledger l ON l.fill_id=f.id WHERE l.id IS NULL').fetchone()[0]
if orphans:errors.append(f'{orphans} fills missing ledger entries')
code='\n'.join(x.read_text() for x in Path('lab').glob('*.py'))
if 'private_key' in code or 'eth_account' in code:errors.append('unexpected signing code')
result={'classification':s.execute('SELECT kind FROM source_environment WHERE id=1').fetchone()[0] if s.execute("SELECT name FROM sqlite_master WHERE name='source_environment'").fetchone() else 'legacy-unclassified','process':'standalone Fraction-based replay; no production accounting imports','third_party_audit':False,'database':a.db,'fills_replayed':checked,'portfolios_checked':10,'integrity':'ok','errors':errors,'limits':['Zero live fills does not validate live execution.','Static scan is not a full security audit.','Requires independent human/agent review before claiming independent audit completion.']}
Path(a.out).write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2));raise SystemExit(bool(errors))
