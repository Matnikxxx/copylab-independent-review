"""Apply validated config while worker is stopped; never resets financial history."""
import sys,json,fcntl,argparse
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from lab.store import Store
from lab.config import validate
p=argparse.ArgumentParser();p.add_argument('--db',default='data/lab.sqlite');a=p.parse_args()
lock=open(a.db+'.worker.lock','a')
try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
except BlockingIOError:raise SystemExit('Stop worker before changing configuration')
c=validate(json.loads(Path('config.json').read_text()));s=Store(a.db)
old=s.one("SELECT value FROM settings WHERE key='config'")
if old and json.loads(old['value'])['starting_capital']!=c['starting_capital']:raise SystemExit('Starting capital is immutable for an existing run. Use a new isolated DB for a different-capital experiment.')
with s.tx():
 s.db.execute('INSERT OR REPLACE INTO settings VALUES(?,?)',('config',json.dumps(c,sort_keys=True)))
 s.audit('config_update',{'old':json.loads(old['value']) if old else None,'new':c})
s.db.close();print('Validated configuration applied; accounting history preserved.')
