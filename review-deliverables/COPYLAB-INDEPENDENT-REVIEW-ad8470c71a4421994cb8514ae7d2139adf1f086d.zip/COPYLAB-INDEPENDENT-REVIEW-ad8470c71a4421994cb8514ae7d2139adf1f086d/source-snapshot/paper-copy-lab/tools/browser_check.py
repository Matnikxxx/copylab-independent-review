"""Read-only production UI smoke test; wallet mutations use a disposable DB server."""
import json
from pathlib import Path
from playwright.sync_api import sync_playwright
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,args=['--no-sandbox'])
 page=browser.new_page(viewport={'width':1440,'height':1100});errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 pages=[]
 for name in ['overview','A','B','C','D','E','wallets','activity','health']:
  page.goto('http://127.0.0.1:8080/#'+name);page.wait_for_selector('#content .card');page.wait_for_timeout(100)
  assert page.locator('#error').inner_text()=='',page.locator('#error').inner_text()
  pages.append({'page':name,'title':page.locator('#title').inner_text(),'table_count':page.locator('table').count()})
 page.goto('http://127.0.0.1:8080/#overview');page.wait_for_selector('#content .card');page.screenshot(path='docs/dashboard-desktop.png',full_page=True)
 page.set_viewport_size({'width':390,'height':844});page.screenshot(path='docs/dashboard-mobile.png',full_page=True)
 overflow=page.evaluate('document.documentElement.scrollWidth > window.innerWidth')
 assert not overflow,'mobile page overflow'
 browser.close()
 report={'pages':pages,'javascript_errors':errors,'mobile_horizontal_overflow':overflow}
 Path('docs/browser-evidence.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
 assert not errors
