"""Build SYNTHETIC, disposable evidence. No network, user DB or wallet access."""
import sys,json,sqlite3,tempfile,subprocess,hashlib
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from lab.store import Store,SCHEMA,now
from lab.integrity import Integrity
from lab.migrations import upgrade_existing,table_digests
from lab.validation import forward_evidence
OUT=Path('docs/remediation');OUT.mkdir(exist_ok=True)
with tempfile.TemporaryDirectory() as tmp:
 s=Store(tmp+'/source.sqlite',synthetic=True);i=Integrity(s);ordinal=0
 def event(key,kind,legs):
  global ordinal
  ordinal+=1;eid=i.synthetic_event('fixture-wallet',key,kind,{'legs':legs,'effects':[key]},ordinal);i.lifecycle(eid)
 def leg(key,token,delta,cash='0',basis=None):
  v={'identity':key,'token':token,'delta':delta,'cash':cash}
  if basis is not None:v['basis']=basis
  return v
 event('entry','BUY',[leg('entry/leg','T','10','-5','5')])
 event('partial','SELL',[leg('partial/leg','T','-4','3')])
 event('conversion','CONVERSION',[leg('conversion/out','T','-6'),leg('conversion/in','OTHER','6','0','3')])
 event('resolution','RESOLUTION',[leg('resolution/leg','OTHER','0')])
 event('payout','REDEEM',[leg('payout/leg','OTHER','-6','4')])
 event('split','SPLIT',[leg('split/yes','YES','10','-5','5'),leg('split/no','NO','10','-5','5')])
 event('merge','MERGE',[leg('merge/yes','YES','-10','5'),leg('merge/no','NO','-10','5')])
 event('combo','COMBO',[leg('combo/leg','COMBO','2','-1','1')])
 event('negative-risk','NEG_RISK',[leg('negative-risk/out','COMBO','-2'),leg('negative-risk/in','DEST','2','0','1')])
 event('final','REDEEM',[leg('final/leg','DEST','-2','.5')])
 class CapturedAPI:
  def get(self,*args,**kw):return {'data':[{'side':'BUY','size':'10','price':'.5','timestamp':0,'transaction_hash':'tx','token_id':'T'},{'side':'BUY','size':'10.0','price':'.50','timestamp':0,'transaction_hash':'tx','token_id':'T'}],'pagination':{'next_cursor':None,'has_more':False}}
 i.collect(CapturedAPI(),'fixture-wallet','/v2/trades',{'user':'fixture-wallet'})
 subprocess.run([sys.executable,'tools/source_verify.py','--db',s.path,'--out',str(OUT/'source-replay.json')],check=True)
 report=json.loads((OUT/'source-replay.json').read_text());assert report['source_cash']=='3/2' and report['source_realized']=='3/2' and not report['errors']
 subprocess.run([sys.executable,'tools/source_verify.py','--db',s.path,'--out',str(OUT/'source-replay-repeat.json')],check=True)
 assert (OUT/'source-replay.json').read_bytes()==(OUT/'source-replay-repeat.json').read_bytes()
 export=forward_evidence(s);assert export['classification']=='synthetic' and export['no_forward_results'] and not export['profitability_claim']
 (OUT/'synthetic-forward-export.json').write_text(json.dumps(export,indent=2));s.db.close()
 # Legacy schema, nonempty legacy tables. Migration only on this disposable file.
 legacy=Path(tmp)/'legacy.sqlite';db=sqlite3.connect(legacy);db.executescript(SCHEMA);db.execute('INSERT INTO migrations VALUES(1,?)',(now(),));db.execute('INSERT INTO migrations VALUES(2,?)',(now(),));db.execute('INSERT INTO audit(ts,action,payload) VALUES(?,?,?)',(now(),'synthetic fixture','{}'));db.execute('INSERT INTO positions VALUES(?,?,?,?,?,?,?)',('A','executable','fixture-wallet','T','M','2','1'));db.commit();db.close()
 evidence=upgrade_existing(legacy,Path(tmp)/'before.sqlite');evidence['classification']='synthetic';evidence['runtime_database_migrated']=False
 check=sqlite3.connect(legacy);evidence['paper_holds']=check.execute('SELECT COUNT(*) FROM paper_holds').fetchone()[0];evidence['versions']=[r[0] for r in check.execute('SELECT version FROM migrations')];check.close();assert evidence['paper_holds']==1
 (OUT/'migration-evidence.json').write_text(json.dumps(evidence,indent=2))
 # Production-classified EMPTY disposable run demonstrates zero results, no supplied wallets.
 empty=Store(tmp+'/empty-production.sqlite');empty_export=forward_evidence(empty);assert empty_export['supplied_wallet_count']==0 and empty_export['no_forward_results']
 (OUT/'empty-forward-readiness.json').write_text(json.dumps(empty_export,indent=2));empty.db.close()
print('Synthetic source replay, deterministic replay, migration/backups and empty forward workflow verified. No user data used.')
