"""Independent read-only Fraction replay; no lab/production imports.
Returns deterministic evidence excluding paths/timestamps. Not a third-party audit.
"""
import argparse,json,sqlite3
from fractions import Fraction as F
from pathlib import Path

def verify(path):
 db=sqlite3.connect(Path(path).resolve().as_uri()+'?mode=ro',uri=True);db.row_factory=sqlite3.Row
 errors=[];totals={};cash=F(0);realized=F(0);seen=set();legs_seen=set();count=0
 classification=db.execute('SELECT kind FROM source_environment WHERE id=1').fetchone()[0]
 for e in db.execute("SELECT e.* FROM verified_events e WHERE e.state='applied' OR EXISTS(SELECT 1 FROM source_movements m WHERE m.event=e.id) ORDER BY ordering,id"):
  count+=1;p=json.loads(e['canonical_payload']);kind=e['kind'];staged=[]
  if not e['provenance'].startswith('synthetic') or classification!='synthetic':errors.append('unaudited production adapter event')
  for effect in p['effects']:
   if (e['wallet'],effect) in seen:errors.append('duplicate effect')
   seen.add((e['wallet'],effect))
  mixed=any(F(x['delta'])<0 for x in p['legs']) and any(F(x['delta'])>0 for x in p['legs'])
  transform=kind in ('CONVERSION','NEG_RISK') or kind=='COMBO' and mixed
  for leg in p['legs']:
   key=(e['wallet'],leg['token']);q,c=totals.get(key,(F(0),F(0)));delta=F(leg['delta']);flow=F(leg.get('cash','0'));r=F(0)
   if (e['wallet'],leg['identity']) in legs_seen:errors.append('duplicate transfer leg')
   legs_seen.add((e['wallet'],leg['identity']))
   if delta>0:change=F(leg['basis'])
   elif delta<0:
    if q<=0 or -delta>q:errors.append('source underflow');continue
    change=c*delta/q;r=flow+change
   else:change=F(0);r=flow
   if transform or kind=='TRANSFER':r=F(0)
   totals[key]=(q+delta,c+change);cash+=flow;realized+=r
   movement=db.execute('SELECT * FROM source_movements WHERE event=? AND leg_identity=?',(e['id'],leg['identity'])).fetchone()
   if movement is None:errors.append('missing source movement');continue
   for field,value in [('delta',delta),('cost_delta',change),('cash',flow),('realized',r)]:
    if abs(F(movement[field])-value)>F(1,1000000):errors.append('source journal '+field+' mismatch')
 for stored in db.execute('SELECT * FROM source_inventory'):
  q,c=totals.pop((stored['wallet'],stored['token']),(F(0),F(0)))
  if abs(q-F(stored['qty']))>F(1,1000000) or abs(c-F(stored['cost']))>F(1,1000000):errors.append('source ending inventory mismatch')
 if any(q or c for q,c in totals.values()):errors.append('missing persisted source inventory')
 for frontier in db.execute('SELECT * FROM capture_frontiers'):
  batch=db.execute('SELECT * FROM collection_batches WHERE id=?',(frontier['batch'],)).fetchone()
  if not batch or batch['status']!='complete':errors.append('frontier refers to incomplete batch');continue
  pages=db.execute('SELECT * FROM collection_pages WHERE batch=? ORDER BY page_number',(batch['id'],)).fetchall()
  if not pages or pages[-1]['cursor_out'] is not None:errors.append('missing terminal capture')
 for page in db.execute('SELECT * FROM collection_pages'):
  raw=json.loads(page['raw']);obs=db.execute('SELECT * FROM source_observations WHERE page=? ORDER BY ordinal',(page['id'],)).fetchall()
  if len(obs)!=len(raw['data']):errors.append('raw observation multiplicity lost')
  for n,o in enumerate(obs):
   if o['ordinal']!=n or json.loads(o['payload'])!=raw['data'][n]:errors.append('provider row/order mismatch')
 result={'classification':classification,'third_party_audit':False,'applied_source_events':count,'source_cash':str(cash),'source_realized':str(realized),'raw_observations':db.execute('SELECT COUNT(*) FROM source_observations').fetchone()[0],'errors':errors,'scope':'independent arithmetic and durable-capture invariants; not chain completeness or market performance'}
 db.close();return result
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--db',required=True);p.add_argument('--out',required=True);a=p.parse_args();result=verify(a.db);Path(a.out).write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2));raise SystemExit(bool(result['errors']))
