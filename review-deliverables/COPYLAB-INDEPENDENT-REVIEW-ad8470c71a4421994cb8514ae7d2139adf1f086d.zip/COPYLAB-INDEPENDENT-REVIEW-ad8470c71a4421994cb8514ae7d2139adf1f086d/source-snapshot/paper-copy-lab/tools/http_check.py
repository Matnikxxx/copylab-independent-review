"""Disposable HTTP integration; synthetic address NEVER polled upstream."""
import subprocess,sys,tempfile,time,json,urllib.request,urllib.error,socket,argparse
p=argparse.ArgumentParser();p.add_argument('--out',default='docs/http-evidence.json');args=p.parse_args()
from pathlib import Path
W='0x'+'2'*40
with socket.socket() as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
with tempfile.TemporaryDirectory() as tmp:
 code="from lab.public import Collector;Collector.cycle=lambda self:self.s.health('public_api',True,'synthetic HTTP test; no upstream requests');from lab.main import main;main()"
 proc=subprocess.Popen([sys.executable,'-c',code,'--db',tmp+'/http.sqlite','--port',str(port)],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
 base=f'http://127.0.0.1:{port}'
 def request(path,data=None,token=None):
  headers={'Content-Type':'application/json'}
  if token:headers['X-Lab-CSRF']=token
  req=urllib.request.Request(base+path,data=json.dumps(data).encode() if data else None,headers=headers)
  try:
   with urllib.request.urlopen(req,timeout=2) as r:return r.status,json.load(r)
  except urllib.error.HTTPError as e:return e.code,json.load(e)
 try:
  # Bounded test subprocess readiness, not a persistent dev-server polling loop.
  for _ in range(60):
   try:status,state=request('/api/state');break
   except (OSError,urllib.error.URLError):time.sleep(.05)
  else:raise RuntimeError('test HTTP server not ready')
  token=state['csrf'];assert request('/api/wallets',{'address':W,'action':'add'})[0]==403
  assert request('/api/wallets',{'address':'bad','action':'add'},token)[0]==400
  assert request('/api/wallets',{'address':W,'action':'add','label':'SYNTHETIC FIXTURE'},token)[0]==200
  assert request('/api/wallets',{'address':W,'action':'disable'},token)[0]==200
  assert request('/api/wallets',{'address':W,'action':'remove'},token)[0]==200
  state=request('/api/state')[1];assert len(state['wallets'])==1 and state['wallets'][0]['removed']==1
  assert len(state['audit'])==3 and not state['events'] and not state['fills']
  report={'database':'disposable synthetic DB, deleted after test','upstream_requests':0,'checks':['CSRF rejected','invalid address rejected','add via HTTP','disable via HTTP','soft remove preserves wallet and audit','all ten ledgers present','no synthetic trades in production DB'],'portfolios':sum(len([t for t in m if t in ('ideal','executable')]) for m in state['models'].values()),'passed':True}
  Path(args.out).write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
 finally:proc.terminate();proc.wait(timeout=10)
