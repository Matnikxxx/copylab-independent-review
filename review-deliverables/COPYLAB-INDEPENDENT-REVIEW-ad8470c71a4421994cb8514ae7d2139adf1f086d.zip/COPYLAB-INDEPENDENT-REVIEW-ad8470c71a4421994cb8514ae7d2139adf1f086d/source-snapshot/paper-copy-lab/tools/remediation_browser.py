"""In-memory intercepted browser checks. No server deployment/network/user DB."""
import sys,json,tempfile
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from lab.main import App
from playwright.sync_api import sync_playwright
with tempfile.TemporaryDirectory() as tmp:
 app=App(tmp+'/empty.sqlite',json.loads(Path('config.json').read_text()));state=app.state();app.s.db.close()
 with sync_playwright() as p:
  browser=p.chromium.launch(headless=True,args=['--no-sandbox']);page=browser.new_page(viewport={'width':1440,'height':1100});errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  def route(r):
   if r.request.url.endswith('/api/state'):r.fulfill(content_type='application/json',body=json.dumps(state))
   else:r.fulfill(content_type='text/html',body=Path('lab/dashboard.html').read_text())
  page.route('**/*',route);checked=[]
  for name in ['overview','A','B','C','D','E','wallets','activity','health']:
   page.goto('http://copylab.test/#'+name);page.wait_for_selector('#content .card');checked.append(name)
  assert page.get_by_text('Source integrity · copying blocked until verified').count()==1
  page.screenshot(path='docs/remediation/health-desktop.png',full_page=True)
  page.set_viewport_size({'width':390,'height':844});overflow=page.evaluate('document.documentElement.scrollWidth>window.innerWidth');assert not overflow
  page.screenshot(path='docs/remediation/health-mobile.png',full_page=True);browser.close()
  result={'classification':'synthetic empty in-memory API fixture','network_requests_to_real_services':0,'pages':checked,'javascript_errors':errors,'mobile_overflow':overflow};assert not errors
  Path('docs/remediation/browser-evidence.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
