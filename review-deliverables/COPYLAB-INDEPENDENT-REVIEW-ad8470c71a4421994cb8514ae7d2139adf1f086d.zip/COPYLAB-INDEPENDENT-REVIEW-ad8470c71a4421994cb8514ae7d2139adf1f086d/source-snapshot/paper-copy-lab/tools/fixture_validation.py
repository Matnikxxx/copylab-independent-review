"""Explicit synthetic accounting stress evidence; NEVER connects to market APIs."""
import json,random,subprocess,sys,tempfile
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from lab.store import Store,now
from lab.engine import Engine
c=json.loads(Path('config.json').read_text());rng=random.Random(44)
with tempfile.TemporaryDirectory() as tmp:
 s=Store(tmp+'/synthetic.sqlite',c,synthetic=True);e=Engine(s,c)
 for model in 'ABCDE':
  for track in ('ideal','executable'):
   for cycle in range(10):
    for step,(side,q) in enumerate([('BUY',10),('BUY',7),('SELL',3),('SELL',7),('SELL',7)]):
     oid=s.db.execute('INSERT INTO orders(event,model,track,wallet,token,market,side,qty,reference,due,status,reason) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',(f'fixture-{cycle}-{step}',model,track,'fixture-wallet','fixture-token','fixture-market',side,str(q),'.5',now(),'filled','synthetic test only')).lastrowid
     order=s.one('SELECT * FROM orders WHERE id=?',(oid,))
     with s.tx():e.a.fill(order,q,str(round(rng.uniform(.2,.8),5)),'.0123','0')
 s.backup(tmp+'/recovered.sqlite');s.db.close()
 subprocess.run([sys.executable,'tools/audit.py','--db',tmp+'/recovered.sqlite','--out','docs/remediation/paper-replay.json'],check=True)
