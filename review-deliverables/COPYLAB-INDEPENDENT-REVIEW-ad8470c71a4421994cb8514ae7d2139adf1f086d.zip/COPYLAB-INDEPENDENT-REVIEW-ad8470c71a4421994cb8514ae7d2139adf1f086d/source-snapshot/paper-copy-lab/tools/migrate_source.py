"""Explicit operator migration, never invoked by tests against runtime data."""
import argparse,json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from lab.migrations import upgrade_existing
p=argparse.ArgumentParser();p.add_argument('--db',required=True);p.add_argument('--backup',required=True);p.add_argument('--evidence',required=True);a=p.parse_args()
result=upgrade_existing(a.db,a.backup);Path(a.evidence).write_text(json.dumps(result,indent=2));print('Migration 3 applied with verified backup; legacy rows preserved.')
