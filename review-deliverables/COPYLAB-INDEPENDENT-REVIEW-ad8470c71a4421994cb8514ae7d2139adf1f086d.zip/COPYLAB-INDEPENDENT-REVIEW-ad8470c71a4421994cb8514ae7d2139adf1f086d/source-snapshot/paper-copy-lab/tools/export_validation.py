"""Explicit read-only export, refuses legacy DB until operator migration."""
import argparse,sqlite3,json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from lab.validation import forward_evidence
class ReadOnly:
 def __init__(self,path):self.db=sqlite3.connect(Path(path).resolve().as_uri()+'?mode=ro',uri=True);self.db.row_factory=sqlite3.Row
 def rows(self,sql,args=()):return [dict(x) for x in self.db.execute(sql,args)]
 def one(self,sql,args=()):
  xs=self.rows(sql,args);return xs[0] if xs else None
p=argparse.ArgumentParser();p.add_argument('--db',required=True);p.add_argument('--out',required=True);a=p.parse_args();s=ReadOnly(a.db)
try:Path(a.out).write_text(json.dumps(forward_evidence(s),indent=2))
finally:s.db.close()
