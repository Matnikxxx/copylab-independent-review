# CopyLab — Polymarket paper copy-trading laboratory

**PAPER ONLY. Research build; acceptance criteria are not all met.** No signing, live order placement, credentials, automatically selected wallets, or existing-project dependencies.

See [Completion / acceptance report](docs/COMPLETION_REPORT.md), [audit findings](docs/AUDIT.md), and [exact continuation plan](docs/CONTINUE.md) before interpreting results.

## Run

Requirements: Python 3.11+ (tested 3.13), `curl`, outbound HTTPS, Linux/macOS (`fcntl` worker lock). Runtime has **no third-party Python dependencies**. Git repository is local; no remote has been created or modified.

```bash
cd /home/user/paper-copy-lab
python3 -m unittest discover -s tests -v
python3 -m lab.main --port 8080
```

Open the live preview or `http://localhost:8080` on your own computer. It binds `0.0.0.0` for sandbox preview compatibility. **Do not expose directly to the public Internet:** there is CSRF protection but no account authentication/TLS. Use a trusted network or authenticated reverse proxy.

Stop: Ctrl+C (SIGINT), or SIGTERM to the foreground process. Restart with the identical command and database path. SQLite persists cash, inventory, events, decisions, fills and audit history. Never delete the database to resolve a configuration error. The sandbox preview is not a durable 24/7 hosting service.

## Wallets

Open **Wallet registry** → add a user-supplied Polymarket **proxy wallet** (`0x` + 40 hex digits). Zero address is rejected; hex shape validation is not proof of ownership or existence. Wallets start empty in this distribution.

All models read the same registry each cycle. Initial admission waits for two matching current-position snapshots and no activity in a recent 60-second window; no historical paper fills are invented. Highly active wallets may never admit under this conservative rule. After admission, public closed-position statistics are collected to qualify B and size E. Baseline limitations and indexing-lag risks are detailed in the audit.

Disable cancels pending buys. Existing positions remain eligible for model exits and settlement; wallet sells while disabled are not copied. Remove is a soft delete preserving all history. Enable triggers inventory re-baselining; this does **not** reconstruct missed activity or reconcile old copied inventory automatically. Re-enable with existing positions only after explicit review.

## Configuration

Edit `config.json` **with the worker stopped**, then:

```bash
python3 tools/configure.py --db data/lab.sqlite
python3 -m lab.main --db data/lab.sqlite --port 8080
```

Configuration is validated and versioned in the DB audit. A silently changed file is refused on restart. Starting capital is immutable for an existing run; use a different database for a new experiment. See [configuration reference](docs/CONFIGURATION.md).

## Verification

```bash
python3 -m unittest discover -s tests -v
python3 tools/fixture_validation.py    # 500 SYNTHETIC fills; disposable DB; independent Fraction replay
python3 tools/audit.py                # read-only replay of actual local DB
python3 tools/http_check.py           # disposable HTTP integration; no upstream wallet requests
```

Optional browser evidence (development only):

```bash
python3 -m pip install playwright
python3 -m playwright install --with-deps chromium
python3 tools/browser_check.py        # app must be running on 8080
```

Historical failed test logs are retained. Synthetic fixtures never enter `data/lab.sqlite`.

## Backups and recovery

```bash
mkdir -p data/backups
python3 -m lab.main --backup data/backups/lab-backup.sqlite
```

SQLite's online backup API includes committed WAL content. Store backups off-host as well. For recovery: stop worker, preserve the damaged DB and its `-wal`/`-shm` files together, restore a verified backup to a **new path**, check `PRAGMA integrity_check`, then start with `--db recovered.sqlite`. Do not copy just a busy main `.sqlite` file. Transactions commit fills, cash movements, cost basis, closure and order status atomically. Gaps beyond the event overlap can require explicit reconciliation; recovery is not a promise of lossless upstream history.

## Layout

- `lab/public.py`: fixed-origin GET-only public API client, v2 cursor collector, stable baseline, token finality.
- `lab/strategies.py`: A–E entry decisions.
- `lab/engine.py`: ordering/quarantine, risk, hybrid copying, depth simulation, model exits and settlement.
- `lab/accounting.py`: Decimal fee-inclusive weighted-average basis, partial exits, closed cycles, snapshots.
- `lab/store.py`: SQLite schema/migrations, transactions, backup.
- `lab/main.py`, `lab/dashboard.html`: worker and responsive dashboard.
- `tests/`: synthetic unit/regression tests; `tools/`: separately runnable verification.
- `docs/`: official API extracts, journal, architecture, audit, browser/test evidence and forward observation report.

---
## H01–H05 safety remediation notice (uncommitted changes)

Read `docs/REMEDIATION_REPORT.md` before using earlier run instructions. Runtime DBs
at schema 2 now require an explicit backed-up migration 3 and were NOT migrated by
this task. Production source copying is deliberately blocked without an audited
canonical checkpoint/log adapter; matching REST snapshots no longer admit a wallet.
Synthetic tests still exercise original strategies/risk/financial algorithms. No
new build has been deployed. No real wallet-driven validation is authorised or run.
